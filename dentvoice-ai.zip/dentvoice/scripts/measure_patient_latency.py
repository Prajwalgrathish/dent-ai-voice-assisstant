"""Measure Patient Voice Assistant response latency.

Default (no models needed): measures the server-side ORCHESTRATION only (safety policy, interpreter rules, patient-scoped
tools, composition, guardrails) with the fake STT/LLM/TTS providers, in-process and over real HTTP on localhost.
Those numbers say nothing about model speed.

With --real it uses the providers configured in .env (faster-whisper / Ollama or hosted LLM / Piper), so you can measure
the real end-to-end figures on YOUR machine. Run:

    python scripts/measure_patient_latency.py            # orchestration only (fake providers)
    python scripts/measure_patient_latency.py --real     # real providers from .env
    python scripts/measure_patient_latency.py --runs 20
"""

from __future__ import annotations

import argparse
import statistics
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import requests  # noqa: E402
import uvicorn  # noqa: E402

from voiceassistant.api import create_app  # noqa: E402
from voiceassistant.config import Settings  # noqa: E402
from voiceassistant.factory import build_pipeline  # noqa: E402

QUESTIONS = [
    "Explain my report.",
    "Elaborate on my report.",
    "Describe my findings.",
    "What are molar teeth?",
    "What does this finding mean?",
    "Can you explain this in simple English?",
    "Do I have cancer?",  # refusal path (never calls a model)
]


def pct(values, p):
    values = sorted(values)
    return values[min(len(values) - 1, int(round(p / 100 * (len(values) - 1))))]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--real", action="store_true", help="use the real providers configured in .env")
    ap.add_argument("--runs", type=int, default=10)
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--speak", action="store_true", help="also synthesize speech (measures TTS)")
    args = ap.parse_args()

    env = {} if args.real else {"STT_PROVIDER": "fake", "LLM_PROVIDER": "fake", "TTS_PROVIDER": "fake"}
    settings = Settings.from_env(env if env else None, dotenv_path=".env")
    pipeline = build_pipeline(settings)
    server = uvicorn.Server(uvicorn.Config(create_app(pipeline), host="127.0.0.1", port=args.port, log_level="error"))
    threading.Thread(target=server.run, daemon=True).start()
    while not server.started:
        time.sleep(0.05)
    base = f"http://127.0.0.1:{args.port}"

    print(f"providers: stt={pipeline.stt.name} llm={pipeline.llm.name} tts={pipeline.tts.name}  mode={'REAL' if args.real else 'fake (orchestration only)'}")
    print(f"{'question':44} {'n':>3} {'http p50':>9} {'http p95':>9} {'server p50':>11} {'model p50':>10}")
    all_http = []
    for q in QUESTIONS:
        http_ms, server_ms, model_ms = [], [], []
        for _ in range(args.runs):
            token = requests.post(f"{base}/v1/patient/session", json={"patient_id": "P001"}, timeout=10).json()["session_token"]
            h = {"Authorization": f"Bearer {token}"}
            if q.startswith(("What does this", "Can you")):  # follow-ups need a first answer in the same session
                requests.post(f"{base}/v1/patient/chat", json={"message": "Explain my OPG report"}, headers=h, timeout=120)
            t = time.perf_counter()
            r = requests.post(f"{base}/v1/patient/chat", json={"message": q, "speak": args.speak}, headers=h, timeout=120)
            http_ms.append((time.perf_counter() - t) * 1000)
            body = r.json()
            server_ms.append(body["timings_ms"]["total"])
            model_ms.append(body["timings_ms"].get("llm_generate", 0.0))
        all_http += http_ms
        print(f"{q[:44]:44} {args.runs:>3} {statistics.median(http_ms):>7.1f}ms {pct(http_ms, 95):>7.1f}ms {statistics.median(server_ms):>9.1f}ms {statistics.median(model_ms):>8.1f}ms")
    print(f"\nOVERALL http p50={statistics.median(all_http):.1f} ms  p95={pct(all_http, 95):.1f} ms over {len(all_http)} requests")
    server.should_exit = True
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
