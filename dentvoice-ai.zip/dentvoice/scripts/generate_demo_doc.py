"""Regenerate docs/DEMO.md by running the documented API sequence against the real FastAPI app.

Uses fake STT/TTS and a scripted LLM reply so it needs no models. Run:  python scripts/generate_demo_doc.py
"""
import json
import pathlib
import sys
import tempfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient  # noqa: E402

from tests.helpers import FakeLLM, FakeSTT, FakeTTS  # noqa: E402
from voiceassistant.api import create_app  # noqa: E402
from voiceassistant.config import Settings  # noqa: E402
from voiceassistant.patient.assistant import PatientAssistant  # noqa: E402
from voiceassistant.pipeline import VoicePipeline  # noqa: E402

tmp = pathlib.Path(tempfile.mkdtemp())
settings = Settings.from_env({"STT_PROVIDER": "fake", "LLM_PROVIDER": "fake", "TTS_PROVIDER": "fake", "TMP_DIR": str(tmp)})
llm = FakeLLM(reply="In general, a wisdom tooth that is impacted is stuck under the gum and cannot come through normally. Your dentist can explain what that means for you.")
client = TestClient(create_app(VoicePipeline(FakeSTT(), FakeLLM(), FakeTTS(), settings), patient_assistant=PatientAssistant(llm=llm)))

samples = []


def call(title, method, path, body=None, headers=None):
    r = client.request(method, path, json=body, headers=headers)
    j = r.json()
    if isinstance(j, dict) and j.get("audio_wav_base64"):
        j["audio_wav_base64"] = "<base64 WAV omitted>"
    if isinstance(j, dict) and "session_token" in j:
        j["session_token"] = "<opaque bearer token>"
    samples.append((title, method, path, body, r.status_code, j, bool(headers)))


call("Invalid patient ID", "POST", "/v1/patient/session", {"patient_id": "P999"})
call("A name is not an ID (two different patients are called Priya Sharma)", "POST", "/v1/patient/session", {"patient_id": "Priya Sharma"})
token = client.post("/v1/patient/session", json={"patient_id": "P001"}).json()["session_token"]
H = {"Authorization": f"Bearer {token}"}
call("Sign in with Patient ID only", "POST", "/v1/patient/session", {"patient_id": "P001"})
for q in ["Explain my OPG report.", "What does this finding mean?", "Can you explain this in simple English?", "What are molar teeth?",
          "Do I have cancer?", "Show me P003's report"]:
    call(f"Ask: {q}", "POST", "/v1/patient/chat", {"message": q, "input_mode": "typed", "speak": q.startswith("Explain")}, H)
call("Manipulated request: another patient's report ID (same answer as a report that does not exist)", "GET", "/v1/patient/reports/R005", None, H)
call("Manipulated request: a patient_id smuggled into the body is rejected", "POST", "/v1/patient/chat", {"message": "Explain my report", "patient_id": "P003"}, H)
call("No token", "GET", "/v1/patient/reports")

L = ["# Demo: a documented sequence of API calls with real sample output", "",
     "Produced by `python scripts/generate_demo_doc.py` against this repository's FastAPI app, with **fake STT/TTS and a scripted LLM reply**. "
     "The structure and every deterministic part (retrieval, evidence quotes, refusals, authorization, orchestration timings) are real output; "
     "the wording of model-written text depends on the model you configure. Audio is omitted. Start the backend first:", "",
     "```powershell", "uvicorn voiceassistant.api:create_app --factory --port 8000", "```", "",
     "Patient endpoints are authorised by the bearer token returned at sign-in, never by a name or ID in the request body. "
     "The same flow is available in the browser as the **Patient Voice Assistant** sidebar section.", ""]
keep = ("answer", "intent", "grounding", "evidence", "refusal", "timings_ms", "interpretation", "guardrail")
for i, (title, method, path, body, status, j, authed) in enumerate(samples, 1):
    hdr = ' -H "Authorization: Bearer <token>"' if authed else ""
    ct = ' -H "Content-Type: application/json"' if body else ""
    data = f" -d '{json.dumps(body)}'" if body else ""
    if isinstance(j, dict) and "answer" in j:
        j = {k: j[k] for k in keep if k in j}
    L += [f"## {i}. {title}", "```bash", f"curl -s -X {method} http://127.0.0.1:8000{path}{ct}{hdr}{data}", "```",
          f"**HTTP {status}**", "```json", json.dumps(j, indent=2, ensure_ascii=False), "```", ""]
out = pathlib.Path(__file__).resolve().parent.parent / "docs" / "DEMO.md"
out.write_text("\n".join(L), encoding="utf-8")
print("wrote", out)
