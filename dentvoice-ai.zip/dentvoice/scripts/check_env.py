"""Compatibility / setup check. Run this on YOUR machine after installing requirements:

    python scripts\\check_env.py              # quick: imports, versions, Piper CLI, Ollama reachability
    python scripts\\check_env.py --load-models   # also loads the Whisper model (downloads ~150 MB the first time)

Standard library only. It never changes anything; it only reports.
"""

import argparse
import importlib.metadata as md
import json
import os
import platform
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from voiceassistant.config import Settings  # noqa: E402
from voiceassistant.errors import VoiceAssistantError  # noqa: E402

results = []


def report(status, name, detail=""):
    results.append(status)
    print(f"[{status:^7}] {name}" + (f" - {detail}" if detail else ""))


def version(pkg):
    try:
        return md.version(pkg)
    except md.PackageNotFoundError:
        return None


def check_python():
    v = sys.version_info
    ok = (3, 10) <= (v.major, v.minor) <= (3, 12)
    report("OK" if ok else "WARN", "Python", f"{platform.python_version()} on {platform.system()} {platform.release()}"
           + ("" if ok else " (3.11 is the tested target)"))


def check_packages():
    required = [("faster-whisper", "speech recognition"), ("piper-tts", "preferred TTS"), ("pyttsx3", "fallback TTS (Windows)")]
    optional = [("sounddevice", "--record microphone"), ("fastapi", "API"), ("uvicorn", "API server"),
                ("python-multipart", "API uploads"), ("httpx", "API tests"), ("pytest", "test runner")]
    for pkg, why in required:
        v = version(pkg)
        report("OK" if v else "MISSING", pkg, f"{v} ({why})" if v else f"not installed ({why})")
    for pkg, why in optional:
        v = version(pkg)
        report("OK" if v else "optional", pkg, f"{v} ({why})" if v else f"not installed ({why})")


def check_piper(settings):
    if not version("piper-tts"):
        return
    try:
        proc = subprocess.run([sys.executable, "-m", "piper", "--help"], capture_output=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as exc:
        report("FAIL", "piper CLI", f"could not run: {type(exc).__name__}")
        return
    text = (proc.stdout + proc.stderr).decode("utf-8", "replace")
    if proc.returncode != 0:
        report("FAIL", "piper CLI", "`python -m piper --help` failed; first lines: " + " | ".join(text.strip().splitlines()[:3]))
        return
    style = "--output-file" if "--output-file" in text else ("--output_file" if "--output_file" in text else "unknown")
    report("OK" if style != "unknown" else "WARN", "piper CLI", f"runs; output flag spelling: {style}")
    model = settings.piper_model_path
    if not model:
        report("WARN", "PIPER_MODEL_PATH", "not set; Piper cannot speak until a voice model is configured (see README)")
    elif Path(model).is_file() and Path(model + ".json").is_file():
        report("OK", "Piper voice model", model)
    else:
        report("FAIL", "Piper voice model", f"{model} or its .onnx.json not found")


def check_pyttsx3():
    if not version("pyttsx3"):
        return
    try:
        import pyttsx3

        engine = pyttsx3.init()
        n = len(engine.getProperty("voices") or [])
        engine.stop()
        report("OK" if n else "WARN", "pyttsx3 engine", f"initialised; {n} voice(s) found")
    except Exception as exc:  # noqa: BLE001
        report("FAIL", "pyttsx3 engine", f"init failed: {type(exc).__name__}: {exc}")


def check_whisper(settings, load):
    if not version("faster-whisper"):
        return
    if not load:
        report("skipped", "Whisper model load", "run with --load-models to test (downloads the model on first run)")
        return
    try:
        from faster_whisper import WhisperModel

        WhisperModel(settings.stt_model, device=settings.stt_device, compute_type=settings.stt_compute_type)
        report("OK", "Whisper model load", f"{settings.stt_model} ({settings.stt_device}/{settings.stt_compute_type})")
    except Exception as exc:  # noqa: BLE001
        report("FAIL", "Whisper model load", f"{type(exc).__name__}: {exc}")


def check_llm(settings):
    url = settings.llm_base_url + "/models"
    headers = {"Authorization": f"Bearer {settings.llm_api_key}"} if settings.llm_api_key else {}
    local = "localhost" in url or "127.0.0.1" in url
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) if local else urllib.request.build_opener()
    try:
        with opener.open(urllib.request.Request(url, headers=headers), timeout=5) as resp:
            data = json.loads(resp.read(1_000_000).decode("utf-8"))
        ids = [m.get("id") for m in data.get("data", []) if isinstance(m, dict)]
        report("OK", "LLM endpoint", f"{settings.llm_base_url} reachable; models: {', '.join(map(str, ids[:8])) or '(none listed)'}")
        if ids and settings.llm_model not in ids:
            report("WARN", "LLM_MODEL", f"{settings.llm_model!r} not in the list above (Ollama: `ollama pull {settings.llm_model}`)")
    except urllib.error.HTTPError as exc:
        report("WARN", "LLM endpoint", f"reachable but /models returned HTTP {exc.code} (may still work for chat)")
    except Exception as exc:  # noqa: BLE001
        report("FAIL", "LLM endpoint", f"{settings.llm_base_url} not reachable ({type(exc).__name__}). Is Ollama running?")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--load-models", action="store_true")
    args = ap.parse_args()
    print(f"Python executable: {sys.executable}\n")
    check_python()
    check_packages()
    try:
        settings = Settings.from_env(dotenv_path=Path(".env"))
    except VoiceAssistantError as exc:
        report("FAIL", "Configuration", exc.user_message)
        return 1
    report("OK", "Configuration", f"stt={settings.stt_provider} llm={settings.llm_provider}@{settings.llm_base_url} tts={','.join(settings.tts_providers)}")
    check_piper(settings)
    check_pyttsx3()
    check_whisper(settings, args.load_models)
    if settings.llm_provider == "openai_compat":
        check_llm(settings)
    bad = results.count("FAIL") + results.count("MISSING")
    print(f"\n{results.count('OK')} OK, {results.count('WARN')} warnings, {bad} problems.")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
