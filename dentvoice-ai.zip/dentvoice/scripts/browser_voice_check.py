"""Drive the RUNNING app in real Chromium with a fake microphone and report what the browser actually did.

Start the backend and the frontend first (see README), then:

    python scripts/browser_voice_check.py --url http://localhost:8502

Needs:  pip install playwright  &&  python -m playwright install chromium
The microphone is Chromium's fake device (a generated WAV file), so no hardware or permission prompt is involved.
It checks: greeting playback -> automatic listening, spoken request -> reply playback -> listening again,
the 15 s idle stop, clarification with a microphone off/on, "Listen to me", and blocked-autoplay recovery.
Nothing here is mocked in the app: it exercises the same pages you use.
"""

from __future__ import annotations

import argparse
import io
import math
import struct
import tempfile
import wave
from pathlib import Path

BLOCK_FIRST_PLAY = """(() => { const orig = HTMLMediaElement.prototype.play; let blocked = false;
  HTMLMediaElement.prototype.play = function () { if (!blocked) { blocked = true;
  return Promise.reject(new DOMException('play() blocked', 'NotAllowedError')); } return orig.apply(this, arguments); }; })();"""


def make_wav(segments, rate=16000) -> bytes:
    buf = io.BytesIO()
    w = wave.open(buf, "wb")
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
    for kind, secs in segments:
        w.writeframes(b"".join(struct.pack("<h", int(9000 * math.sin(2 * math.pi * 220 * i / rate) * (1 + math.sin(i / 900)) / 2) if kind == "tone" else 0)
                               for i in range(int(rate * secs))))
    w.close()
    return buf.getvalue()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8502")
    args = ap.parse_args()
    from playwright.sync_api import sync_playwright

    tmp = Path(tempfile.mkdtemp())
    silence, speech = tmp / "silence.wav", tmp / "speech.wav"
    silence.write_bytes(make_wav([("sil", 300)]))
    speech.write_bytes(make_wav([("sil", 6), ("tone", 1.5), ("sil", 300)]))
    results: list[tuple[str, bool, str]] = []

    def check(name, ok, detail=""):
        results.append((name, bool(ok), detail))
        print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))

    def session(p, mic, block=False):
        b = p.chromium.launch(args=["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream",
                                    f"--use-file-for-fake-audio-capture={mic}%noloop"])
        page = b.new_context(permissions=["microphone"], viewport={"width": 1300, "height": 1000}).new_page()
        if block:
            page.add_init_script(BLOCK_FIRST_PLAY)
        page.goto(args.url)
        page.wait_for_selector("text=AI Assistant", timeout=30000)
        f = None
        for _ in range(100):
            f = next((x for x in page.frames if "dentvoice_mic" in x.url), None)
            if f:
                break
            page.wait_for_timeout(250)
        f.wait_for_selector("#label", state="attached", timeout=20000)
        f.evaluate("""() => { window.__hist = []; const l = document.getElementById('label');
            const rec = () => window.__hist.push(l.textContent); rec();
            new MutationObserver(rec).observe(l, {childList:true, characterData:true, subtree:true}); }""")
        return b, page, f

    def label(f): return f.evaluate("document.getElementById('label').textContent")
    def hist(f): return f.evaluate("window.__hist")
    def events(f): return f.evaluate("window.__dv().outbox.map(e => e.type + ':' + (e.action || e.state || ''))")

    def wait_label(f, want, seconds=25):
        for _ in range(int(seconds * 4)):
            if label(f) == want:
                return True
            f.page.wait_for_timeout(250)
        return False

    def chat(page, text):
        box = page.get_by_placeholder("Type your message or request…")
        box.fill(text); box.press("Enter"); page.wait_for_timeout(2500)

    with sync_playwright() as p:
        # 1. greeting -> automatic listening -> spoken request -> reply -> listening -> idle stop
        b, page, f = session(p, speech)
        wait_label(f, "Stopped after silence", 45)
        h = hist(f)
        ev = events(f)
        check("greeting audio really played", "playback:started" in ev and "playback:ended" in ev, str(ev))
        check("listening starts after the greeting ended", ev.index("playback:ended") < ev.index("action:resume"))
        check("speech was captured and answered", "Hearing you…" in h and "Working on it…" in h, str(h))
        check("reply audio played, then listening again", h.count("Speaking…") >= 2 and "Listening…" in h[h.index("Working on it…"):], str(h))
        check("15 s of silence stopped capture", h[-1] == "Stopped after silence" and "action:idle_timeout" in ev)
        body = page.inner_text("body")
        check("page does not claim Speaking/Listening after the stop", "Speaking…" not in body)
        check("exactly one greeting on screen", body.count("How can I help") == 1)
        b.close()

        # 2. clarification survives microphone off/on, spoken label independent of speaking
        b, page, f = session(p, silence)
        wait_label(f, "Listening…", 30)
        chat(page, "Show me Priya Sharma's reports")
        check("duplicate name -> asks which patient", "Which one" in page.inner_text("body") or "Which one d" in page.inner_text("body"))
        check("microphone waits for the answer", wait_label(f, "Listening for your answer…", 20), label(f))
        f.evaluate("document.getElementById('mic').click()"); page.wait_for_timeout(1500)
        check("mic off -> Paused", label(f) == "Paused")
        f.evaluate("document.getElementById('mic').click()")
        check("mic on again -> still waiting for the answer", wait_label(f, "Listening for your answer…", 10))
        chat(page, "Patient ID is P001")
        check("answer resolves the ORIGINAL request", "P001" in page.inner_text("body") and "Priya Sharma (P001)" in page.inner_text("body").replace("\n", " "))
        b.close()

        # 3. "Listen to me" after the idle stop
        b, page, f = session(p, silence)
        wait_label(f, "Stopped after silence", 45)
        chat(page, "Listen to me")
        check('typed "Listen to me" restarts listening', wait_label(f, "Listening…", 15), str(hist(f)[-4:]))
        check("no second greeting", page.inner_text("body").count("How can I help") == 1)
        b.close()

        # 4. autoplay blocked -> visible recovery, never "Speaking"
        b, page, f = session(p, silence, block=True)
        page.wait_for_timeout(3000)
        check("blocked autoplay is reported", "playback:blocked" in events(f))
        check("one-tap enable-audio control shown", f.evaluate("document.getElementById('audio-btn').classList.contains('show')"))
        check("UI does not claim to be speaking", "Speaking…" not in hist(f))
        f.evaluate("document.getElementById('audio-btn').click()"); page.wait_for_timeout(2500)
        check("tapping it plays the greeting", "playback:ended" in events(f))
        b.close()

    failed = [r for r in results if not r[1]]
    print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
