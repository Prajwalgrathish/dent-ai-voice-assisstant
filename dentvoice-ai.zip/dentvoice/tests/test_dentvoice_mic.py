"""Unit and regression tests for Claude's dentvoice_mic component and integration:
1. Component declaration and exported symbols.
2. Event parsing (Utterance, MicError, MicAction).
3. Audio validation and empty/malformed audio safety rejection.
4. Action events (pause, resume).
5. Assistant state management and silence timeout integration.
"""

from __future__ import annotations

import base64
import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

_ROOT = Path(__file__).resolve().parent.parent
_FRONTEND = _ROOT / "frontend"
for _p in (str(_ROOT), str(_FRONTEND)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from dentvoice_mic import (
    Event,
    MicAction,
    MicError,
    Utterance,
    _parse,
    dentvoice_mic,
    dentvoice_mic_events,
)
from frontend.sections.assistant import _init, _queue_reply_audio, _voice_status


def _make_dummy_wav(num_samples: int = 16000, rate: int = 16000) -> bytes:
    """Construct a minimal valid RIFF/WAV header with PCM mono 16-bit data."""
    data_bytes = b"\x00" * (num_samples * 2)
    total_size = 36 + len(data_bytes)
    header = bytearray(44)
    header[0:4] = b"RIFF"
    header[4:8] = total_size.to_bytes(4, "little")
    header[8:12] = b"WAVE"
    header[12:16] = b"fmt "
    header[16:20] = (16).to_bytes(4, "little")
    header[20:22] = (1).to_bytes(2, "little")  # PCM
    header[22:24] = (1).to_bytes(2, "little")  # 1 channel (mono)
    header[24:28] = rate.to_bytes(4, "little")
    header[28:32] = (rate * 2).to_bytes(4, "little")
    header[32:34] = (2).to_bytes(2, "little")
    header[34:36] = (16).to_bytes(2, "little")
    header[36:40] = b"data"
    header[40:44] = len(data_bytes).to_bytes(4, "little")
    return bytes(header) + data_bytes


class DentVoiceMicComponentTests(unittest.TestCase):
    """Test dentvoice_mic data structures, parsing, and error safety."""

    def test_exported_classes_and_types(self):
        self.assertTrue(callable(dentvoice_mic))
        u = Utterance(id="t-1", wav=b"RIFF...", duration_s=1.0, sample_rate=16000)
        self.assertEqual(u.id, "t-1")
        self.assertEqual(u.sample_rate, 16000)

        e = MicError(id="t-2", code="permission_denied", message="Access denied")
        self.assertEqual(e.code, "permission_denied")

        a = MicAction(id="t-3", action="pause")
        self.assertEqual(a.action, "pause")

    def test_dentvoice_mic_defaults_are_sensitive_to_speech(self):
        import inspect
        sig = inspect.signature(dentvoice_mic_events)  # dentvoice_mic() is a thin wrapper around it
        params = sig.parameters
        self.assertAlmostEqual(params["min_rms"].default, 0.006)
        self.assertEqual(params["min_speech_ms"].default, 200)
        self.assertEqual(params["end_silence_ms"].default, 900)
        self.assertEqual(params["hold_timeout_ms"].default, 120_000)
        self.assertEqual(params["idle_timeout_ms"].default, 15_000)

    def test_parse_valid_utterance(self):
        wav = _make_dummy_wav(8000, 16000)
        raw = {
            "type": "utterance",
            "id": "utt-101",
            "wav_b64": base64.b64encode(wav).decode("ascii"),
            "duration_s": 0.5,
            "sample_rate": 16000,
        }
        parsed = _parse(raw)
        self.assertIsInstance(parsed, Utterance)
        self.assertEqual(parsed.id, "utt-101")
        self.assertEqual(parsed.wav, wav)
        self.assertEqual(parsed.duration_s, 0.5)

    def test_parse_rejects_empty_or_too_small_audio(self):
        # Empty audio payload
        raw = {
            "type": "utterance",
            "id": "utt-empty",
            "wav_b64": base64.b64encode(b"").decode("ascii"),
            "duration_s": 0.0,
        }
        parsed = _parse(raw)
        self.assertIsInstance(parsed, MicError)
        self.assertEqual(parsed.code, "empty_audio")

        # Audio smaller than 44 bytes (corrupt header)
        raw_short = {
            "type": "utterance",
            "id": "utt-short",
            "wav_b64": base64.b64encode(b"RIFFshort").decode("ascii"),
            "duration_s": 0.01,
        }
        parsed_short = _parse(raw_short)
        self.assertIsInstance(parsed_short, MicError)
        self.assertEqual(parsed_short.code, "empty_audio")

    def test_parse_rejects_non_riff_format(self):
        corrupt = b"NOPE" + b"\x00" * 50
        raw = {
            "type": "utterance",
            "id": "utt-corrupt",
            "wav_b64": base64.b64encode(corrupt).decode("ascii"),
            "duration_s": 0.1,
        }
        parsed = _parse(raw)
        self.assertIsInstance(parsed, MicError)
        self.assertEqual(parsed.code, "empty_audio")

    def test_parse_mic_error_event(self):
        raw = {
            "type": "error",
            "id": "err-1",
            "code": "permission_denied",
            "message": "User denied permission",
        }
        parsed = _parse(raw)
        self.assertIsInstance(parsed, MicError)
        self.assertEqual(parsed.code, "permission_denied")
        self.assertEqual(parsed.message, "User denied permission")

    def test_parse_mic_action_event(self):
        raw_pause = {"type": "action", "id": "act-1", "action": "pause"}
        parsed_pause = _parse(raw_pause)
        self.assertIsInstance(parsed_pause, MicAction)
        self.assertEqual(parsed_pause.action, "pause")

        raw_resume = {"type": "action", "id": "act-2", "action": "resume"}
        parsed_resume = _parse(raw_resume)
        self.assertIsInstance(parsed_resume, MicAction)
        self.assertEqual(parsed_resume.action, "resume")

    def test_parse_none_for_invalid_input(self):
        self.assertIsNone(_parse(None))
        self.assertIsNone(_parse("string"))
        self.assertIsNone(_parse({}))
        self.assertIsNone(_parse({"type": "unknown"}))


class DentVoiceMicAssistantIntegrationTests(unittest.TestCase):
    """Test assistant state transitions with dentvoice_mic."""

    def setUp(self):
        import streamlit as st
        st.session_state.clear()
        _init()

    def test_init_sets_dentvoice_mic_state_keys(self):
        import streamlit as st
        for key in ("dv_turn_id", "dv_last_event_id", "dv_playing_id", "dv_audio", "dv_listening", "dv_standby"):
            self.assertIn(key, st.session_state)
        self.assertIsNone(st.session_state.dv_playing_id)
        self.assertFalse(st.session_state.dv_listening)

    def test_queueing_reply_audio_never_marks_the_assistant_as_speaking(self):
        import streamlit as st
        _queue_reply_audio(_make_dummy_wav(32000, 16000), is_clarification=False)
        self.assertIsNotNone(st.session_state.dv_audio)
        self.assertIsNone(st.session_state.dv_playing_id)
        self.assertEqual(_voice_status()[0], "idle")

    def test_mic_error_updates_dv_turn_id_to_release_gate(self):
        import streamlit as st
        err = MicError(id="err-release-99", code="empty_audio", message="Empty audio")
        from frontend.sections.assistant import _handle_mic_error
        _handle_mic_error(err)
        self.assertEqual(st.session_state.dv_turn_id, "err-release-99")
        self.assertIsNone(st.session_state.dv_mic_error, "empty audio is dropped silently, not an error state")


if __name__ == "__main__":
    unittest.main()
