from io import BytesIO
import pytest
from pypdf import PdfReader
from voiceassistant.report_pdf import build_report_pdf, compare_reports

PAT = {"patient_id": "P001", "name": "Priya Sharma", "date_of_birth": "1988-04-12"}
R1 = {"report_id": "R001", "patient_id": "P001", "date": "2025-01-10", "type": "Examination",
      "findings": ["Caries on 36", "Mild gingivitis"], "anatomical_sites": ["36"], "recommendations": ["Restoration of 36"]}
R2 = {"report_id": "R002", "patient_id": "P001", "date": "2025-06-02", "type": "Follow-up",
      "findings": ["Mild gingivitis", "Plaque build-up"], "assessment": "Stable"}


def text(pdf):
    r = PdfReader(BytesIO(pdf))
    return r, "\n".join(p.extract_text() for p in r.pages)


def test_single_report_pdf_has_identity_and_content():
    pdf = build_report_pdf(PAT, [R1])
    assert pdf.startswith(b"%PDF")
    r, t = text(pdf)
    for s in ("Priya Sharma", "P001", "R001", "2025-01-10", "Caries on 36", "Restoration of 36", "Page 1 of 1"):
        assert s in t
    assert "not signed" in t.lower()


def test_missing_fields_are_stated_not_invented():
    _, t = text(build_report_pdf(PAT, [R2]))
    assert t.count("Not documented in this report") >= 3     # sites, recommendations, clinician
    assert "Caries" not in t


def test_refuses_other_patients_report():
    bad = dict(R1, patient_id="P002")
    with pytest.raises(ValueError):
        build_report_pdf(PAT, [bad])


def test_input_validation():
    with pytest.raises(ValueError):
        build_report_pdf(PAT, [])
    with pytest.raises(ValueError):
        build_report_pdf({"name": "x"}, [R1])
    with pytest.raises(ValueError):
        build_report_pdf(PAT, [R1], kind="summary")
    with pytest.raises(ValueError):
        build_report_pdf(PAT, [R1], kind="comparison")


def test_ai_summary_is_labelled_draft_with_source():
    _, t = text(build_report_pdf(PAT, [R1], kind="summary", ai_summary="Caries noted on tooth 36."))
    assert "AI-GENERATED DRAFT" in t and "R001" in t and "Caries noted on tooth 36." in t


def test_comparison_is_deterministic_and_only_uses_documented_entries():
    c = compare_reports(R1, R2)
    assert c["findings"]["added"] == ["Plaque build-up"] and c["findings"]["removed"] == ["Caries on 36"]
    assert c["findings"]["unchanged"] == ["Mild gingivitis"]
    _, t = text(build_report_pdf(PAT, [R2, R1], kind="comparison"))
    assert "Plaque build-up" in t and "no clinical interpretation" in t.lower()


def test_multi_page_and_long_text_and_unicode():
    long = dict(R1, report_id="R9", findings=[f"Finding {i}: " + "detailed observation " * 15 for i in range(80)])
    pdf = build_report_pdf(PAT, [long, R2], kind="report")
    r, t = text(pdf)
    assert len(r.pages) >= 2 and f"Page 2 of {len(r.pages)}" in t
    u = build_report_pdf(dict(PAT, name="Priya Sharma ®"), [dict(R1, findings=["Sensitivity <cold> & 'hot' – 36"])])
    assert u.startswith(b"%PDF")        # special characters must not break layout markup


def test_export_all_sorted_newest_first():
    _, t = text(build_report_pdf(PAT, [R1, R2]))
    assert t.index("R002") < t.index("R001")
