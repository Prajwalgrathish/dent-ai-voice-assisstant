import contextlib
import io
import unittest

from tests.helpers import TmpCase
from voiceassistant.cli import main
from voiceassistant.config import Settings
from voiceassistant.factory import build_llm, build_stt, build_tts
from voiceassistant.providers.base import FallbackTTS
from voiceassistant.providers.llm_openai_compat import OpenAICompatLLM
from voiceassistant.providers.stt_faster_whisper import FasterWhisperSTT
from voiceassistant.providers.tts_piper import PiperTTS
from voiceassistant.providers.tts_pyttsx3 import Pyttsx3TTS


class FactoryTests(unittest.TestCase):
    def test_default_settings_build_real_provider_objects_without_importing_heavy_packages(self):
        s = Settings.from_env({})
        self.assertIsInstance(build_stt(s), FasterWhisperSTT)
        self.assertIsInstance(build_llm(s), OpenAICompatLLM)
        tts = build_tts(s)
        self.assertIsInstance(tts, FallbackTTS)
        self.assertEqual([type(p) for p in tts.providers], [PiperTTS, Pyttsx3TTS])

    def test_switching_llm_endpoint_is_config_only(self):
        local = build_llm(Settings.from_env({}))
        hosted = build_llm(Settings.from_env({"LLM_BASE_URL": "https://api.example.com/v1", "LLM_API_KEY": "k", "LLM_MODEL": "m"}))
        self.assertEqual((type(local), type(hosted)), (OpenAICompatLLM, OpenAICompatLLM))
        self.assertNotEqual(local.base_url, hosted.base_url)

    def test_single_tts_is_not_wrapped(self):
        self.assertIsInstance(build_tts(Settings.from_env({"TTS_PROVIDER": "pyttsx3"})), Pyttsx3TTS)


class CliTests(TmpCase):
    def env(self, **extra):
        env = {"STT_PROVIDER": "fake", "LLM_PROVIDER": "fake", "TTS_PROVIDER": "fake", "TMP_DIR": str(self.tmp / "work")}
        env.update(extra)
        return env

    def run_cli(self, argv, env=None, input_fn=input):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = main(argv, environ=env or self.env(), input_fn=input_fn)
        return code, out.getvalue(), err.getvalue()

    def test_typed_text(self):
        code, out, _ = self.run_cli(["--text", "hello", "--no-play"])
        self.assertEqual(code, 0)
        self.assertIn("typed input", out)
        self.assertIn("Assistant: (fake LLM) You said: hello", out)
        self.assertEqual(list((self.tmp / "work").glob("*.wav")), [])  # temp audio cleaned up

    def test_audio_file_with_transcript_correction(self):
        code, out, _ = self.run_cli(["--audio-file", str(self.wav()), "--no-play"], input_fn=lambda prompt: "corrected text")
        self.assertEqual(code, 0)
        self.assertIn("Transcript (speech recognition", out)
        self.assertIn("Assistant: (fake LLM) You said: corrected text", out)

    def test_audio_file_accept_transcript(self):
        code, out, _ = self.run_cli(["--audio-file", str(self.wav()), "--no-play", "--no-confirm"])
        self.assertEqual(code, 0)
        self.assertIn("You said: this is a fake transcript", out)

    def test_bad_audio_file_reports_error(self):
        bad = self.tmp / "bad.wav"
        bad.write_bytes(b"")
        code, out, _ = self.run_cli(["--audio-file", str(bad), "--no-confirm"])
        self.assertEqual(code, 1)
        self.assertIn("audio error", out)

    def test_save_audio(self):
        dest = self.tmp / "saved.wav"
        self.run_cli(["--text", "hi", "--no-play", "--save-audio", str(dest)])
        self.assertTrue(dest.is_file())

    def test_config_error_exit_code(self):
        code, _, err = self.run_cli(["--text", "hi"], env=self.env(STT_PROVIDER="bogus"))
        self.assertEqual(code, 2)
        self.assertIn("Configuration error", err)

    def test_interactive_loop(self):
        lines = iter(["first", "second", "quit"])
        code, out, _ = self.run_cli(["--no-play"], input_fn=lambda prompt: next(lines))
        self.assertEqual(code, 0)
        self.assertIn("You said: first", out)
        self.assertIn("You said: second", out)


if __name__ == "__main__":
    unittest.main()
