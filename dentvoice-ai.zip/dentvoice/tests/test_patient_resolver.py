import pytest
from voiceassistant.patient_resolver import extract_patient_id, resolve, select_from_candidates

P = [
    {"patient_id": "P001", "name": "Priya Sharma", "date_of_birth": "1988-04-12"},
    {"patient_id": "P002", "name": "Priya Sharmila", "date_of_birth": "1991-07-02"},
    {"patient_id": "P003", "name": "Preethi Naik", "date_of_birth": "1979-01-23"},
    {"patient_id": "P004", "name": "Arjun Rao", "date_of_birth": "1985-09-30"},
    {"patient_id": "P005", "name": "Priya Sharma", "date_of_birth": "1995-11-05"},  # duplicate full name
]
NODUP = [p for p in P if p["patient_id"] != "P005"]


@pytest.mark.parametrize("t", ["P001", "p001", "P-001", "P 001", "P 0 0 1", "patient ID P001", "P zero zero one",
                               "p oh oh one", "P double zero one", "get P. 001 please"])
def test_spoken_ids_normalise(t):
    assert extract_patient_id(t) == "P001"


@pytest.mark.parametrize("t", ["Priya", "the second one", "P1", "P 12", "", None, "P001 or P002"])
def test_not_ids(t):
    assert extract_patient_id(t) is None


def test_exact_id():
    r = resolve(P, patient_id="P zero zero three")
    assert r.status == "matched" and r.patient["patient_id"] == "P003"


def test_unknown_id_not_found():
    assert resolve(P, patient_id="P009").status == "not_found"


def test_exact_unique_name():
    r = resolve(NODUP, name="Priya Sharma")
    assert r.status == "matched" and r.patient["patient_id"] == "P001"
    assert resolve(NODUP, name="priya sharmila").patient["patient_id"] == "P002"
    assert resolve(NODUP, name="Priya Sharma's").patient["patient_id"] == "P001"


def test_duplicate_exact_name_is_ambiguous_and_lists_ids():
    r = resolve(P, name="Priya Sharma")
    assert r.status == "ambiguous" and r.patient is None
    assert {p["patient_id"] for p in r.candidates} == {"P001", "P005"}
    assert "P001" in r.message and "P005" in r.message


def test_first_name_only_is_ambiguous():
    r = resolve(NODUP, name="Priya")
    assert r.status == "ambiguous" and len(r.candidates) == 2


def test_nonexistent_name_never_opens_similar_patient():
    r = resolve(P, name="Preethi Sharma")
    assert r.status == "not_found" and r.patient is None
    assert r.message == "I couldn't find a patient named Preethi Sharma. Would you like to try another name or patient ID?"


def test_unique_partial_requires_confirmation_by_default():
    r = resolve(P, name="Naik")
    assert r.status == "needs_confirmation" and r.patient is None
    assert resolve(P, name="Naik", allow_unique_partial=True).status == "matched"


def test_fuzzy_stt_variant_asks_confirmation_never_auto():
    r = resolve(NODUP, name="Preethy Naik")
    assert r.status == "needs_confirmation" and r.patient is None
    assert r.candidates[0]["patient_id"] == "P003"


def test_low_confidence_asks_repeat_even_for_exact_name():
    assert resolve(NODUP, name="Priya Sharma", stt_confidence=0.2).status == "needs_repeat"
    assert resolve(NODUP, patient_id="P001", stt_confidence=0.2).status == "needs_repeat"
    assert resolve(NODUP, name="Priya Sharma", stt_confidence=None).status == "matched"


def test_id_and_name_conflict_needs_confirmation():
    r = resolve(P, name="Preethi Naik", patient_id="P001")
    assert r.status == "needs_confirmation" and r.patient is None


def test_name_with_embedded_spoken_id():
    r = resolve(P, name="patient P zero zero one")
    assert r.status == "matched" and r.patient["patient_id"] == "P001"


def test_empty_query():
    assert resolve(P, name="  ").status == "no_query"


def test_select_ordinal_id_dob_and_failures():
    c = resolve(P, name="Priya Sharma").candidates
    assert select_from_candidates("the first patient", c).patient["patient_id"] == "P001"
    assert select_from_candidates("the second one", c).patient["patient_id"] == "P005"
    assert select_from_candidates("patient ID P zero zero five", c).patient["patient_id"] == "P005"
    assert select_from_candidates("born 1988-04-12", c).patient["patient_id"] == "P001"
    assert select_from_candidates("the third one", c).status == "needs_repeat"          # out of range -> ask again
    assert select_from_candidates("P003", c).status == "needs_repeat"                    # not one of the options
    assert select_from_candidates("hmm", c).status == "needs_repeat"
    assert select_from_candidates("the first", c, stt_confidence=0.1).status == "needs_repeat"
