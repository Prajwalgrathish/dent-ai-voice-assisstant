import struct
import unittest
import wave

from tests.helpers import TmpCase
from voiceassistant.audio import concat_wavs, validate_audio_file, wav_duration
from voiceassistant.errors import AudioValidationError, TTSError

LIMITS = dict(max_bytes=1_000_000, max_seconds=5.0)


class AudioValidationTests(TmpCase):
    def test_valid_wav_passes(self):
        p = validate_audio_file(self.wav(), **LIMITS)
        self.assertTrue(p.is_file())

    def test_missing_file(self):
        with self.assertRaises(AudioValidationError):
            validate_audio_file(self.tmp / "nope.wav", **LIMITS)

    def test_empty_file(self):
        f = self.tmp / "empty.wav"
        f.write_bytes(b"")
        with self.assertRaisesRegex(AudioValidationError, "empty"):
            validate_audio_file(f, **LIMITS)

    def test_unsupported_extension(self):
        f = self.tmp / "x.txt"
        f.write_text("hello")
        with self.assertRaises(AudioValidationError) as ctx:
            validate_audio_file(f, **LIMITS)
        self.assertIn("Unsupported", ctx.exception.user_message)

    def test_content_not_matching_extension(self):
        f = self.tmp / "fake.wav"
        f.write_bytes(b"this is definitely not audio data at all")
        with self.assertRaises(AudioValidationError):
            validate_audio_file(f, **LIMITS)

    def test_too_large(self):
        with self.assertRaisesRegex(AudioValidationError, "too large"):
            validate_audio_file(self.wav(seconds=1.0), max_bytes=1000, max_seconds=5.0)

    def test_too_long(self):
        with self.assertRaisesRegex(AudioValidationError, "too long"):
            validate_audio_file(self.wav(seconds=2.0), max_bytes=10_000_000, max_seconds=1.0)

    def test_too_short(self):
        with self.assertRaisesRegex(AudioValidationError, "too short"):
            validate_audio_file(self.wav(seconds=0.01), **LIMITS)

    def test_silent_wav_rejected(self):
        f = self.tmp / "silent.wav"
        with wave.open(str(f), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(16000)
            w.writeframes(struct.pack("<h", 0) * 8000)
        with self.assertRaisesRegex(AudioValidationError, "silent"):
            validate_audio_file(f, **LIMITS)

    def test_truncated_wav_rejected(self):
        good = self.wav().read_bytes()
        f = self.tmp / "trunc.wav"
        f.write_bytes(good[:20])
        with self.assertRaises(AudioValidationError):
            validate_audio_file(f, **LIMITS)


class ConcatTests(TmpCase):
    def test_concat_adds_durations(self):
        a, b = self.wav("a.wav", seconds=0.2), self.wav("b.wav", seconds=0.3)
        out = self.tmp / "out.wav"
        concat_wavs([a, b], out)
        self.assertAlmostEqual(wav_duration(out), 0.5, places=2)

    def test_concat_mismatched_formats_rejected(self):
        a, b = self.wav("a.wav", rate=16000), self.wav("b.wav", rate=22050)
        with self.assertRaises(TTSError):
            concat_wavs([a, b], self.tmp / "out.wav")

    def test_concat_nothing_rejected(self):
        with self.assertRaises(TTSError):
            concat_wavs([], self.tmp / "out.wav")


if __name__ == "__main__":
    unittest.main()
