
"""Tests for dental patient matching and latest-report retrieval."""

import unittest

from voiceassistant.dental.service import (
    find_patient,
    get_latest_report,
    load_patients,
)
from voiceassistant.dental.service import AmbiguousPatientError, PatientNotFoundError


class DentalServiceTests(unittest.TestCase):
    """Tests against the project's synthetic dental dataset."""

    @classmethod
    def setUpClass(cls):
        cls.patients = load_patients()

    def test_duplicate_patient_name_requires_identifier(self):
        with self.assertRaises(AmbiguousPatientError):
            find_patient(name="Priya Sharma")

    def test_dob_disambiguates_duplicate_patient_name(self):
        patient = find_patient(
            name="Priya Sharma",
            date_of_birth="1995-04-12",
        )
        self.assertEqual(patient["patient_id"], "P001")

    def test_patient_id_identifies_correct_patient(self):
        patient = find_patient(patient_id="P003")
        self.assertEqual(patient["name"], "Arjun Rao")

    def test_wrong_dob_does_not_match_patient(self):
        with self.assertRaises(PatientNotFoundError):
            find_patient(
                name="Priya Sharma",
                date_of_birth="1900-01-01",
            )

    def test_unknown_patient_is_not_matched(self):
        with self.assertRaises(PatientNotFoundError):
            find_patient(name="Fake Person")

    def test_latest_report_is_returned_for_unique_patient(self):
        result = get_latest_report(name="Arjun Rao")

        self.assertEqual(result["patient_id"], "P003")
        self.assertEqual(result["patient_name"], "Arjun Rao")
        self.assertTrue(result["report"])
        self.assertTrue(result["synthetic_data"])

    def test_opg_report_can_be_requested_by_type(self):
        result = get_latest_report(
            name="Arjun Rao",
            report_type="OPG",
        )

        self.assertEqual(result["patient_id"], "P003")
        self.assertTrue(result["report"])
        self.assertIn("opg", str(result["report"]).lower())

    def test_duplicate_name_can_be_resolved_using_patient_id(self):
        patient = find_patient(
            name="Priya Sharma",
            patient_id="P001",
        )
        self.assertEqual(patient["patient_id"], "P001")


if __name__ == "__main__":
    unittest.main()

