"""Hands-free voice workflow: greeting, speaking/listening state, idle timeout, resume, clarification persistence,
plain-English explanations and patient-data freshness.

Real-browser behaviour (playback, capture, the 15 s idle timer) is covered in tests/browser. These tests cover the
Python side: the Streamlit app reacts ONLY to events the browser reports, and keeps conversation state across them.
The microphone component is replaced by a scripted stand-in that returns exactly what the real one would send.
"""

from __future__ import annotations

import base64
import json
import os
import socket
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from tests.helpers import FakeLLM, FakeSTT, FakeTTS, TmpCase
from voiceassistant.config import CLARIFICATION_TIMEOUT_SECONDS, SILENCE_TIMEOUT_SECONDS
from voiceassistant.speech_cleaner import clean_text_for_speech
from voiceassistant.voice_commands import day_part, greeting_for_hour, is_listen_command

try:
    import httpx  # noqa: F401
    import multipart  # noqa: F401
    import uvicorn
    from streamlit.testing.v1 import AppTest

    import dentvoice_mic
    from voiceassistant.api import create_app

    HAVE_DEPS = True
except ImportError:
    HAVE_DEPS = False

APP = str(Path(__file__).resolve().parent.parent / "frontend" / "app.py")


# ───────────────────────────── pure logic ─────────────────────────────
class GreetingByLocalTimeTests(unittest.TestCase):
    def test_wording_for_each_part_of_the_day(self):
        self.assertEqual(greeting_for_hour(9), "Good morning, Doctor. Welcome to DentVoice AI. How can I help you?")
        self.assertEqual(greeting_for_hour(14), "Good afternoon, Doctor. How can I help you?")
        self.assertEqual(greeting_for_hour(19), "Good evening, Doctor. How can I help you?")
        self.assertEqual(greeting_for_hour(23), "Hello, Doctor. How can I help you tonight?")

    def test_boundaries(self):
        expected = {4: "night", 5: "morning", 11: "morning", 12: "afternoon", 16: "afternoon",
                    17: "evening", 20: "evening", 21: "night", 0: "night"}
        for hour, part in expected.items():
            self.assertEqual(day_part(hour), part, hour)

    def test_greeting_is_not_hard_coded(self):
        self.assertEqual(len({greeting_for_hour(h) for h in range(24)}), 4)


class ListenCommandTests(unittest.TestCase):
    def test_accepted_phrases(self):
        for phrase in ("Listen to me", "listen to me.", "Start listening", "Listen", "Please start listening",
                       "DentVoice, listen to me", "Resume listening", "Listen to me, Doctor!"):
            self.assertTrue(is_listen_command(phrase), phrase)

    def test_only_whole_utterances_count(self):
        for phrase in ("listen to the patient history", "I will listen to me later", "listening", "Listen carefully to P001",
                       "Show me Priya Sharma's reports", "", None):
            self.assertFalse(is_listen_command(phrase), phrase)


class SingleComponentCopyTests(unittest.TestCase):
    """`streamlit run frontend\\app.py` puts frontend/ first on sys.path. A second copy of the component there would
    silently shadow the real one (it did: edits to the other copy had no effect)."""

    def test_there_is_exactly_one_component_package(self):
        root = Path(__file__).resolve().parent.parent
        found = [p for p in root.rglob("dentvoice_mic") if p.is_dir() and ".venv" not in str(p) and "__pycache__" not in str(p)]
        self.assertEqual(found, [root / "dentvoice_mic"], found)

    def test_streamlit_style_import_order_sees_the_current_component(self):
        import importlib
        import sys
        root = Path(__file__).resolve().parent.parent
        saved_path, saved_mod = list(sys.path), sys.modules.pop("dentvoice_mic", None)
        try:
            sys.path[:] = [str(root / "frontend"), str(root)] + [p for p in saved_path if p not in (str(root), str(root / "frontend"))]
            mod = importlib.import_module("dentvoice_mic")
            self.assertTrue(hasattr(mod, "PlaybackEvent") and hasattr(mod, "dentvoice_mic_events"))
            self.assertEqual(Path(mod.__file__).resolve().parent, root / "dentvoice_mic")
        finally:
            sys.path[:] = saved_path
            sys.modules.pop("dentvoice_mic", None)
            if saved_mod is not None:
                sys.modules["dentvoice_mic"] = saved_mod


# ───────────────────────────── Python state machine ─────────────────────────────
class EventDrivenStateTests(unittest.TestCase):
    def setUp(self):
        import streamlit as st
        from frontend.sections.assistant import _init
        st.session_state.clear()
        _init()
        self.st = st

    def ev(self, kind, **kw):
        from dentvoice_mic import _parse
        return _parse({"type": kind, "id": f"t-{time.time_ns()}", **kw})

    def test_speaking_requires_the_browser_to_report_playback(self):
        from frontend.sections.assistant import _apply_event, _queue_reply_audio, _voice_status
        _queue_reply_audio(b"RIFF....WAVE" + b"\0" * 64, is_clarification=False, audio_id="r1")
        self.assertEqual(_voice_status()[0], "idle", "audio exists but nothing is playing yet")
        _apply_event(self.ev("playback", audio_id="r1", state="started"))
        self.assertEqual(_voice_status(), ("speaking", "Speaking…"))
        _apply_event(self.ev("playback", audio_id="r1", state="ended"))
        self.assertNotEqual(_voice_status()[0], "speaking", "indicator clears as soon as playback ends")
        self.assertIsNone(self.st.session_state.dv_audio)
        self.assertIn("r1", self.st.session_state.dv_audio_done)

    def test_failed_playback_is_explicit_and_never_speaking(self):
        from frontend.sections.assistant import _apply_event, _queue_reply_audio, _voice_status
        _queue_reply_audio(b"RIFF....WAVE" + b"\0" * 64, audio_id="r2")
        _apply_event(self.ev("playback", audio_id="r2", state="failed", message="decode error"))
        self.assertNotEqual(_voice_status()[0], "speaking")
        self.assertIn("could not be played", self.st.session_state.timeout_message)
        self.assertIn("decode error", self.st.session_state.timeout_message)
        self.assertIsNone(self.st.session_state.dv_audio)

    def test_blocked_autoplay_keeps_audio_queued_and_offers_recovery(self):
        from frontend.sections.assistant import _apply_event, _queue_reply_audio, _voice_status
        _queue_reply_audio(b"RIFF....WAVE" + b"\0" * 64, audio_id="greeting")
        _apply_event(self.ev("playback", audio_id="greeting", state="blocked"))
        self.assertTrue(self.st.session_state.dv_audio_blocked)
        self.assertIsNotNone(self.st.session_state.dv_audio, "stays queued so the 'enable audio' tap can play it")
        self.assertNotEqual(_voice_status()[0], "speaking")
        self.assertNotIn("greeting", self.st.session_state.dv_audio_done)

    def test_enabling_the_microphone_means_listening_not_speaking(self):
        from frontend.sections.assistant import _apply_event, _voice_status
        _apply_event(self.ev("action", action="resume"))
        self.assertEqual(_voice_status(), ("listening", "Listening…"))

    def test_clarification_is_labelled_but_never_depends_on_speaking(self):
        from frontend.sections.assistant import _apply_event, _voice_status
        self.st.session_state.is_clarification = True
        _apply_event(self.ev("action", action="resume"))
        self.assertEqual(_voice_status(), ("listening", "Listening for your answer…"))
        _apply_event(self.ev("playback", audio_id="x", state="started"))
        self.assertEqual(_voice_status()[0], "speaking")
        _apply_event(self.ev("playback", audio_id="x", state="ended"))
        self.assertEqual(_voice_status()[0], "listening", "back to listening the moment audio ends")

    def test_no_server_side_wall_clock_timers_remain(self):
        for key in ("speaking_ends_at", "timer_expires_at", "voice_state", "voice_mode_enabled", "greeting_spoken"):
            self.assertNotIn(key, self.st.session_state)

    def test_idle_timeout_and_pause_reports(self):
        from frontend.sections.assistant import _apply_event, _voice_status
        _apply_event(self.ev("action", action="resume"))
        _apply_event(self.ev("action", action="idle_timeout"))
        self.assertEqual(_voice_status()[0], "standby")
        self.assertIn(f"{SILENCE_TIMEOUT_SECONDS} seconds", self.st.session_state.timeout_message)
        _apply_event(self.ev("action", action="resume"))
        _apply_event(self.ev("action", action="pause"))
        self.assertEqual(_voice_status()[0], "paused")

    def test_replayed_events_are_applied_once(self):
        from frontend.sections.assistant import _mark_seen
        self.assertTrue(_mark_seen("a-1"))
        self.assertFalse(_mark_seen("a-1"))
        self.assertTrue(_mark_seen("a-2"))


# ───────────────────────────── Streamlit app, scripted microphone ─────────────────────────────
def _free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class ScriptedMic:
    """Stands in for the browser component: returns what the real one would, and records what the app sent it."""

    def __init__(self):
        self.events: list[dict] = []
        self.calls: list[dict] = []
        self._n = 0

    def __call__(self, **kwargs):
        self.calls.append(kwargs)
        return {"events": list(self.events)} if self.events else None

    @property
    def last(self) -> dict:
        return self.calls[-1]

    def send(self, kind, **kw):
        self._n += 1
        self.events.append({"type": kind, "id": f"s-{self._n}", **kw})

    def action(self, name):
        self.send("action", action=name)

    def playback(self, audio_id, state, message=""):
        self.send("playback", audio_id=audio_id, state=state, message=message)

    def utterance(self, wav: bytes):
        self.send("utterance", wav_b64=base64.b64encode(wav).decode(), duration_s=1.0, sample_rate=16000)


def _wav(seconds=0.5) -> bytes:
    import io
    import struct
    import wave
    buf = io.BytesIO()
    w = wave.open(buf, "wb")
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
    w.writeframes(struct.pack("<h", 1000) * int(16000 * seconds))
    w.close()
    return buf.getvalue()


@unittest.skipUnless(HAVE_DEPS, "streamlit AppTest / uvicorn not installed")
class AssistantVoiceWorkflowIntegration(TmpCase):
    def setUp(self):
        super().setUp()
        self.stt, self.llm, self.tts = FakeSTT(), FakeLLM(), FakeTTS()
        pipeline, *_ = self.pipeline(stt=self.stt, llm=self.llm, tts=self.tts)
        self.port = _free_port()
        self.server = uvicorn.Server(uvicorn.Config(create_app(pipeline), host="127.0.0.1", port=self.port, log_level="error"))
        self.thread = threading.Thread(target=self.server.run, daemon=True)
        self.thread.start()
        for _ in range(100):
            if self.server.started:
                break
            time.sleep(0.05)
        self.assertTrue(self.server.started, "backend did not start")
        self.addCleanup(self._stop)
        os.environ["DENTVOICE_API_URL"] = f"http://127.0.0.1:{self.port}"
        self.addCleanup(os.environ.pop, "DENTVOICE_API_URL", None)
        self.mic = ScriptedMic()
        patcher = mock.patch.object(dentvoice_mic, "_component", self.mic)
        patcher.start()
        self.addCleanup(patcher.stop)

    def _stop(self):
        self.server.should_exit = True
        self.thread.join(timeout=5)

    # helpers
    def app(self):
        at = AppTest.from_file(APP, default_timeout=30)
        at.run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        return at

    def rerun(self, at):
        at.run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        return at

    def say(self, at, text):
        at.chat_input[0].set_value(text).run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        return at

    @staticmethod
    def markdown(at) -> str:
        return " ".join(m.value for m in at.markdown)

    @staticmethod
    def last_reply(at) -> str:
        return at.session_state["chat"][-1]["text"]

    # ---- greeting ----
    def test_greeting_is_created_once_and_never_repeated_by_rerenders_navigation_or_mic_toggles(self):
        at = self.app()
        greetings = [m for m in at.session_state["chat"] if m.get("is_greeting")]
        self.assertEqual(len(greetings), 1)
        self.assertEqual(self.mic.last["audio"]["id"], "greeting")
        self.assertNotIn("Speaking", self.markdown(at), "nothing is playing yet, so nothing may claim to be speaking")
        self.mic.playback("greeting", "started")
        self.rerun(at)
        self.assertIn("Speaking…", self.markdown(at))
        self.mic.playback("greeting", "ended")
        self.rerun(at)
        self.assertNotIn("Speaking", self.markdown(at))
        self.assertIsNone(self.mic.last["audio"], "consumed audio is not sent again")
        self.assertIn("greeting", self.mic.last["done_ids"])
        for event in ("pause", "resume", "idle_timeout", "resume"):
            self.mic.action(event)
            self.rerun(at)
        self.rerun(at)
        next(r for r in at.radio if r.key == "nav").set_value("Patient Reports").run()
        next(r for r in at.radio if r.key == "nav").set_value("AI Assistant").run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        self.assertEqual(len([m for m in at.session_state["chat"] if m.get("is_greeting")]), 1)
        self.assertIsNone(self.mic.last["audio"])
        self.assertEqual(len(self.tts.calls), 1, "the greeting was synthesised exactly once")

    def test_greeting_uses_the_browsers_local_time_when_known(self):
        """Uses the browser's UTC offset (no time-zone database needed, which Windows Python lacks)."""
        from datetime import datetime, timedelta, timezone
        from streamlit.runtime.context import ContextProxy
        for offset_minutes in (660, -780):                      # UTC-11 and UTC+13: 24 hours apart
            self.mic.calls.clear()
            with mock.patch.object(ContextProxy, "timezone_offset", new_callable=mock.PropertyMock, return_value=offset_minutes):
                at = self.app()
            allowed = {greeting_for_hour((datetime.now(timezone.utc) - timedelta(minutes=offset_minutes + d)).hour) for d in (-1, 0, 1)}
            self.assertIn(at.session_state["chat"][0]["text"], allowed, offset_minutes)
        self.assertEqual(self.tts.calls[-1], at.session_state["chat"][0]["text"])

    def test_local_hour_falls_back_to_the_server_clock_when_the_browser_gives_nothing(self):
        from datetime import datetime
        from streamlit.runtime.context import ContextProxy
        from frontend.sections.assistant import _local_hour
        with mock.patch.object(ContextProxy, "timezone_offset", new_callable=mock.PropertyMock, return_value=None), \
                mock.patch.object(ContextProxy, "timezone", new_callable=mock.PropertyMock, return_value=None):
            self.assertIn(_local_hour(), {datetime.now().hour, (datetime.now().hour - 1) % 24})

    # ---- speaking / listening indicators ----
    def test_enabling_the_microphone_shows_listening_and_never_speaking(self):
        at = self.app()
        self.mic.playback("greeting", "ended")
        self.mic.action("resume")
        self.rerun(at)
        self.assertIn("Listening…", self.markdown(at))
        self.assertNotIn("Speaking", self.markdown(at))
        self.assertNotIn("TTS Active", self.markdown(at))

    def test_playback_failure_and_browser_block_are_reported_with_a_way_to_recover(self):
        at = self.app()
        self.mic.playback("greeting", "blocked")
        self.rerun(at)
        self.assertTrue(at.session_state["dv_audio_blocked"])
        self.assertTrue(any("blocked automatic audio" in w.value for w in at.warning))
        self.assertIsNotNone(self.mic.last["audio"], "still queued for the one-tap enable-audio control")
        self.assertNotIn("Speaking", self.markdown(at))
        self.mic.playback("greeting", "started")
        self.mic.playback("greeting", "failed", "decode error")
        self.rerun(at)
        self.assertNotIn("Speaking", self.markdown(at))
        self.assertTrue(any("could not be played" in i.value for i in at.info))

    def test_clarification_state_is_independent_of_speaking_and_needs_no_countdown(self):
        at = self.app()
        self.say(at, "Show me Priya Sharma's reports")
        self.assertTrue(self.mic.last["clarify"])
        self.assertEqual(self.mic.last["clarify_timeout_ms"], CLARIFICATION_TIMEOUT_SECONDS * 1000)
        self.mic.playback(self.mic.last["audio"]["id"], "started")
        self.mic.playback(self.mic.last["audio"]["id"], "ended")
        self.mic.action("resume")
        self.rerun(at)
        self.assertIn("Listening for your answer…", self.markdown(at))
        self.assertNotIn("Speaking", self.markdown(at))
        self.assertNotIn("remaining", self.markdown(at) + " ".join(c.value for c in at.caption),
                         "no server countdown that could outlive the audio")

    # ---- idle timeout & resume ----
    def test_idle_timeout_report_stops_listening_but_keeps_everything(self):
        at = self.app()
        self.say(at, "Open Priya's latest OPG report")             # ambiguous -> pending clarification
        pending = at.session_state["pending_report_name"]
        self.assertTrue(pending)
        chat_len = len(at.session_state["chat"])
        self.mic.action("resume"); self.rerun(at)
        self.mic.action("idle_timeout"); self.rerun(at)
        self.assertIn(f"Stopped after {SILENCE_TIMEOUT_SECONDS} seconds of silence", self.markdown(at))
        self.assertEqual(at.session_state["pending_report_name"], pending)
        self.assertEqual(len(at.session_state["chat"]), chat_len)
        self.assertFalse(self.mic.last["auto_start"], "after an idle stop the browser must not restart by itself")
        self.assertTrue(self.mic.last["standby"])
        self.assertEqual(self.mic.last["idle_timeout_ms"], SILENCE_TIMEOUT_SECONDS * 1000)
        self.assertEqual(SILENCE_TIMEOUT_SECONDS, 15)

    def test_resume_button_asks_the_browser_to_restart_once(self):
        at = self.app()
        self.mic.action("idle_timeout"); self.rerun(at)
        before = self.mic.last["resume_nonce"]
        next(b for b in at.button if b.key == "btn_enable_voice").click().run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        self.assertEqual(self.mic.last["resume_nonce"], before + 1)
        self.assertFalse(self.mic.last["standby"])
        self.assertNotIn("Listening…", self.markdown(at), "not 'Listening' until the browser reports capture is running")
        self.mic.action("resume"); self.rerun(at)
        self.assertIn("Listening…", self.markdown(at))
        self.assertEqual(self.mic.last["resume_nonce"], before + 1, "reruns do not re-trigger the resume")

    # ---- "Listen to me" ----
    def test_typed_listen_to_me_resumes_without_greeting_llm_or_losing_pending_clarification(self):
        at = self.app()
        self.say(at, "Show me Priya Sharma's reports")
        pending = at.session_state["pending_report_name"]
        self.mic.action("idle_timeout"); self.rerun(at)
        llm_calls, tts_calls = len(self.llm.calls), len(self.tts.calls)
        before = self.mic.last["resume_nonce"]
        self.say(at, "Listen to me")
        self.assertEqual(self.mic.last["resume_nonce"], before + 1)
        self.assertFalse(self.mic.last["standby"])
        self.assertEqual(at.session_state["pending_report_name"], pending, "pending clarification preserved")
        self.assertEqual(len(self.llm.calls), llm_calls, "a voice command never goes to the language model")
        self.assertEqual(len(self.tts.calls), tts_calls, "and does not re-speak a greeting")
        self.assertEqual(len([m for m in at.session_state["chat"] if m.get("is_greeting")]), 1)
        self.assertIn("Resuming the microphone", self.last_reply(at))
        self.assertIn("Priya Sharma", self.last_reply(at), "reminds which question is still open")

    def test_spoken_listen_to_me_while_listening_is_acknowledged_not_answered_by_the_llm(self):
        at = self.app()
        self.mic.action("resume"); self.rerun(at)
        self.stt.text = "Listen to me"
        llm_calls = len(self.llm.calls)
        self.mic.utterance(_wav()); self.rerun(at)
        self.assertEqual(len(self.llm.calls), llm_calls)
        self.assertIn("I'm listening", self.last_reply(at))

    def test_listen_variants_are_not_taken_as_patient_answers(self):
        at = self.app()
        self.say(at, "Show me Priya Sharma's reports")
        for phrase in ("Start listening", "Listen"):
            self.say(at, phrase)
            self.assertIsNone(at.session_state["active_patient"])
            self.assertTrue(at.session_state["pending_report_name"])

    # ---- patient ambiguity & clarification across microphone restarts ----
    def test_duplicate_names_ask_then_resolve_with_patient_id_after_microphone_restarts(self):
        at = self.app()
        self.say(at, "Show me Priya Sharma's reports")
        self.assertIsNone(at.session_state["active_patient"], "must not pick a patient arbitrarily")
        self.assertIsNone(at.session_state["active_report"], "and must not expose either report")
        self.assertIn("Multiple patients match that name.", self.last_reply(at))   # generic: no IDs, names or dates of birth
        self.assertNotIn("P001", self.last_reply(at))
        self.assertNotIn("1995", self.last_reply(at))
        for event in ("resume", "pause", "resume", "idle_timeout", "resume"):   # microphone off / on / timeout / on
            self.mic.action(event); self.rerun(at)
        self.assertEqual(at.session_state["pending_report_name"], "Priya Sharma")
        self.say(at, "Patient ID is P001")
        self.assertEqual(at.session_state["active_patient"]["patient_id"], "P001")
        self.assertEqual(at.session_state["active_report"]["report"]["report_id"], "R002", "P001's latest report")
        self.assertIsNone(at.session_state["pending_report_name"])
        self.assertFalse(self.mic.last["clarify"])

    def test_spoken_clarification_after_restart_resolves_the_original_request(self):
        at = self.app()
        self.say(at, "Show me Priya Sharma's reports")
        self.mic.action("idle_timeout"); self.rerun(at)
        self.mic.action("resume"); self.rerun(at)
        self.stt.text = "Patient ID is P 0 0 2."
        self.mic.utterance(_wav()); self.rerun(at)
        self.assertEqual(at.session_state["active_patient"]["patient_id"], "P002")
        self.assertEqual(at.session_state["active_report"]["report"]["report_id"], "R004", "P002's latest report")

    def test_invalid_id_and_unresolved_ambiguity_ask_again_without_guessing(self):
        at = self.app()
        self.say(at, "Show me Priya Sharma's reports")
        self.say(at, "Patient ID is P999")
        self.assertIsNone(at.session_state["active_patient"])
        self.assertEqual(at.session_state["pending_report_name"], "Priya Sharma", "request still pending")
        self.assertTrue(self.mic.last["clarify"])
        self.say(at, "Priya Sharma")
        self.assertIsNone(at.session_state["active_patient"])
        self.assertTrue(at.session_state["pending_report_name"])
        self.assertIn("Priya Sharma", self.last_reply(at))
        self.say(at, "Patient ID is P001")
        self.assertEqual(at.session_state["active_patient"]["patient_id"], "P001")

    def test_pronoun_followup_uses_the_identified_patient(self):
        at = self.app()
        self.say(at, "Show me Priya Sharma's reports")
        self.say(at, "Patient ID is P002")
        self.say(at, "Give her reports")
        self.assertNotIn("Which patient", self.last_reply(at))
        self.assertEqual(at.session_state["active_patient"]["patient_id"], "P002")
        self.assertIn("P002", self.last_reply(at))

    def test_pronoun_without_a_known_patient_asks_and_the_answer_completes_the_request(self):
        at = self.app()
        self.say(at, "Give her reports")
        self.assertIn("Which patient", self.last_reply(at))
        self.say(at, "P003")
        self.assertEqual(at.session_state["active_patient"]["patient_id"], "P003")

    def test_empty_audio_is_never_submitted_as_a_request(self):
        at = self.app()
        chat_len = len(at.session_state["chat"])
        llm_calls = len(self.llm.calls)
        self.mic.send("utterance", wav_b64=base64.b64encode(b"RIFF").decode(), duration_s=0.0, sample_rate=16000)
        self.rerun(at)
        self.assertEqual(len(at.session_state["chat"]), chat_len)
        self.assertEqual(len(self.llm.calls), llm_calls)
        self.assertIsNone(at.session_state["dv_mic_error"])

    def test_denied_microphone_permission_is_explained_and_recoverable(self):
        at = self.app()
        self.mic.send("error", code="permission_denied", message="Microphone access is blocked. Click the lock icon.")
        self.rerun(at)
        self.assertIn("Microphone problem", self.markdown(at))
        self.assertTrue(any("blocked" in i.value for i in at.info))
        next(b for b in at.button if b.key == "btn_enable_voice").click().run()
        self.mic.action("resume"); self.rerun(at)
        self.assertIn("Listening…", self.markdown(at))
        self.assertIsNone(at.session_state["dv_mic_error"])

    # ---- plain-English explanation in the AI Assistant ----
    def test_doctor_asks_for_a_plain_english_explanation_of_the_loaded_report(self):
        at = self.app()
        self.say(at, "Open Priya's latest OPG report")
        self.say(at, "Patient ID is P001")
        llm_calls = len(self.llm.calls)
        self.say(at, "Explain her report in simple English")
        text = self.last_reply(at)
        self.assertEqual(len(self.llm.calls), llm_calls, "explanations are built from the report, not invented by a model")
        self.assertIn("In plain English", text)
        self.assertIn("wisdom tooth", text)
        self.assertIn("stuck under the gum", text)
        self.assertIn("What isn't known from the report", text)
        self.assertIn("Clinician review is required", text)
        for invented in ("infection", "cancer", "abscess", "must be removed", "surgery is needed"):
            self.assertNotIn(invented, text.lower())
        self.assertEqual(self.tts.calls[-1], clean_text_for_speech(text), "spoken and written explanation are the same text")

    def test_general_dental_term_questions_still_go_to_the_assistant_not_the_report(self):
        at = self.app()
        self.say(at, "Open Priya's latest OPG report")
        self.say(at, "Patient ID is P001")
        llm_calls = len(self.llm.calls)
        self.say(at, "What are molar teeth?")
        self.assertEqual(len(self.llm.calls), llm_calls + 1)


# ───────────────────────────── plain-English report explanations (backend) ─────────────────────────────
@unittest.skipUnless(HAVE_DEPS, "fastapi test deps not installed")
class PatientPlainEnglishExplanationTests(TmpCase):
    def setUp(self):
        super().setUp()
        from fastapi.testclient import TestClient
        self.tts = FakeTTS()
        pipeline, *_ = self.pipeline(tts=self.tts)
        self.client = TestClient(create_app(pipeline))
        self.addCleanup(self.client.close)

    def ask(self, pid, text, speak=False):
        token = self.client.post("/v1/patient/session", json={"patient_id": pid}).json()["session_token"]
        r = self.client.post("/v1/patient/chat", json={"message": text, "speak": speak}, headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(r.status_code, 200, r.text)
        return r.json()

    def kinds(self, body):
        return [s["kind"] for s in body["sections"]]

    def test_explanation_has_plain_meaning_general_and_uncertainty_parts_kept_apart(self):
        body = self.ask("P001", "Explain my OPG report")
        kinds = self.kinds(body)
        for needed in ("documented", "plain", "general", "uncertain"):
            self.assertIn(needed, kinds)
        by = {s["kind"]: s["text"] for s in body["sections"] if s["kind"] != "note"}
        documented = " ".join(s["text"] for s in body["sections"] if s["kind"] == "documented").lower()
        self.assertIn("impacted lower left third molar", documented, "verbatim report text stays documented")
        self.assertIn("wisdom tooth", by["plain"])
        self.assertIn("lower left", by["plain"])
        self.assertIn("stuck under the gum", by["plain"])
        self.assertTrue(by["general"].startswith("In general"))
        self.assertIn("not a statement that anything is wrong", by["general"], "explains the significance without over-claiming")
        self.assertIn("can sometimes", by["general"], "possible implications are hedged")
        self.assertIn("doesn't say", by["uncertain"])
        self.assertIn("whether any treatment is needed", by["uncertain"])
        self.assertNotIn("you have", body["answer"].lower())

    def test_it_does_not_invent_findings_diagnoses_or_treatment(self):
        for pid, text in (("P001", "Explain my OPG report"), ("P001", "Explain my dental examination"),
                          ("P002", "Explain my report"), ("P006", "Explain my report")):
            answer = self.ask(pid, text)["answer"].lower()
            for banned in ("cancer", "infection", "abscess", "root canal", "extract", "antibiotic", "you need", "surgery", "diagnos"):
                if banned == "diagnos":
                    self.assertNotIn("you have been diagnosed", answer)
                    continue
                self.assertNotIn(banned, answer, f"{pid}: {banned!r}")

    def test_gum_finding_is_explained_in_everyday_words(self):
        body = self.ask("P001", "Explain my dental examination report")
        by = {s["kind"]: s["text"] for s in body["sections"]}
        self.assertIn("red or swollen", by["plain"])
        self.assertIn("mildly", by["plain"])
        self.assertIn("plaque", by["general"])

    def test_clear_report_is_not_turned_into_a_problem(self):
        body = self.ask("P002", "Explain my OPG report")
        by = {s["kind"]: s["text"] for s in body["sections"]}
        self.assertIn("nothing unusual or urgent", by["plain"])
        self.assertIn("not a promise", by["general"])
        self.assertNotIn("impacted", body["answer"].lower())

    def test_placeholder_report_says_it_cannot_explain_more(self):
        body = self.ask("P006", "Explain my report")
        by = {s["kind"]: s["text"] for s in body["sections"]}
        self.assertIn("does not describe a specific problem", by["plain"])
        self.assertIn("can't say more", by["uncertain"])

    def test_written_and_spoken_answers_are_the_same_text(self):
        before = len(self.tts.calls)
        body = self.ask("P001", "Explain my OPG report", speak=True)
        self.assertTrue(body["audio_wav_base64"])
        spoken = " ".join(self.tts.calls[before:])        # long answers are synthesised in chunks
        norm = lambda t: " ".join(t.split())              # noqa: E731
        self.assertEqual(norm(spoken), norm(clean_text_for_speech(body["answer"])), "what is spoken is the written answer")
        sections_text = "\n\n".join(s["text"] for s in body["sections"])
        self.assertEqual(body["answer"], sections_text, "everything shown is in the answer; the answer is what is spoken")

    def test_simple_english_followup_is_shorter_but_keeps_the_same_parts(self):
        token = self.client.post("/v1/patient/session", json={"patient_id": "P001"}).json()["session_token"]
        h = {"Authorization": f"Bearer {token}"}
        full = self.client.post("/v1/patient/chat", json={"message": "Explain my OPG report"}, headers=h).json()
        simple = self.client.post("/v1/patient/chat", json={"message": "Can you explain this in simple English?"}, headers=h).json()
        self.assertIn("uncertain", self.kinds(simple))
        self.assertIn("plain", self.kinds(simple))
        self.assertLessEqual(len(simple["answer"]), len(full["answer"]) + 120)


# ───────────────────────────── patient lookup is never stale ─────────────────────────────
class PatientLookupFreshnessTests(TmpCase):
    def test_lookup_reads_the_current_data_file_every_time(self):
        from voiceassistant.dental import service
        data = json.loads(Path(service.DATA_PATH).read_text(encoding="utf-8"))
        copy = self.tmp / "patients.json"
        copy.write_text(json.dumps(data), encoding="utf-8")
        with mock.patch.object(service, "DATA_PATH", copy):
            with self.assertRaises(service.PatientNotFoundError):
                service.get_latest_report(patient_id="P007")
            new = {"patient_id": "P007", "name": "Test Person", "date_of_birth": "1990-01-01",
                   "phone_contact": "DEMO-0007",
                   "reports": [{"report_id": "R099", "type": "OPG", "date": "2026-10-01", "findings": ["Synthetic example."], "impression": None}]}
            copy.write_text(json.dumps(data + [new]), encoding="utf-8")        # edited while "the backend keeps running"
            result = service.get_latest_report(patient_id="P007")
            self.assertEqual(result["report"]["report_id"], "R099")

    def test_p006_and_both_priya_sharma_records_resolve(self):
        from voiceassistant.dental import service
        self.assertEqual(service.get_latest_report(patient_id="P006")["patient_name"], "Priya Naik")
        candidates = service.list_patient_candidates("Priya Sharma")
        self.assertEqual({c["patient_id"] for c in candidates}, {"P001", "P002"})
        self.assertEqual(service.get_latest_report(patient_id="P001")["report"]["report_id"], "R002")
        self.assertEqual(service.get_latest_report(patient_id="P002")["report"]["report_id"], "R004")
        with self.assertRaises(service.AmbiguousPatientError):
            service.get_latest_report(name="Priya Sharma")

    def test_new_backend_process_serves_p006_from_the_same_file(self):
        from fastapi.testclient import TestClient
        pipeline, *_ = self.pipeline()
        with TestClient(create_app(pipeline)) as c:
            r = c.post("/v1/patient/session", json={"patient_id": "P006"})
            self.assertEqual(r.status_code, 200)
            self.assertEqual(r.json()["patient"]["first_name"], "Priya")


if __name__ == "__main__":
    unittest.main()
