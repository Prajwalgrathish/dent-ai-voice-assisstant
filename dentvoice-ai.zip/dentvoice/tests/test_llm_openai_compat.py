"""Tests the OpenAI-compatible adapter against a local stub HTTP server (not a real LLM)."""

import json
import socket
import threading
import time
import unittest
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest import mock

from voiceassistant.errors import (
    LLMConnectionError,
    LLMError,
    LLMRateLimitError,
    LLMResponseError,
    LLMServerError,
    LLMTimeoutError,
)
from voiceassistant.providers.llm_openai_compat import OpenAICompatLLM

OK_BODY = {"choices": [{"message": {"role": "assistant", "content": "  Hello from stub.  "}}]}
MESSAGES = [{"role": "system", "content": "sys"}, {"role": "user", "content": "hi"}]


def reply(status=200, body=None, headers=None, delay=0.0):
    def action(handler):
        if delay:
            time.sleep(delay)
        raw = body if isinstance(body, bytes) else json.dumps(body if body is not None else {}).encode()
        try:
            handler.send_response(status)
            handler.send_header("Content-Type", "application/json")
            for k, v in (headers or {}).items():
                handler.send_header(k, v)
            handler.send_header("Content-Length", str(len(raw)))
            handler.end_headers()
            handler.wfile.write(raw)
        except OSError:
            pass  # client already gave up (timeout test)

    return action


class _Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        self.server.requests.append(
            {"path": self.path, "headers": {k.lower(): v for k, v in self.headers.items()}, "body": json.loads(body)}
        )
        script = self.server.script
        (script.pop(0) if len(script) > 1 else script[0])(self)

    def log_message(self, *args):
        pass


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False

    def handle_error(self, request, client_address):
        pass


class LLMAdapterTests(unittest.TestCase):
    def serve(self, *script):
        server = _Server(("127.0.0.1", 0), _Handler)
        server.requests, server.script = [], list(script)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(lambda: (server.shutdown(), server.server_close()))
        self.sleeps = []
        self.base_url = f"http://127.0.0.1:{server.server_address[1]}/v1"
        return server

    def llm(self, **kw):
        kw.setdefault("timeout_s", 5.0)
        kw.setdefault("max_retries", 2)
        return OpenAICompatLLM(self.base_url, "test-model", sleep=self.sleeps.append, **kw)

    def test_success_and_request_shape(self):
        server = self.serve(reply(200, OK_BODY))
        text = self.llm(temperature=0.1, max_tokens=50).complete(MESSAGES)
        self.assertEqual(text, "Hello from stub.")
        req = server.requests[0]
        self.assertEqual(req["path"], "/v1/chat/completions")
        self.assertEqual(req["body"]["model"], "test-model")
        self.assertEqual(req["body"]["messages"], MESSAGES)
        self.assertEqual((req["body"]["temperature"], req["body"]["max_tokens"], req["body"]["stream"]), (0.1, 50, False))
        self.assertNotIn("authorization", req["headers"])  # no key configured (local Ollama style)

    def test_api_key_sent_as_bearer(self):
        server = self.serve(reply(200, OK_BODY))
        self.llm(api_key="sk-test-123").complete(MESSAGES)
        self.assertEqual(server.requests[0]["headers"]["authorization"], "Bearer sk-test-123")

    def test_rate_limit_then_success_retries_with_retry_after(self):
        server = self.serve(reply(429, {"error": "slow"}, {"Retry-After": "2"}), reply(200, OK_BODY))
        self.assertEqual(self.llm().complete(MESSAGES), "Hello from stub.")
        self.assertEqual(len(server.requests), 2)
        self.assertEqual(self.sleeps, [2.0])

    def test_rate_limit_exhausted_is_bounded(self):
        server = self.serve(reply(429, {}))
        with self.assertRaises(LLMRateLimitError):
            self.llm(max_retries=2).complete(MESSAGES)
        self.assertEqual(len(server.requests), 3)  # 1 try + 2 retries, then stop
        self.assertEqual(len(self.sleeps), 2)

    def test_server_error_retried_then_raised(self):
        server = self.serve(reply(500, {}))
        with self.assertRaises(LLMServerError):
            self.llm(max_retries=1).complete(MESSAGES)
        self.assertEqual(len(server.requests), 2)

    def test_auth_error_not_retried_and_key_not_leaked(self):
        server = self.serve(reply(401, {"error": "bad key sk-test-123"}))
        with self.assertRaises(LLMError) as ctx:
            self.llm(api_key="sk-test-123").complete(MESSAGES)
        self.assertEqual(len(server.requests), 1)
        self.assertIn("LLM_API_KEY", ctx.exception.user_message)
        self.assertNotIn("sk-test-123", str(ctx.exception) + ctx.exception.user_message)

    def test_not_found_message_mentions_ollama_pull(self):
        self.serve(reply(404, {}))
        with self.assertRaises(LLMError) as ctx:
            self.llm().complete(MESSAGES)
        self.assertIn("ollama pull", ctx.exception.user_message)

    def test_malformed_bodies_raise_response_error(self):
        bodies = [b"not json", {"choices": []}, {"choices": [{"message": {"content": ""}}]}, {"error": "x"}, [1, 2], {"choices": ["x"]}]
        for body in bodies:
            with self.subTest(body=body):
                server = self.serve(reply(200, body))
                with self.assertRaises(LLMResponseError):
                    self.llm().complete(MESSAGES)
                self.assertEqual(len(server.requests), 1)  # malformed responses are not retried

    def test_timeout(self):
        self.serve(reply(200, OK_BODY, delay=1.5))
        with self.assertRaises(LLMTimeoutError):
            self.llm(timeout_s=0.3, max_retries=0).complete(MESSAGES)

    def test_connection_refused_is_not_retried(self):
        # Real socket to a closed port. The timeout is deliberately generous: Linux/macOS report
        # "refused" instantly, but Windows keeps retrying the SYN and reports it only after ~2 s.
        # A short timeout would fire first there and (correctly) be classified as a timeout, which
        # is a different case, pinned by the mock-based tests below.
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
        self.sleeps = []
        llm = OpenAICompatLLM(f"http://127.0.0.1:{port}/v1", "m", timeout_s=15.0, max_retries=3, sleep=self.sleeps.append)
        with self.assertRaises(LLMConnectionError) as ctx:
            llm.complete(MESSAGES)
        self.assertIn("Ollama", ctx.exception.user_message)
        self.assertEqual(self.sleeps, [])

    # ---- classification rules, independent of OS socket timing (the transport is mocked) ----
    def llm_with_open(self, side_effect, **kw):
        self.sleeps = []
        llm = OpenAICompatLLM("http://127.0.0.1:9/v1", "m", timeout_s=5.0, sleep=self.sleeps.append, **kw)
        patcher = mock.patch.object(OpenAICompatLLM, "_open", side_effect=side_effect)
        self.open_mock = patcher.start()
        self.addCleanup(patcher.stop)
        return llm

    def test_refused_connection_is_connection_error_and_not_retried(self):
        refused = urllib.error.URLError(ConnectionRefusedError(10061, "refused"))
        llm = self.llm_with_open(refused, max_retries=3)
        with self.assertRaises(LLMConnectionError):
            llm.complete(MESSAGES)
        self.assertEqual(self.open_mock.call_count, 1)
        self.assertEqual(self.sleeps, [])

    def test_connect_phase_timeout_is_timeout_error_and_retried(self):
        timed_out = urllib.error.URLError(TimeoutError("timed out"))  # how urllib reports a connect timeout
        llm = self.llm_with_open(timed_out, max_retries=3)
        with self.assertRaises(LLMTimeoutError):
            llm.complete(MESSAGES)
        self.assertEqual(self.open_mock.call_count, 4)  # 1 try + 3 retries, then stop
        self.assertEqual(len(self.sleeps), 3)

    def test_response_phase_timeout_is_timeout_error_and_retried(self):
        llm = self.llm_with_open(TimeoutError("timed out"), max_retries=2)  # raw TimeoutError while awaiting the reply
        with self.assertRaises(LLMTimeoutError):
            llm.complete(MESSAGES)
        self.assertEqual(self.open_mock.call_count, 3)
        self.assertEqual(len(self.sleeps), 2)

    def test_connection_reset_mid_request_is_connection_error_and_not_retried(self):
        llm = self.llm_with_open(ConnectionResetError(10054, "reset"), max_retries=3)
        with self.assertRaises(LLMConnectionError):
            llm.complete(MESSAGES)
        self.assertEqual(self.open_mock.call_count, 1)

    def test_empty_message_list_rejected(self):
        self.serve(reply(200, OK_BODY))
        with self.assertRaises(LLMError):
            self.llm().complete([])


if __name__ == "__main__":
    unittest.main()
