import json
import pytest
from voiceassistant.dictation import (build_draft, finalize, new_draft, numbers_in, parse_llm_json, validate_draft)

TX = "Patient reports sensitivity in the lower right molar. Cold sensitivity noted. Further examination required."
GOOD = json.dumps({"chief_complaint": "Sensitivity in lower right molar", "patient_reported_symptoms": ["Cold sensitivity"],
                   "observed_findings": [], "anatomical_sites": ["lower right molar"], "assessment": None,
                   "recommendations": ["Further examination required"]})


def test_valid_draft_preserves_transcript_and_requires_review():
    d = build_draft(TX, GOOD, patient_id="P001")
    assert validate_draft(d) == []
    assert d["source_transcript"] == TX and d["status"] == "draft" and d["requires_clinician_review"] is True
    assert d["clinical_draft"]["observed_findings"] == []                # nothing invented
    assert any("no specific tooth" in f["reason"] for f in d["uncertainty_flags"])


def test_invented_tooth_number_is_removed_and_flagged():
    llm = json.dumps({"anatomical_sites": ["tooth 46"], "patient_reported_symptoms": ["Cold sensitivity"]})
    d = build_draft(TX, llm, "P001")
    assert d["clinical_draft"]["anatomical_sites"] == []
    assert any("46" in f["reason"] for f in d["uncertainty_flags"])


def test_spoken_tooth_number_is_accepted():
    d = build_draft("Caries on tooth thirty six, buccal surface.", json.dumps({"observed_findings": ["Caries"], "anatomical_sites": ["tooth 36"]}), "P001")
    assert d["clinical_draft"]["anatomical_sites"] == ["tooth 36"]
    assert numbers_in("thirty-six and forty eight and 7") == {36, 48, 7}


@pytest.mark.parametrize("bad", ["", "not json", "{broken", "[1,2]", None])
def test_malformed_llm_output_gives_empty_flagged_draft(bad):
    d = build_draft(TX, bad, "P001")
    assert validate_draft(d) == [] and d["source_transcript"] == TX
    assert d["clinical_draft"]["observed_findings"] == [] and d["uncertainty_flags"]


def test_fenced_json_and_wrong_types():
    obj, err = parse_llm_json("Sure!\n```json\n" + GOOD + "\n```")
    assert err is None and obj["chief_complaint"]
    d = build_draft(TX, json.dumps({"observed_findings": "caries", "anatomical_sites": [5, None], "assessment": 7}), "P001")
    assert validate_draft(d) == [] and d["clinical_draft"]["observed_findings"] == [] and d["clinical_draft"]["assessment"] is None


def test_model_assessment_is_flagged():
    d = build_draft(TX, json.dumps({"assessment": "Pulpitis", "patient_reported_symptoms": ["Cold sensitivity"]}), "P001")
    assert any(f["field"] == "assessment" for f in d["uncertainty_flags"])


def test_empty_dictation():
    d = build_draft("   ", GOOD)
    assert d["uncertainty_flags"][0]["reason"] == "empty_transcript"


def test_validation_catches_bad_edits():
    d = new_draft(TX, "P001")
    d["clinical_draft"]["recommendations"] = "oops"
    assert any("recommendations" in e for e in validate_draft(d))
    d2 = new_draft(TX); del d2["review"]
    assert validate_draft(d2) and validate_draft("x") and validate_draft({})
    d3 = new_draft(TX); d3["status"] = "finalized"
    assert any("finalized" in e for e in validate_draft(d3))      # cannot self-declare finalized


def test_finalize_workflow():
    d = build_draft(TX, GOOD, "P001")
    with pytest.raises(ValueError):
        finalize(d, reviewer_id="DR01", confirmed=False)
    with pytest.raises(ValueError):
        finalize(d, reviewer_id="", confirmed=True, acknowledge_flags=True)
    with pytest.raises(ValueError):
        finalize(d, reviewer_id="DR01", confirmed=True)                       # flags not acknowledged
    with pytest.raises(ValueError):
        finalize(build_draft(TX, GOOD), reviewer_id="DR01", confirmed=True, acknowledge_flags=True)  # no patient
    out = finalize(d, reviewer_id="DR01", confirmed=True, acknowledge_flags=True)
    assert out["status"] == "finalized" and out["review"]["reviewed_by"] == "DR01" and validate_draft(out) == []
    assert d["status"] == "draft"                                               # original untouched
    with pytest.raises(ValueError):
        finalize(out, reviewer_id="DR01", confirmed=True, acknowledge_flags=True)
