"""Regression tests for:
1. Clarification intent preservation (download report / PDF).
2. Clarification resolution with patient ID, DOB, and ordinals ("first patient", "second one").
3. Unambiguous resolution vs. re-prompting when out of range.
4. Empty transcription handling (retry message, re-arming, silence timer reset).
5. STT transient error handling without stopping voice mode.
6. Repeated speech after TTS playback and component state synchronization.
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

_ROOT = Path(__file__).resolve().parent.parent
_FRONTEND = _ROOT / "frontend"
for _p in (str(_ROOT), str(_FRONTEND)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import streamlit as st

from frontend.api_client import ApiError
from frontend.sections.assistant import (
    _fulfill_report_intent,
    _get_spoken_greeting,
    _get_time_greeting,
    _greet_if_needed,
    _handle_user_turn,
    _identifier_from_followup,
    _init,
    _resolve_candidate_by_ordinal,
)
from voiceassistant.dental.report_intent import is_pdf_intent
from voiceassistant.speech_cleaner import clean_text_for_speech


class ClarificationIntentPreservationTests(unittest.TestCase):
    """Test continuation of report and PDF download intents across clarification turns."""

    def setUp(self):
        st.session_state.clear()
        _init()
        st.session_state.voice_wanted = True

    def test_is_pdf_intent_recognizes_download_requests(self):
        self.assertTrue(is_pdf_intent("I wanted to download a report of Priya Sharma."))
        self.assertTrue(is_pdf_intent("Download report for Priya Sharma"))
        self.assertTrue(is_pdf_intent("Download that report as a PDF"))
        self.assertTrue(is_pdf_intent("Can you download her examination report?"))
        self.assertFalse(is_pdf_intent("Show me the report for Priya Sharma"))
        self.assertFalse(is_pdf_intent("Summarize her report"))

    def test_identifier_from_followup_variants(self):
        # Patient ID extraction
        self.assertEqual(_identifier_from_followup("P001"), {"patient_id": "P001"})
        self.assertEqual(_identifier_from_followup("patient ID P001"), {"patient_id": "P001"})
        self.assertEqual(_identifier_from_followup("patient id P 001"), {"patient_id": "P001"})
        self.assertEqual(_identifier_from_followup("patient id P-001"), {"patient_id": "P001"})
        self.assertEqual(_identifier_from_followup("P 0 0 1"), {"patient_id": "P001"})
        self.assertEqual(_identifier_from_followup("P zero zero one"), {"patient_id": "P001"})
        self.assertEqual(_identifier_from_followup("patient id P oh oh one"), {"patient_id": "P001"})
        self.assertEqual(_identifier_from_followup("use ID P002 please"), {"patient_id": "P002"})

        # DOB extraction
        self.assertEqual(_identifier_from_followup("1995-04-12"), {"dob": "1995-04-12"})
        self.assertEqual(_identifier_from_followup("her dob is 1988-11-03"), {"dob": "1988-11-03"})

        # Ordinals
        self.assertEqual(_identifier_from_followup("the first patient"), {"ordinal": 0})
        self.assertEqual(_identifier_from_followup("first one"), {"ordinal": 0})
        self.assertEqual(_identifier_from_followup("1st"), {"ordinal": 0})
        self.assertEqual(_identifier_from_followup("the second patient"), {"ordinal": 1})
        self.assertEqual(_identifier_from_followup("second one"), {"ordinal": 1})
        self.assertEqual(_identifier_from_followup("2nd"), {"ordinal": 1})
        self.assertEqual(_identifier_from_followup("the third patient"), {"ordinal": 2})

    def test_resolve_candidate_by_ordinal(self):
        # Privacy: with several matching patients (never listed to the doctor) an ordinal picks nobody.
        self.assertIsNone(_resolve_candidate_by_ordinal("Priya Sharma", 0))
        self.assertIsNone(_resolve_candidate_by_ordinal("Priya Sharma", 1))
        self.assertEqual(_resolve_candidate_by_ordinal("Rahul Verma", 0)["patient_id"], "P005")  # one match: nothing to choose

        cand_out_of_bounds = _resolve_candidate_by_ordinal("Priya Sharma", 10)
        self.assertIsNone(cand_out_of_bounds)

    def test_ambiguous_download_request_preserves_pdf_intent(self):
        client = MagicMock()
        client.latest_report.side_effect = ApiError("Multiple patients match.", status=409, ambiguous=True)
        client.tts.return_value = {"audio_wav_base64": None, "tts_engine": "mock_tts"}

        with patch("streamlit.rerun"):
            _handle_user_turn(client, "I wanted to download a report of Priya Sharma.")

        self.assertEqual(st.session_state.pending_report_name, "Priya Sharma")
        self.assertEqual(st.session_state.pending_intent, "download_pdf")
        self.assertTrue(st.session_state.is_clarification)
        # Check that assistant asked for clarification
        last_msg = st.session_state.chat[-1]
        self.assertEqual(last_msg["role"], "assistant")
        # privacy: the question never names, numbers or describes the matching patients
        self.assertIn("Multiple patients match that name.", last_msg["text"])
        self.assertNotIn("P001", last_msg["text"])

    def test_clarification_continuation_with_patient_id_provides_pdf(self):
        client = MagicMock()
        # Set pending state as if Turn 1 just asked for clarification
        st.session_state.pending_report_name = "Priya Sharma"
        st.session_state.pending_intent = "download_pdf"
        st.session_state.is_clarification = True

        mock_report_data = {
            "patient_name": "Priya Sharma",
            "patient_id": "P001",
            "report": {
                "report_id": "R001",
                "type": "OPG",
                "date": "2026-09-15",
                "findings": ["Sample finding"],
                "impression": "Sample impression",
            },
            "synthetic_data": True,
            "requires_clinician_review": True,
        }
        client.latest_report.return_value = mock_report_data
        client.report_pdf.return_value = b"%PDF-1.4 mock pdf data"
        client.tts.return_value = {"audio_wav_base64": None, "tts_engine": "mock_tts"}

        with patch("streamlit.rerun"):
            _handle_user_turn(client, "P001")

        # Client was called with P001
        client.latest_report.assert_called_once_with(
            name="Priya Sharma",
            patient_id="P001",
            date_of_birth=None,
            phone_contact=None,
            report_type=None,
        )
        # Pending state cleared
        self.assertIsNone(st.session_state.pending_report_name)
        self.assertIsNone(st.session_state.pending_intent)
        self.assertEqual(st.session_state.active_patient["patient_id"], "P001")

        # PDF download was fulfilled!
        last_msg = st.session_state.chat[-1]
        self.assertEqual(last_msg["role"], "assistant")
        self.assertIn("pdf_bytes", last_msg)
        self.assertEqual(last_msg["pdf_bytes"], b"%PDF-1.4 mock pdf data")
        self.assertIn("DentVoice_Report_P001_R001.pdf", last_msg["pdf_name"])

    def test_clarification_continuation_with_ordinal_first_patient(self):
        client = MagicMock()
        st.session_state.pending_report_name = "Priya Sharma"
        st.session_state.pending_intent = "download_pdf"
        st.session_state.is_clarification = True

        mock_report_data = {
            "patient_name": "Priya Sharma",
            "patient_id": "P001",
            "report": {
                "report_id": "R001",
                "type": "OPG",
                "date": "2026-09-15",
                "findings": ["Sample finding"],
            },
        }
        client.latest_report.return_value = mock_report_data
        client.report_pdf.return_value = b"%PDF-1.4 mock pdf"
        client.tts.return_value = {"audio_wav_base64": None, "tts_engine": "mock_tts"}

        with patch("streamlit.rerun"):
            _handle_user_turn(client, "the first patient")

        # Privacy: the matching patients were never listed, so "the first patient" picks nobody. No report is
        # retrieved, the question stays open, and the doctor is asked for the ID.
        client.latest_report.assert_not_called()
        client.report_pdf.assert_not_called()
        self.assertEqual(st.session_state.pending_report_name, "Priya Sharma")
        self.assertIn("Multiple patients match that name", st.session_state.chat[-1]["text"])
        self.assertNotIn("pdf_bytes", st.session_state.chat[-1])


class AutomaticGreetingTests(unittest.TestCase):
    """The greeting is created once, shown, and queued for the BROWSER to play. Nothing claims it is speaking."""

    def setUp(self):
        st.session_state.clear()
        _init()

    def _client(self, audio="UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA="):
        client = MagicMock()
        client.tts.return_value = {"audio_wav_base64": audio, "tts_engine": "mock_tts"}
        return client

    def test_initial_page_open_displays_and_queues_the_greeting_without_claiming_speech(self):
        client = self._client()
        with patch("frontend.sections.assistant.datetime") as mock_dt:
            mock_dt.now.return_value.hour = 9
            _greet_if_needed(client)
        self.assertEqual(len(st.session_state.chat), 1)
        msg = st.session_state.chat[0]
        self.assertEqual(msg["text"], "Good morning, Doctor. Welcome to DentVoice AI. How can I help you?")
        self.assertTrue(msg["is_greeting"])
        client.tts.assert_called_once_with("Good morning, Doctor. Welcome to DentVoice AI. How can I help you?")
        self.assertEqual(st.session_state.dv_audio["id"], "greeting")      # queued for the browser
        self.assertIsNone(st.session_state.dv_playing_id)                  # NOT 'speaking': the browser has not said so
        self.assertFalse(st.session_state.dv_listening)

    def test_written_and_spoken_greeting_are_identical(self):
        self.assertEqual(_get_spoken_greeting(), _get_time_greeting())

    def test_greeting_not_repeated_on_rerun(self):
        client = self._client(audio=None)
        _greet_if_needed(client)
        _greet_if_needed(client)
        _greet_if_needed(client)
        self.assertEqual(len(st.session_state.chat), 1)
        client.tts.assert_called_once()

    def test_greeting_survives_clearing_chat_without_repeating(self):
        client = self._client(audio=None)
        _greet_if_needed(client)
        st.session_state.chat = []                     # "Clear chat"
        _greet_if_needed(client)
        self.assertEqual(st.session_state.chat, [])

    def test_tts_failure_still_shows_the_greeting_and_does_not_block_listening(self):
        client = MagicMock()
        client.tts.side_effect = RuntimeError("tts down")
        _greet_if_needed(client)
        self.assertIn("Doctor", st.session_state.chat[0]["text"])
        self.assertIn("unavailable", st.session_state.chat[0]["warn"])
        self.assertIsNone(st.session_state.dv_audio)   # nothing queued -> the component starts listening directly


class TTSCleanupAndNaturalInteractionTests(unittest.TestCase):
    """Test dedicated speech cleaning and independent text/voice modes."""

    def setUp(self):
        st.session_state.clear()
        _init()

    def test_clean_text_for_speech_removes_emojis_and_preserves_meaning(self):
        text = "Good evening, Doctor! 👋 How can I help you today?"
        cleaned = clean_text_for_speech(text)
        self.assertEqual(cleaned, "Good evening, Doctor. How can I help you today?")
        self.assertNotIn("👋", cleaned)
        self.assertNotIn("waving", cleaned.lower())

    def test_clean_text_for_speech_removes_markdown_and_links(self):
        text = "**Findings**: No cavities observed; *Impression*: Normal. See [Report](http://localhost/r) 📄"
        cleaned = clean_text_for_speech(text)
        self.assertEqual(cleaned, "Findings: No cavities observed; Impression: Normal. See Report")
        self.assertNotIn("**", cleaned)
        self.assertNotIn("*", cleaned)
        self.assertNotIn("📄", cleaned)

    def test_clean_text_for_speech_removes_headers_and_code_blocks(self):
        text = "### Dental Exam\n```json\n{\"tooth\": 18}\n```\nAll teeth sound."
        cleaned = clean_text_for_speech(text)
        self.assertEqual(cleaned, "Dental Exam All teeth sound.")

    def test_spoken_greeting_format_by_time_of_day(self):
        with patch("frontend.sections.assistant.datetime") as mock_dt:
            for hour, expected in ((9, "Good morning, Doctor. Welcome to DentVoice AI. How can I help you?"),
                                   (14, "Good afternoon, Doctor. How can I help you?"),
                                   (20, "Good evening, Doctor. How can I help you?"),
                                   (23, "Hello, Doctor. How can I help you tonight?")):
                mock_dt.now.return_value.hour = hour
                self.assertEqual(_get_spoken_greeting(), expected)

    def test_text_chat_works_independently_when_the_microphone_is_off(self):
        st.session_state.dv_listening = False
        client = MagicMock()
        client.turn.return_value = {
            "reply_text": "Here are the details for your request.",
            "audio_wav_base64": None,
            "tts_engine": "mock",
        }

        with patch("streamlit.rerun"):
            _handle_user_turn(client, "Can you check my notes?", input_mode="typed")

        # The microphone state is untouched by a typed message
        self.assertFalse(st.session_state.dv_listening)
        # Message was processed and appended
        self.assertEqual(len(st.session_state.chat), 2)
        self.assertEqual(st.session_state.chat[0]["role"], "user")
        self.assertEqual(st.session_state.chat[0]["text"], "Can you check my notes?")
        self.assertEqual(st.session_state.chat[1]["role"], "assistant")
        self.assertIn("Here are the details for your request.", st.session_state.chat[1]["text"])


if __name__ == "__main__":
    unittest.main()
