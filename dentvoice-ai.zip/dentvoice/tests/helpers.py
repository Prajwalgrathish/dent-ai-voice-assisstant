"""Shared test helpers. All tests use fake or stubbed providers: no network, models or API keys."""

import shutil
import tempfile
import unittest
from pathlib import Path

from voiceassistant.config import Settings
from voiceassistant.pipeline import VoicePipeline
from voiceassistant.providers.fake import FakeLLM, FakeSTT, FakeTTS, write_tone_wav  # noqa: F401


class TmpCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="va_test_"))
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)

    def settings(self, **overrides) -> Settings:
        env = {"STT_PROVIDER": "fake", "LLM_PROVIDER": "fake", "TTS_PROVIDER": "fake", "TMP_DIR": str(self.tmp / "work")}
        env.update(overrides)
        return Settings.from_env(env)

    def pipeline(self, stt=None, llm=None, tts=None, **overrides):
        stt, llm, tts = stt or FakeSTT(), llm or FakeLLM(), tts or FakeTTS()
        p = VoicePipeline(stt, llm, tts, self.settings(**overrides))
        return p, stt, llm, tts

    def wav(self, name="in.wav", **kw) -> Path:
        path = self.tmp / name
        write_tone_wav(path, **kw)
        return path
