"""Tests the faster-whisper adapter logic against a FAKE faster_whisper module (not the real model)."""

import math
import sys
import types
import unittest
from collections import namedtuple
from unittest import mock

from tests.helpers import TmpCase
from voiceassistant.errors import STTError
from voiceassistant.providers.stt_faster_whisper import FasterWhisperSTT

Seg = namedtuple("Seg", "text avg_logprob no_speech_prob")


def fake_module(segments=(), raises=None, load_raises=None):
    state = types.SimpleNamespace(loads=[], calls=[])

    class WhisperModel:
        def __init__(self, name, device, compute_type):
            if load_raises:
                raise load_raises
            state.loads.append((name, device, compute_type))

        def transcribe(self, path, **kwargs):
            state.calls.append((path, kwargs))
            if raises:
                raise raises
            return iter(segments), types.SimpleNamespace(language="en")

    module = types.ModuleType("faster_whisper")
    module.WhisperModel = WhisperModel
    return module, state


class FasterWhisperTests(TmpCase):
    def stt(self, module, **kw):
        patcher = mock.patch.dict(sys.modules, {"faster_whisper": module})
        patcher.start()
        self.addCleanup(patcher.stop)
        return FasterWhisperSTT("base.en", "cpu", "int8", **kw)

    def test_transcript_text_and_confidence(self):
        module, state = fake_module([Seg(" Hello there.", -0.1, 0.01), Seg(" How are you?", -0.3, 0.02)])
        t = self.stt(module).transcribe(self.wav())
        self.assertEqual(t.text, "Hello there. How are you?")
        self.assertAlmostEqual(t.confidence, (math.exp(-0.1) + math.exp(-0.3)) / 2, places=6)
        self.assertFalse(t.low_confidence)
        self.assertEqual(state.calls[0][1]["language"], "en")
        self.assertTrue(state.calls[0][1]["vad_filter"])

    def test_low_confidence_flag(self):
        module, _ = fake_module([Seg(" mumble", -1.5, 0.1)])
        t = self.stt(module, min_confidence=0.45).transcribe(self.wav())
        self.assertTrue(t.low_confidence)

    def test_no_segments_gives_empty_text_and_no_confidence(self):
        module, _ = fake_module([])
        t = self.stt(module).transcribe(self.wav())
        self.assertEqual((t.text, t.confidence, t.low_confidence), ("", None, False))

    def test_hallucination_segments_filtered(self):
        # Segments with high no_speech_prob and low avg_logprob should be dropped
        good_seg = Seg(" Arjun Rao", -0.2, 0.05)
        hallucinated_seg = Seg(" invented words", -1.5, 0.85)
        module, state = fake_module([good_seg, hallucinated_seg])
        t = self.stt(module).transcribe(self.wav())
        self.assertEqual(t.text, "Arjun Rao")
        self.assertTrue(state.calls[0][1]["vad_filter"])
        self.assertFalse(state.calls[0][1]["condition_on_previous_text"])

    def test_model_loaded_once_lazily(self):
        module, state = fake_module([Seg(" a", -0.1, 0.0)])
        stt = self.stt(module)
        self.assertEqual(state.loads, [])
        stt.transcribe(self.wav())
        stt.transcribe(self.wav())
        self.assertEqual(state.loads, [("base.en", "cpu", "int8")])

    def test_package_missing(self):
        with mock.patch.dict(sys.modules, {"faster_whisper": None}):
            with self.assertRaises(STTError) as ctx:
                FasterWhisperSTT().transcribe(self.wav())
        self.assertIn("pip install faster-whisper", ctx.exception.user_message)

    def test_model_load_failure_and_transcribe_failure(self):
        module, _ = fake_module(load_raises=OSError("download failed"))
        with self.assertRaises(STTError):
            self.stt(module).transcribe(self.wav())
        module, _ = fake_module(raises=RuntimeError("decode error at /secret/path"))
        with self.assertRaises(STTError) as ctx:
            self.stt(module).transcribe(self.wav())
        self.assertNotIn("/secret", ctx.exception.user_message)


if __name__ == "__main__":
    unittest.main()
