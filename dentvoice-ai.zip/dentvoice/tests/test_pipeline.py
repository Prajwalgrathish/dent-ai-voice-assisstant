import unittest
import wave

from tests.helpers import FakeLLM, FakeSTT, FakeTTS, TmpCase
from voiceassistant.audio import wav_duration
from voiceassistant.errors import LLMTimeoutError, STTError, TTSError
from voiceassistant.providers.base import FallbackTTS


class PipelineTests(TmpCase):
    # ---- typed input -------------------------------------------------
    def test_typed_turn_skips_stt_and_is_labelled(self):
        p, stt, llm, tts = self.pipeline()
        r = p.run_text("hello")
        self.assertTrue(r.ok)
        self.assertEqual(r.input_mode, "typed")
        self.assertIsNone(r.transcript)
        self.assertEqual(stt.calls, [])
        self.assertEqual(r.reply_text, "(fake LLM) You said: hello")
        self.assertEqual(tts.calls, [r.reply_text])  # spoken text == displayed text
        with wave.open(str(r.audio_path), "rb") as w:
            self.assertGreater(w.getnframes(), 0)
        self.assertEqual([m["role"] for m in llm.calls[0]], ["system", "user"])

    def test_empty_and_too_long_typed_input(self):
        p, _, llm, _ = self.pipeline(MAX_INPUT_CHARS="10")
        self.assertEqual(p.run_text("   ").error.stage, "input")
        self.assertEqual(p.run_text("x" * 11).error.stage, "input")
        self.assertEqual(llm.calls, [])

    # ---- speech input -------------------------------------------------
    def test_valid_audio_turn(self):
        p, stt, llm, _ = self.pipeline(stt=FakeSTT(text="what is machine learning"))
        r = p.run_audio(self.wav())
        self.assertTrue(r.ok)
        self.assertEqual(r.input_mode, "speech")
        self.assertEqual(r.transcript.text, "what is machine learning")
        self.assertEqual(len(stt.calls), 1)
        self.assertEqual(llm.calls[0][-1]["content"], "what is machine learning")

    def test_invalid_audio_never_reaches_stt(self):
        p, stt, _, _ = self.pipeline()
        bad = self.tmp / "empty.wav"
        bad.write_bytes(b"")
        r = p.run_audio(bad)
        self.assertEqual(r.error.stage, "audio")
        self.assertEqual(stt.calls, [])

    def test_stt_provider_failure(self):
        stt = FakeSTT(error=STTError("boom", user_message="Speech recognition failed."))
        p, _, llm, _ = self.pipeline(stt=stt)
        r = p.run_audio(self.wav())
        self.assertEqual((r.error.stage, r.error.message), ("stt", "Speech recognition failed."))
        self.assertEqual(llm.calls, [])

    def test_unexpected_stt_exception_is_not_leaked(self):
        p, _, _, _ = self.pipeline(stt=FakeSTT(error=RuntimeError("secret C:\\path\\key")))
        r = p.run_audio(self.wav())
        self.assertEqual(r.error.stage, "stt")
        self.assertNotIn("secret", r.error.message)

    def test_empty_transcript_means_no_speech(self):
        p, _, llm, _ = self.pipeline(stt=FakeSTT(text="  "))
        r = p.run_audio(self.wav())
        self.assertEqual(r.error.stage, "stt")
        self.assertIn("No speech", r.error.message)
        self.assertEqual(llm.calls, [])

    def test_low_confidence_is_flagged_but_still_answered(self):
        p, _, _, _ = self.pipeline(stt=FakeSTT(confidence=0.2, low_confidence=True))
        r = p.run_audio(self.wav())
        self.assertTrue(r.ok)
        self.assertTrue(r.transcript.low_confidence)

    # ---- LLM ------------------------------------------------------------
    def test_llm_failure(self):
        llm = FakeLLM(error=LLMTimeoutError("t", user_message="The language model took too long to respond."))
        p, _, _, tts = self.pipeline(llm=llm)
        r = p.run_text("hi")
        self.assertEqual(r.error.stage, "llm")
        self.assertIsNone(r.audio_path)
        self.assertEqual(tts.calls, [])

    def test_unexpected_llm_exception_is_not_leaked(self):
        p, _, _, _ = self.pipeline(llm=FakeLLM(error=ValueError("api key sk-123")))
        r = p.run_text("hi")
        self.assertEqual(r.error.stage, "llm")
        self.assertNotIn("sk-123", r.error.message)

    def test_empty_llm_reply(self):
        p, _, _, tts = self.pipeline(llm=FakeLLM(reply="   "))
        r = p.run_text("hi")
        self.assertEqual(r.error.stage, "llm")
        self.assertEqual(tts.calls, [])

    # ---- TTS --------------------------------------------------------------
    def test_tts_failure_preserves_text_answer(self):
        tts = FakeTTS(error=TTSError("x", user_message="Speech synthesis failed."))
        p, _, _, _ = self.pipeline(tts=tts)
        r = p.run_text("hi")
        self.assertTrue(r.ok)
        self.assertEqual(r.reply_text, "(fake LLM) You said: hi")
        self.assertIsNone(r.audio_path)
        self.assertEqual(r.tts_error.stage, "tts")

    def test_unexpected_tts_exception_preserves_text_answer(self):
        p, _, _, _ = self.pipeline(tts=FakeTTS(error=RuntimeError("driver crash")))
        r = p.run_text("hi")
        self.assertTrue(r.ok)
        self.assertTrue(r.reply_text)
        self.assertNotIn("driver", r.tts_error.message)

    def test_long_reply_is_chunked_and_joined(self):
        reply = "One sentence here. Two sentence here. Three sentence here."
        p, _, _, tts = self.pipeline(llm=FakeLLM(reply=reply), tts=FakeTTS(seconds=0.2), TTS_MAX_CHARS="30")
        r = p.run_text("go")
        self.assertEqual(len(tts.calls), 3)
        self.assertEqual(" ".join(tts.calls), reply)
        self.assertAlmostEqual(wav_duration(r.audio_path), 0.6, places=2)
        self.assertEqual([f.name for f in p.settings.tmp_dir.iterdir()], [r.audio_path.name])  # chunk files removed

    def test_cleanup_deletes_audio(self):
        p, _, _, _ = self.pipeline()
        r = p.run_text("hi")
        path = r.audio_path
        self.assertTrue(path.exists())
        p.cleanup(r)
        self.assertFalse(path.exists())
        self.assertIsNone(r.audio_path)

    def test_fallback_tts_uses_second_provider(self):
        first = FakeTTS(name="first", error=TTSError("down", user_message="down"))
        second = FakeTTS(name="second")
        p, _, _, _ = self.pipeline(tts=FallbackTTS([first, second]))
        r = p.run_text("hi")
        self.assertEqual(r.tts_engine, "second")
        self.assertEqual((len(first.calls), len(second.calls)), (1, 1))

    def test_fallback_tts_all_fail_keeps_text(self):
        err = TTSError("down", user_message="down")
        p, _, _, _ = self.pipeline(tts=FallbackTTS([FakeTTS(name="a", error=err), FakeTTS(name="b", error=err)]))
        r = p.run_text("hi")
        self.assertTrue(r.ok)
        self.assertIsNone(r.audio_path)
        self.assertIsNotNone(r.tts_error)


if __name__ == "__main__":
    unittest.main()
