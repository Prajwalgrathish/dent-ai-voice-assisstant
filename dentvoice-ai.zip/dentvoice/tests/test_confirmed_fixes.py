"""Automated tests for verified fixes:
1. Patient search and ambiguous-name handling.
2. Latest-report retrieval and missing reports.
3. Lowercase, uppercase, and mixed-case natural-language report requests.
4. P006 findings schema integrity.
5. Contextual follow-up handling without guessing patient identity ("Summarize her report").
6. Clinical dictation preserving uncertainty without inventing clinical observations.
"""

import unittest
from fastapi.testclient import TestClient

from voiceassistant.api import _build_clinical_draft, create_app
from voiceassistant.config import Settings
from voiceassistant.dental.report_intent import parse_report_request
from voiceassistant.dental.service import (
    AmbiguousPatientError,
    PatientNotFoundError,
    find_patient,
    get_latest_report,
    list_patient_candidates,
    load_patients,
)
from voiceassistant.factory import build_pipeline


class PatientSearchAndAmbiguityTests(unittest.TestCase):
    """Test patient search, candidate listing, and disambiguation."""

    def test_duplicate_name_raises_ambiguous_error(self):
        with self.assertRaises(AmbiguousPatientError):
            find_patient(name="Priya Sharma")

    def test_first_name_only_requires_full_name(self):
        with self.assertRaises(AmbiguousPatientError) as ctx:
            find_patient(name="Priya")
        self.assertIn("full name", str(ctx.exception))

    def test_list_candidates_returns_all_matches_for_first_name(self):
        candidates = list_patient_candidates("Priya")
        self.assertEqual(len(candidates), 3)
        ids = {c["patient_id"] for c in candidates}
        self.assertEqual(ids, {"P001", "P002", "P006"})

    def test_list_candidates_returns_exact_matches_for_full_name(self):
        candidates = list_patient_candidates("Priya Sharma")
        self.assertEqual(len(candidates), 2)
        ids = {c["patient_id"] for c in candidates}
        self.assertEqual(ids, {"P001", "P002"})

    def test_dob_disambiguates_patient(self):
        p1 = find_patient(name="Priya Sharma", date_of_birth="1995-04-12")
        self.assertEqual(p1["patient_id"], "P001")

        p2 = find_patient(name="Priya Sharma", date_of_birth="1988-11-03")
        self.assertEqual(p2["patient_id"], "P002")

    def test_phone_contact_disambiguates_patient(self):
        p1 = find_patient(name="Priya Sharma", phone_contact="DEMO-0001")
        self.assertEqual(p1["patient_id"], "P001")

    def test_api_patient_search_ambiguous_returns_ambiguous_status(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        # Search returns 200 with status: ambiguous and clarification message
        res = client.post("/v1/dental/patients/search", json={"name": "Priya Sharma"})
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["status"], "ambiguous")
        self.assertEqual(data["clarification_type"], "date_of_birth_or_contact")

        # Latest report retrieval without disambiguation raises 409
        rep_res = client.post("/v1/dental/reports/latest", json={"name": "Priya Sharma"})
        self.assertEqual(rep_res.status_code, 409)
        self.assertEqual(rep_res.json()["detail"]["status"], "ambiguous")

    def test_api_patient_search_matched_returns_200(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post("/v1/dental/patients/search", json={"name": "Arjun Rao"})
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["status"], "matched")
        self.assertEqual(data["patient"]["name"], "Arjun Rao")

    def test_api_patient_search_not_found_returns_404(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post("/v1/dental/patients/search", json={"name": "Nobody Here"})
        self.assertEqual(res.status_code, 404)


class LatestReportRetrievalTests(unittest.TestCase):
    """Test retrieval of reports and handling of missing reports/types."""

    def test_retrieve_latest_report_successfully(self):
        res = get_latest_report(name="Arjun Rao")
        self.assertEqual(res["patient_id"], "P003")
        self.assertEqual(res["patient_name"], "Arjun Rao")
        self.assertEqual(res["report"]["report_id"], "R006")
        self.assertEqual(res["report"]["type"], "Dental Examination")
        self.assertEqual(res["report"]["date"], "2026-10-05")

    def test_retrieve_report_by_specific_type(self):
        res = get_latest_report(name="Arjun Rao", report_type="OPG")
        self.assertEqual(res["report"]["report_id"], "R005")
        self.assertEqual(res["report"]["type"], "OPG")

    def test_missing_report_type_raises_not_found(self):
        with self.assertRaises(PatientNotFoundError) as ctx:
            get_latest_report(name="Arjun Rao", report_type="CBCT")
        self.assertIn("No matching report was found", str(ctx.exception))

    def test_missing_patient_raises_not_found(self):
        with self.assertRaises(PatientNotFoundError):
            get_latest_report(name="Nonexistent Patient")

    def test_api_latest_report_missing_type_returns_404(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post("/v1/dental/reports/latest", json={"name": "Arjun Rao", "report_type": "CBCT"})
        self.assertEqual(res.status_code, 404)


class ReportIntentCaseHandlingTests(unittest.TestCase):
    """Test case-insensitive natural-language report intent parsing."""

    def test_lowercase_report_request(self):
        parsed = parse_report_request("show me the latest report for arjun rao")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("name"), "Arjun Rao")

    def test_uppercase_report_request(self):
        parsed = parse_report_request("SHOW ME THE LATEST REPORT FOR ARJUN RAO")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("name"), "Arjun Rao")

    def test_mixed_case_report_request(self):
        parsed = parse_report_request("Show Me The Latest Report For Arjun Rao")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("name"), "Arjun Rao")

    def test_lowercase_possessive_request(self):
        parsed = parse_report_request("what is arjun rao's latest report")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("name"), "Arjun Rao")

    def test_uppercase_possessive_request(self):
        parsed = parse_report_request("WHAT IS ARJUN RAO'S LATEST REPORT")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("name"), "Arjun Rao")

    def test_lowercase_opg_type_extraction(self):
        parsed = parse_report_request("show me the opg report for arjun rao")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("name"), "Arjun Rao")
        self.assertEqual(parsed.get("report_type"), "OPG")

    def test_unknown_patient_lowercase_parsed(self):
        parsed = parse_report_request("show me the latest report for john doe")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("name").casefold(), "john doe")

    def test_pipeline_turn_lowercase_request_returns_report(self):
        pipeline = build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",)))
        result = pipeline.respond("show me the latest report for arjun rao")
        self.assertIn("Arjun Rao", result.reply_text)
        self.assertIn("P003", result.reply_text)
        self.assertIn("Dental Examination", result.reply_text)


class P006FindingsSchemaTests(unittest.TestCase):
    """Test that all patients, including P006, strictly use list format for findings."""

    def test_all_patients_in_dataset_have_list_findings(self):
        patients = load_patients()
        for patient in patients:
            pid = patient["patient_id"]
            for report in patient.get("reports", []):
                findings = report.get("findings")
                self.assertIsInstance(
                    findings,
                    list,
                    f"Patient {pid} report {report.get('report_id')} findings is {type(findings)}, expected list",
                )
                self.assertGreater(len(findings), 0)

    def test_p006_reports_have_list_findings(self):
        p006 = find_patient(patient_id="P006")
        self.assertEqual(p006["name"], "Priya Naik")
        self.assertEqual(len(p006["reports"]), 2)
        for report in p006["reports"]:
            self.assertIsInstance(report["findings"], list)
            self.assertIsInstance(report["findings"][0], str)
            self.assertIn("Clinician review required", report["findings"][0])

    def test_p006_latest_report_findings_in_pipeline(self):
        pipeline = build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",)))
        result = pipeline.respond("show me the latest report for P006")
        self.assertIn("Priya Naik", result.reply_text)
        self.assertIn("Findings: Synthetic demonstration report. Clinician review required.", result.reply_text)
        # Ensure findings were not iterated character-by-character
        self.assertNotIn("Findings: S; y; n", result.reply_text)


class ContextualFollowUpTests(unittest.TestCase):
    """Test follow-up requests without explicit patient identifiers ask for clarification."""

    def test_summarize_her_report_asks_which_patient(self):
        parsed = parse_report_request("Summarize her report")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("needs_patient"), "true")

    def test_pipeline_summarize_her_report_prompts_for_patient(self):
        pipeline = build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",)))
        result = pipeline.respond("Summarize her report")
        self.assertEqual(
            result.reply_text,
            "Which patient do you mean? Please provide the patient's full name or patient ID.",
        )

    def test_show_me_the_latest_report_without_name_asks_which_patient(self):
        pipeline = build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",)))
        result = pipeline.respond("show me the latest report")
        self.assertEqual(
            result.reply_text,
            "Which patient do you mean? Please provide the patient's full name or patient ID.",
        )


class ClinicalDictationTests(unittest.TestCase):
    """Test clinical dictation parser conservatism and uncertainty handling."""

    def test_dictation_preserves_uncertainty(self):
        draft = _build_clinical_draft("Lower right third molar is possibly horizontally impacted")
        self.assertTrue(draft["uncertainty_detected"])
        self.assertEqual(len(draft["findings"]), 1)
        self.assertEqual(draft["findings"][0]["certainty"], "uncertain_as_dictated")
        self.assertEqual(draft["findings"][0]["anatomical_site"], "Lower right third molar")
        self.assertEqual(draft["findings"][0]["finding"], "possibly horizontally impacted")
        self.assertIn("Review the uncertain wording", draft["uncertainty_note"])
        self.assertTrue(draft["requires_clinician_review"])

    def test_dictation_without_uncertainty(self):
        draft = _build_clinical_draft("Lower right third molar is horizontally impacted")
        self.assertFalse(draft["uncertainty_detected"])
        self.assertEqual(len(draft["findings"]), 1)
        self.assertEqual(draft["findings"][0]["certainty"], "dictated_not_independently_verified")
        self.assertIsNone(draft["uncertainty_note"])

    def test_non_dental_transcript_does_not_invent_findings(self):
        draft = _build_clinical_draft("The patient had coffee this morning")
        self.assertTrue(draft["uncertainty_detected"])
        self.assertEqual(draft["findings"], [])
        self.assertIsNone(draft["anatomical_site"])
        self.assertIn("could not be safely separated", draft["uncertainty_note"])

    def test_clinical_dictation_api_endpoint(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post("/v1/clinical/dictation", json={"transcript": "Upper left central incisor is chipped"})
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(len(data["findings"]), 1)
        self.assertEqual(data["findings"][0]["anatomical_site"], "Upper left central incisor")
        self.assertEqual(data["findings"][0]["finding"], "chipped")


if __name__ == "__main__":
    unittest.main()
