"""Piper (stub subprocess) and pyttsx3 (fake module) adapter tests. No real TTS engine is used."""

import json
import os
import sys
import types
import unittest
from pathlib import Path
from unittest import mock

from tests.helpers import TmpCase, write_tone_wav
from voiceassistant.audio import wav_duration
from voiceassistant.errors import TTSError
from voiceassistant.providers.tts_piper import PiperTTS
from voiceassistant.providers.tts_pyttsx3 import Pyttsx3TTS

PIPER_STUB = r'''
import json, os, sys
sys.path.insert(0, os.environ["VA_REPO"])
from voiceassistant.providers.fake import write_tone_wav
args = sys.argv[1:]
hyphen = os.environ.get("STUB_STYLE", "hyphen") == "hyphen"
if "--help" in args:
    print("usage: piper [--model M] [--output-file F] [--length-scale X]" if hyphen
          else "usage: piper [--model M] [--output_file F] [--length_scale X]")
    sys.exit(0)
wrong = "--output_file" if hyphen else "--output-file"
if wrong in args or ("--length_scale" if hyphen else "--length-scale") in args:
    print("error: unrecognized arguments", file=sys.stderr); sys.exit(2)
out = args[args.index("--output-file" if hyphen else "--output_file") + 1]
with open(os.environ["STUB_RECORD"], "w") as fh:
    json.dump({"args": args, "stdin": sys.stdin.buffer.read().decode("utf-8")}, fh)
mode = os.environ.get("STUB_MODE", "ok")
if mode == "fail":
    print("boom", file=sys.stderr); sys.exit(1)
if mode != "nofile":
    write_tone_wav(out, seconds=0.2)
'''


class PiperTests(TmpCase):
    def setUp(self):
        super().setUp()
        stub = self.tmp / "fake_piper.py"
        stub.write_text(PIPER_STUB)
        (self.tmp / "voice.onnx").write_bytes(b"x")
        (self.tmp / "voice.onnx.json").write_text("{}")
        self.record = self.tmp / "record.json"
        repo = str(Path(__file__).resolve().parent.parent)
        patcher = mock.patch.dict(os.environ, {"VA_REPO": repo, "STUB_RECORD": str(self.record), "STUB_STYLE": "hyphen", "STUB_MODE": "ok"})
        patcher.start()
        self.addCleanup(patcher.stop)
        self.stub = stub

    def piper(self, **kw):
        return PiperTTS(str(self.tmp / "voice.onnx"), command_prefix=[sys.executable, str(self.stub)], **kw)

    def test_synthesizes_wav_and_sends_utf8_text_on_stdin(self):
        out = self.tmp / "o.wav"
        self.piper().synthesize("Hello, world. Café.", out)
        self.assertAlmostEqual(wav_duration(out), 0.2, places=2)
        rec = json.loads(self.record.read_text())
        self.assertEqual(rec["stdin"], "Hello, world. Café.")
        self.assertIn("--model", rec["args"])
        self.assertNotIn("--length-scale", rec["args"])  # default 1.0 -> flag omitted

    def test_detects_underscore_flag_spelling(self):
        os.environ["STUB_STYLE"] = "underscore"
        out = self.tmp / "o.wav"
        self.piper(length_scale=1.2).synthesize("hi there", out)
        args = json.loads(self.record.read_text())["args"]
        self.assertIn("--output_file", args)
        self.assertIn("--length_scale", args)
        self.assertTrue(out.exists())

    def test_length_scale_passed_when_not_default(self):
        self.piper(length_scale=1.3).synthesize("hi there", self.tmp / "o.wav")
        args = json.loads(self.record.read_text())["args"]
        self.assertEqual(args[args.index("--length-scale") + 1], "1.3")

    def test_nonzero_exit_raises_without_leaking_stderr(self):
        os.environ["STUB_MODE"] = "fail"
        with self.assertRaises(TTSError) as ctx:
            self.piper().synthesize("hi", self.tmp / "o.wav")
        self.assertNotIn("boom", ctx.exception.user_message)

    def test_no_output_file_raises(self):
        os.environ["STUB_MODE"] = "nofile"
        with self.assertRaises(TTSError):
            self.piper().synthesize("hi", self.tmp / "o.wav")

    def test_missing_model_config_and_empty_text(self):
        with self.assertRaises(TTSError):
            PiperTTS("", command_prefix=[sys.executable, str(self.stub)]).synthesize("hi", self.tmp / "o.wav")
        (self.tmp / "voice.onnx.json").unlink()
        with self.assertRaises(TTSError):
            self.piper().synthesize("hi", self.tmp / "o.wav")
        with self.assertRaises(TTSError):
            self.piper().synthesize("   ", self.tmp / "o.wav")

    def test_piper_not_installed_gives_install_hint(self):
        broken = PiperTTS(str(self.tmp / "voice.onnx"), command_prefix=[sys.executable, "-c", "import sys; sys.exit(1)"])
        with self.assertRaises(TTSError) as ctx:
            broken.synthesize("hi", self.tmp / "o.wav")
        self.assertIn("pip install piper-tts", ctx.exception.user_message)


class Pyttsx3Tests(TmpCase):
    def fake_module(self, write=True):
        engine = mock.Mock()
        engine.props = {}
        engine.setProperty.side_effect = lambda k, v: engine.props.__setitem__(k, v)
        pending = {}
        engine.save_to_file.side_effect = lambda text, path: pending.update(text=text, path=path)
        engine.runAndWait.side_effect = lambda: write_tone_wav(pending["path"], seconds=0.2) if write else None
        module = types.ModuleType("pyttsx3")
        module.init = lambda: engine
        return module, engine

    def test_synthesizes_with_rate(self):
        module, engine = self.fake_module()
        with mock.patch.dict(sys.modules, {"pyttsx3": module}):
            out = self.tmp / "o.wav"
            Pyttsx3TTS(rate_wpm=150).synthesize("hello", out)
        self.assertEqual(engine.props["rate"], 150)
        self.assertTrue(out.exists())

    def test_not_installed(self):
        with mock.patch.dict(sys.modules, {"pyttsx3": None}):
            with self.assertRaises(TTSError) as ctx:
                Pyttsx3TTS().synthesize("hello", self.tmp / "o.wav")
        self.assertIn("pip install pyttsx3", ctx.exception.user_message)

    def test_engine_writes_nothing(self):
        module, _ = self.fake_module(write=False)
        with mock.patch.dict(sys.modules, {"pyttsx3": module}), self.assertRaises(TTSError):
            Pyttsx3TTS().synthesize("hello", self.tmp / "o.wav")

    def test_engine_crash_is_wrapped(self):
        module = types.ModuleType("pyttsx3")
        module.init = mock.Mock(side_effect=RuntimeError("no SAPI"))
        with mock.patch.dict(sys.modules, {"pyttsx3": module}), self.assertRaises(TTSError):
            Pyttsx3TTS().synthesize("hello", self.tmp / "o.wav")


if __name__ == "__main__":
    unittest.main()
