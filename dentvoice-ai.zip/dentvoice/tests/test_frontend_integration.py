"""Frontend + backend integration: the real Streamlit app (headless AppTest) against a real HTTP backend.

Runs the backend on a free local port in a thread with fake STT/LLM/TTS, so no models, keys or network are needed.
Skipped automatically when streamlit's AppTest is unavailable.
"""

import os
import socket
import threading
import time
import unittest
from pathlib import Path

from tests.helpers import FakeLLM, TmpCase

try:
    import httpx  # noqa: F401
    import multipart  # noqa: F401
    import uvicorn
    from streamlit.testing.v1 import AppTest

    from voiceassistant.api import create_app

    HAVE_DEPS = True
except ImportError:
    HAVE_DEPS = False

APP = str(Path(__file__).resolve().parent.parent / "frontend" / "app.py")


def _free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@unittest.skipUnless(HAVE_DEPS, "streamlit AppTest / uvicorn not installed")
class StreamlitAppIntegration(TmpCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()

    def setUp(self):
        super().setUp()
        pipeline, *_ = self.pipeline()
        self.port = _free_port()
        self.server = uvicorn.Server(uvicorn.Config(create_app(pipeline), host="127.0.0.1", port=self.port, log_level="error"))
        self.thread = threading.Thread(target=self.server.run, daemon=True)
        self.thread.start()
        for _ in range(100):
            if self.server.started:
                break
            time.sleep(0.05)
        self.assertTrue(self.server.started, "backend did not start")
        self.addCleanup(self._stop)
        os.environ["DENTVOICE_API_URL"] = f"http://127.0.0.1:{self.port}"
        self.addCleanup(os.environ.pop, "DENTVOICE_API_URL", None)

    def _stop(self):
        self.server.should_exit = True
        self.thread.join(timeout=5)

    def app(self):
        at = AppTest.from_file(APP, default_timeout=30)
        at.run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        return at

    def test_sidebar_has_exactly_the_four_main_sections_in_order(self):
        at = self.app()
        nav = next(r for r in at.radio if r.key == "nav")
        self.assertEqual(list(nav.options), ["AI Assistant", "Patient Reports", "Clinical Dictation", "Patient Voice Assistant"])

    def test_every_section_renders_without_error(self):
        at = self.app()
        for page in ("Patient Reports", "Clinical Dictation", "Patient Voice Assistant", "AI Assistant"):
            next(r for r in at.radio if r.key == "nav").set_value(page).run()
            self.assertFalse(at.exception, f"{page}: {[e.value for e in at.exception]}")

    def _open_patient_section(self):
        at = self.app()
        next(r for r in at.radio if r.key == "nav").set_value("Patient Voice Assistant").run()
        return at

    def test_patient_section_rejects_invalid_id_with_clear_error(self):
        at = self._open_patient_section()
        at.text_input(key="pva_pid_input").set_value("P999")
        next(b for b in at.button if b.label == "Access my reports").click().run()
        self.assertTrue(any("could not find that Patient ID" in e.value for e in at.error), [e.value for e in at.error])
        self.assertIsNone(at.session_state["pva_token"])

    def test_patient_signs_in_with_id_only_and_sees_only_own_reports(self):
        at = self._open_patient_section()
        at.text_input(key="pva_pid_input").set_value("p003")
        next(b for b in at.button if b.label == "Access my reports").click().run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        self.assertTrue(at.session_state["pva_token"])
        self.assertEqual({r["report_id"] for r in at.session_state["pva_reports"]}, {"R005", "R006"})
        text = " ".join(m.value for m in at.markdown)
        self.assertIn("Signed in: Arjun", text)

    def test_patient_asks_a_question_and_gets_a_grounded_answer(self):
        at = self._open_patient_section()
        at.text_input(key="pva_pid_input").set_value("P001")
        next(b for b in at.button if b.label == "Access my reports").click().run()
        next(b for b in at.button if b.label == "Explain my report.").click().run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        reply = at.session_state["pva_chat"][-1]
        self.assertEqual(reply["role"], "assistant")
        self.assertEqual(reply["evidence"][0]["report_id"], "R002")
        self.assertIn("Mild gingival inflammation recorded", reply["text"])

    def test_ending_the_session_forgets_the_patient(self):
        at = self._open_patient_section()
        at.text_input(key="pva_pid_input").set_value("P001")
        next(b for b in at.button if b.label == "Access my reports").click().run()
        next(b for b in at.button if b.label == "End session").click().run()
        self.assertIsNone(at.session_state["pva_token"])
        self.assertEqual(at.session_state["pva_chat"], [])

    def test_command_to_open_clinical_dictation_navigates_without_crashing(self):
        # Regression: this used to raise StreamlitWidgetAlreadyInstantiatedError (the nav radio was changed
        # after it had been created in the same run).
        at = self.app()
        at.chat_input[0].set_value("Open Clinical Dictation").run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        self.assertEqual(next(r for r in at.radio if r.key == "nav").value, "Clinical Dictation")

    def test_typed_clinical_observation_becomes_an_inline_draft_with_transcript_preserved(self):
        at = self.app()
        at.chat_input[0].set_value("Lower right third molar is horizontally impacted").run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        draft = at.session_state["chat"][-1]["draft"]
        self.assertEqual(draft["original_transcript"], "Lower right third molar is horizontally impacted")
        self.assertEqual(draft["anatomical_site"], "Lower right third molar")
        self.assertEqual(draft["findings"][0]["finding"], "horizontally impacted")
        self.assertTrue(draft["requires_clinician_review"])

    def test_patient_selection_by_ordinal_resolves_the_right_patient(self):
        # Regression: "the first" used to send a MASKED contact to the backend and always fail.
        at = self.app()
        at.chat_input[0].set_value("Open Priya's latest OPG report").run()
        at.chat_input[0].set_value("the first").run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        # Privacy: "the first" cannot choose between several patients that were never listed.
        self.assertIsNone(at.session_state["active_patient"])
        self.assertIsNone(at.session_state["active_report"])
        self.assertIn("Multiple patients match that name", at.session_state["chat"][-1]["text"])

    def test_answering_with_an_id_or_dob_after_ambiguity_resolves(self):
        # Regression: this path used to crash with "'NoneType' object has no attribute 'strip'".
        at = self.app()
        at.chat_input[0].set_value("Open Priya's latest OPG report").run()
        at.chat_input[0].set_value("1988-11-03").run()
        self.assertEqual(at.session_state["active_patient"]["patient_id"], "P002")
        self.assertEqual(at.session_state["active_report"]["report"]["report_id"], "R003")


if __name__ == "__main__":
    unittest.main()
