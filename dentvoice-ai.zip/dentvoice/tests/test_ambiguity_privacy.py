"""Privacy: an ambiguity response must never name, number or describe the matching patients."""

from __future__ import annotations

import logging
import unittest

from frontend.api_client import ApiError, DentVoiceClient
from frontend.sections.assistant import AMBIGUOUS_PATIENT_REPLY, _clarification_reply
from tests import test_report_context as trc
from voiceassistant.api import AMBIGUOUS_PATIENT_MESSAGE

GENERIC = ("Multiple patients match that name. Please provide the intended patient's ID "
           "or use the authorized patient lookup workflow.")
REAL = trc.REAL
SECRETS = [p["patient_id"] for p in REAL] + [p["date_of_birth"] for p in REAL] + ["born", "Priya Naik", "1995", "1988"]


def leaks(text):
    return [s for s in SECRETS if s.casefold() in text.casefold()]


class AmbiguityReplyWordingTests(unittest.TestCase):
    def test_required_wording_is_exact_in_frontend_and_api(self):
        self.assertEqual(AMBIGUOUS_PATIENT_REPLY, GENERIC)
        self.assertEqual(AMBIGUOUS_PATIENT_MESSAGE, GENERIC)

    def test_multiple_candidates_reply_is_generic_whatever_the_candidates_are(self):
        cands = [{"patient_id": p["patient_id"], "name": p["name"], "date_of_birth": p["date_of_birth"]} for p in REAL]
        for given in (cands, cands[:2], [], None):
            self.assertEqual(_clarification_reply("Priya Sharma", given), GENERIC)

    def test_single_candidate_confirmation_never_reads_out_id_or_date_of_birth(self):
        one = [{"patient_id": "P005", "name": "Rahul Verma", "date_of_birth": "1990-01-01"}]
        reply = _clarification_reply("Rahul", one)
        self.assertIn("Do you mean Rahul Verma", reply)
        self.assertNotIn("P005", reply)
        self.assertNotIn("1990", reply)


class AmbiguityConversationPrivacyTests(trc.ContextBase):
    QUESTION = "Can I get the latest reports of Priya Sharma?"

    def test_P001_P002_ambiguity_reply_leaks_nothing_and_the_answer_still_resumes_the_request(self):
        records = []
        handler = logging.Handler()
        handler.emit = lambda r: records.append(r.getMessage())
        root = logging.getLogger()
        root.addHandler(handler)
        old = root.level
        root.setLevel(logging.DEBUG)
        try:
            at = self.app()
            reply = self.say(at, self.QUESTION)
            self.assertEqual(reply, GENERIC)
            self.assertEqual(leaks(" ".join(m["text"] for m in at.session_state["chat"] if m["role"] == "assistant")), [])
            self.assertEqual(leaks(" ".join(str(m.value) for m in at.markdown if "Multiple patients" in str(m.value))), [])
            self.assertTrue(at.session_state["pending_report_name"])  # the original request is remembered
            for pid in ("P002", "P001"):  # the intended patient is identified by ID: correct patient, correct report
                at = self.app()
                self.say(at, self.QUESTION)
                self.say(at, pid)
                self.assert_active(at, pid, trc.history(pid)[0])
        finally:
            root.removeHandler(handler)
            root.setLevel(old)
        self.assertEqual(leaks(" ".join(records)), [], "ambiguity must not put patient details in logs")

    def test_P001_P002_api_409_for_report_and_pdf_carries_only_the_generic_message(self):
        import os
        client = DentVoiceClient(os.environ["DENTVOICE_API_URL"])
        with self.assertRaises(ApiError) as ctx:
            client.latest_report(name="Priya Sharma")
        self.assertEqual((ctx.exception.status, ctx.exception.message), (409, GENERIC))
        with self.assertRaises(ApiError) as ctx:
            client.report_pdf(name="Priya Sharma")
        self.assertEqual((ctx.exception.status, ctx.exception.message), (409, GENERIC))

    def test_P003_name_and_id_mismatch_does_not_reveal_whose_id_it_is(self):
        client = DentVoiceClient(__import__("os").environ["DENTVOICE_API_URL"])
        with self.assertRaises(ApiError) as ctx:
            client.latest_report(name="Arjun Rao", patient_id="P004")
        self.assertEqual(leaks(ctx.exception.message), [])
        self.assertNotIn("Meera", ctx.exception.message)

    def test_P003_unique_name_and_explicit_id_still_open_directly(self):
        at = self.app()
        self.say(at, "Show the latest report for Arjun Rao")
        self.assert_active(at, "P003", trc.history("P003")[0])
        at = self.app()
        self.say(at, "Show the latest report for P002")
        self.assert_active(at, "P002", trc.history("P002")[0])


if __name__ == "__main__":
    unittest.main()
