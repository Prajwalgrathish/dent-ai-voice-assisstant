"""Real-browser tests of the dentvoice_mic component (Chromium + a fake microphone device).

They load the component's real index.html, drive it exactly the way Streamlit does (postMessage render events) and
assert what the browser REALLY did: when audio genuinely played, when capture genuinely started, when the idle timer
stopped it. The microphone is Chromium's fake device fed from a generated WAV file, so no hardware is needed.

Skipped automatically when Playwright or its Chromium build is not installed.
"""

from __future__ import annotations

import base64
import functools
import http.server
import io
import math
import socketserver
import struct
import tempfile
import threading
import time
import unittest
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

try:  # pragma: no cover - environment dependent
    from playwright.sync_api import sync_playwright
    with sync_playwright() as _p:
        _exe = Path(_p.chromium.executable_path)
    HAVE_BROWSER = _exe.exists()
except Exception:  # noqa: BLE001
    HAVE_BROWSER = False


def make_wav(segments, rate: int = 16000) -> bytes:
    buf = io.BytesIO()
    w = wave.open(buf, "wb")
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
    for kind, secs in segments:
        frames = bytearray()
        for i in range(int(rate * secs)):
            v = int(9000 * math.sin(2 * math.pi * 220 * i / rate) * (1 + math.sin(i / 900)) / 2) if kind == "tone" else 0
            frames += struct.pack("<h", v)
        w.writeframes(bytes(frames))
    w.close()
    return buf.getvalue()


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k):  # noqa: D401
        pass


@unittest.skipUnless(HAVE_BROWSER, "Playwright/Chromium not installed")
class MicComponentBrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        handler = functools.partial(_Quiet, directory=str(ROOT))
        cls.server = socketserver.TCPServer(("127.0.0.1", 0), handler)
        cls.port = cls.server.server_address[1]
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.tmp = tempfile.mkdtemp()
        cls.silence = Path(cls.tmp, "silence.wav"); cls.silence.write_bytes(make_wav([("sil", 120)]))
        cls.speech = Path(cls.tmp, "speech.wav"); cls.speech.write_bytes(make_wav([("sil", 1.5), ("tone", 1.5), ("sil", 120)]))
        cls.clip_short = b64(make_wav([("tone", 1.2)]))
        cls.clip_long = b64(make_wav([("tone", 4.0)]))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    # --- helpers ---------------------------------------------------------------------------------------------
    BLOCK_FIRST_PLAY = """
        (() => { const orig = HTMLMediaElement.prototype.play; let blocked = false;
          HTMLMediaElement.prototype.play = function () {
            if (!blocked) { blocked = true; return Promise.reject(new DOMException('play() blocked', 'NotAllowedError')); }
            return orig.apply(this, arguments); }; })();"""

    def browse(self, body, *, mic=None, autoplay=True, block_first_play=False):
        with sync_playwright() as p:
            flags = ["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream",
                     f"--use-file-for-fake-audio-capture={mic or self.silence}%noloop",
                     "--autoplay-policy=no-user-gesture-required" if autoplay
                     else "--autoplay-policy=document-user-activation-required"]
            browser = p.chromium.launch(args=flags)
            try:
                page = browser.new_context(permissions=["microphone"]).new_page()
                if block_first_play:
                    # Chromium allows autoplay once a page holds microphone permission, so the browser's rejection is
                    # reproduced with the exact exception it throws (NotAllowedError) for the first play() call.
                    page.add_init_script(self.BLOCK_FIRST_PLAY)
                page.goto(f"http://127.0.0.1:{self.port}/tests/browser/harness.html")
                page.wait_for_function("window.ready")
                body(page)
            finally:
                browser.close()

    @staticmethod
    def events(page):
        return page.evaluate("events.map(e => e.type + ':' + (e.action || e.state || ''))")

    @staticmethod
    def wait(page, expr, timeout=12000):
        page.wait_for_function(expr, timeout=timeout)

    def render(self, page, **args):
        import json
        page.evaluate("a => render(a)", args)

    # --- tests -----------------------------------------------------------------------------------------------
    def test_speaking_is_shown_only_while_audio_really_plays_then_listening_starts(self):
        def body(page):
            self.render(page, auto_start=True, audio={"id": "greet", "b64": self.clip_long}, idle_timeout_ms=5000)
            self.wait(page, "dv().playing === true")
            self.wait(page, "label() === 'Speaking…'", 3000)
            self.assertEqual(page.evaluate("dv().mode"), "idle", "microphone must not start while the greeting plays")
            self.wait(page, "dv().mode === 'active'")
            self.wait(page, "label() === 'Listening…'", 3000)
            ev = self.events(page)
            self.assertLess(ev.index("playback:started"), ev.index("playback:ended"))
            self.assertLess(ev.index("playback:ended"), ev.index("action:resume"), "listening starts AFTER playback ended")
            self.assertFalse(page.evaluate("dv().playing"))
        self.browse(body)

    def test_blocked_autoplay_is_reported_and_never_shows_speaking(self):
        def body(page):
            self.render(page, auto_start=True, audio={"id": "greet", "b64": self.clip_short}, idle_timeout_ms=5000)
            self.wait(page, "events.some(e => e.state === 'blocked')")
            self.assertNotEqual(page.evaluate("label()"), "Speaking…")
            self.assertFalse(page.evaluate("dv().playing"))
            self.assertTrue(page.evaluate("document.getElementById('f').contentDocument.getElementById('audio-btn').classList.contains('show')"))
            page.evaluate("clickAudioBtn()")                       # the 'enable audio' control
            self.wait(page, "events.some(e => e.state === 'ended')")
            self.assertFalse(page.evaluate("dv().playing"))
        self.browse(body, block_first_play=True)

    def test_corrupt_audio_is_reported_as_failed_not_speaking(self):
        def body(page):
            self.render(page, audio={"id": "bad", "b64": b64(b"not audio at all")})
            self.wait(page, "events.some(e => e.state === 'failed')")
            self.assertFalse(page.evaluate("dv().playing"))
            self.assertNotEqual(page.evaluate("label()"), "Speaking…")
        self.browse(body)

    def test_audio_already_consumed_by_python_is_not_replayed(self):
        def body(page):
            self.render(page, audio={"id": "greet", "b64": self.clip_short}, done_ids=["greet"])
            time.sleep(1.5)
            self.assertFalse([e for e in self.events(page) if e.startswith("playback:")])
            self.render(page, audio={"id": "greet", "b64": self.clip_short})   # rerender: still only once
            self.wait(page, "events.some(e => e.state === 'ended')")
            self.render(page, audio={"id": "greet", "b64": self.clip_short})
            time.sleep(1.0)
            self.assertEqual(sum(1 for e in self.events(page) if e == "playback:started"), 1)
        self.browse(body)

    def test_silence_for_the_idle_timeout_stops_capture(self):
        def body(page):
            self.render(page, auto_start=True, idle_timeout_ms=2500)
            self.wait(page, "dv().mode === 'active'")
            self.wait(page, "dv().mode === 'standby'", 10000)
            self.assertIn("action:idle_timeout", self.events(page))
            self.wait(page, "label() === 'Stopped after silence'", 3000)
            self.assertFalse([e for e in self.events(page) if e.startswith("utterance")], "empty audio is never submitted")
        self.browse(body)

    def test_default_fifteen_second_idle_timeout(self):
        def body(page):
            self.render(page, auto_start=True)               # library default: idle_timeout_ms = 15000
            self.wait(page, "dv().mode === 'active'")
            t0 = time.time()
            self.wait(page, "dv().mode === 'standby'", 25000)
            elapsed = time.time() - t0
            self.assertGreater(elapsed, 13.5)
            self.assertLess(elapsed, 18.0)
        self.browse(body)

    def test_speech_before_the_timeout_is_captured_and_resets_the_timer(self):
        def body(page):
            self.render(page, auto_start=True, idle_timeout_ms=6000)
            self.wait(page, "events.some(e => e.type === 'utterance')", 15000)
            self.assertEqual(page.evaluate("dv().mode"), "active", "speaking must not trigger the idle stop")
            self.assertGreater(page.evaluate("events.find(e => e.type==='utterance').duration_s"), 0.5)
            self.assertEqual(page.evaluate("dv().awaiting !== null"), True)
        self.browse(body, mic=self.speech)

    def test_no_idle_timeout_while_the_assistant_is_thinking(self):
        def body(page):
            self.render(page, auto_start=True, idle_timeout_ms=2500)
            self.wait(page, "events.some(e => e.type === 'utterance')", 15000)
            time.sleep(4.5)                                   # well past the 2.5 s limit, Python has not answered
            self.assertEqual(page.evaluate("dv().mode"), "active")
            self.wait(page, "label() === 'Working on it…'", 3000)
            self.assertNotIn("action:idle_timeout", self.events(page))
        self.browse(body, mic=self.speech)

    def test_no_idle_timeout_while_the_assistant_is_speaking_and_timer_restarts_after(self):
        def body(page):
            self.render(page, auto_start=True, idle_timeout_ms=2500)
            self.wait(page, "dv().mode === 'active'")
            page.evaluate("a => render(a)", {"auto_start": True, "idle_timeout_ms": 2500,
                                              "audio": {"id": "reply", "b64": self.clip_long}})   # 4 s > 2.5 s limit
            self.wait(page, "dv().playing === true")
            time.sleep(3.2)
            self.assertTrue(page.evaluate("dv().playing"))
            self.assertEqual(page.evaluate("dv().mode"), "active", "playback time is not idle time")
            self.assertNotIn("action:idle_timeout", self.events(page))
            self.wait(page, "events.some(e => e.state === 'ended')")
            self.assertLess(page.evaluate("dv().idleMs"), 1500, "idle timer restarts from zero after playback")
            self.wait(page, "dv().mode === 'standby'", 10000)
        self.browse(body)

    def test_resume_after_idle_stop_starts_exactly_one_capture_session(self):
        def body(page):
            self.render(page, auto_start=True, idle_timeout_ms=2000)
            self.wait(page, "dv().mode === 'standby'", 12000)
            n0 = sum(1 for e in self.events(page) if e == "action:resume")
            for nonce in (1, 1, 1):                             # repeated renders with the same nonce = one resume
                self.render(page, auto_start=False, standby=True, idle_timeout_ms=60000, resume_nonce=nonce)
            self.wait(page, "dv().mode === 'active'")
            page.evaluate("clickMic = clickMic")               # clicking while active would PAUSE, so do not click
            time.sleep(0.8)
            n1 = sum(1 for e in self.events(page) if e == "action:resume")
            self.assertEqual(n1 - n0, 1, "no duplicate microphone sessions")
            self.wait(page, "label() === 'Listening…'", 3000)
        self.browse(body)

    def test_clicking_the_microphone_pauses_and_resumes(self):
        def body(page):
            self.render(page, idle_timeout_ms=60000)
            page.evaluate("clickMic()")
            self.wait(page, "dv().mode === 'active'")
            page.evaluate("clickMic()")
            self.wait(page, "dv().mode === 'paused'")
            self.assertIn("action:pause", self.events(page))
            self.wait(page, "label() === 'Paused'", 3000)
            page.evaluate("clickMic()")
            self.wait(page, "dv().mode === 'active'")
        self.browse(body)


if __name__ == "__main__":
    unittest.main()
