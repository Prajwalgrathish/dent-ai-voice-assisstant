"""API tests. Skipped automatically unless fastapi, httpx and python-multipart are installed.

These could NOT be run in the authoring environment (no package installation was possible).
"""

import base64
import io
import unittest

from tests.helpers import FakeLLM, FakeSTT, FakeTTS, TmpCase
from voiceassistant.errors import TTSError

try:
    import httpx  # noqa: F401
    import multipart  # noqa: F401
    from fastapi.testclient import TestClient

    from voiceassistant.api import create_app

    HAVE_DEPS = True
except ImportError:
    HAVE_DEPS = False


@unittest.skipUnless(HAVE_DEPS, "fastapi/httpx/python-multipart not installed")
class ApiTests(TmpCase):
    def client(self, **kw):
        pipeline, *_ = self.pipeline(**kw)
        return TestClient(create_app(pipeline))

    def test_health(self):
        r = self.client().get("/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["status"], "ok")

    def test_typed_turn_returns_text_and_wav(self):
        r = self.client().post("/v1/turn", json={"text": "hello"})
        self.assertEqual(r.status_code, 200)
        body = r.json()
        self.assertEqual(body["input_mode"], "typed")
        self.assertEqual(body["reply_text"], "(fake LLM) You said: hello")
        self.assertEqual(base64.b64decode(body["audio_wav_base64"])[:4], b"RIFF")

    def test_empty_text_rejected(self):
        self.assertEqual(self.client().post("/v1/turn", json={"text": ""}).status_code, 422)

    def test_tts_failure_still_returns_text(self):
        tts = FakeTTS(error=TTSError("x", user_message="Speech synthesis failed."))
        body = self.client(tts=tts).post("/v1/turn", json={"text": "hi"}).json()
        self.assertTrue(body["reply_text"])
        self.assertIsNone(body["audio_wav_base64"])
        self.assertEqual(body["tts_error"], "Speech synthesis failed.")

    def test_llm_failure_maps_to_502_without_internals(self):
        from voiceassistant.errors import LLMTimeoutError

        c = self.client(llm=FakeLLM(error=LLMTimeoutError("t", user_message="The language model took too long to respond.")))
        r = c.post("/v1/turn", json={"text": "hi"})
        self.assertEqual(r.status_code, 502)
        self.assertEqual(r.json()["detail"]["stage"], "llm")

    def test_audio_turn(self):
        data = self.wav().read_bytes()
        r = self.client(stt=FakeSTT(text="spoken words")).post("/v1/turn/audio", files={"file": ("a.wav", io.BytesIO(data), "audio/wav")})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["transcript"]["text"], "spoken words")

    def test_stt_endpoint_only_transcribes(self):
        data = self.wav().read_bytes()
        r = self.client(stt=FakeSTT(text="just text")).post("/v1/stt", files={"file": ("a.wav", io.BytesIO(data), "audio/wav")})
        self.assertEqual(r.json()["text"], "just text")

    def test_rejects_bad_extension_oversize_and_invalid_content(self):
        c = self.client(MAX_AUDIO_BYTES="2000")
        self.assertEqual(c.post("/v1/stt", files={"file": ("a.exe", io.BytesIO(b"x"), "application/octet-stream")}).status_code, 415)
        big = self.wav(seconds=1.0).read_bytes()
        self.assertEqual(c.post("/v1/stt", files={"file": ("a.wav", io.BytesIO(big), "audio/wav")}).status_code, 413)
        self.assertEqual(c.post("/v1/stt", files={"file": ("a.wav", io.BytesIO(b"not audio"), "audio/wav")}).status_code, 422)

    def test_uploads_are_deleted(self):
        c = self.client()
        c.post("/v1/stt", files={"file": ("a.wav", io.BytesIO(self.wav().read_bytes()), "audio/wav")})
        self.assertEqual(list((self.tmp / "work").glob("upload-*")), [])


    def test_clinical_dictation_extracts_site_and_finding(self):
        r = self.client().post(
            "/v1/clinical/dictation",
            json={"transcript": "Lower right third molar is horizontally impacted"},
        )
        self.assertEqual(r.status_code, 200)
        body = r.json()
        self.assertEqual(body["anatomical_site"], "Lower right third molar")
        self.assertEqual(body["findings"][0]["finding"], "horizontally impacted")
        self.assertTrue(body["requires_clinician_review"])
        self.assertEqual(
            body["original_transcript"],
            "Lower right third molar is horizontally impacted",
        )

    def test_clinical_dictation_preserves_uncertainty(self):
        r = self.client().post(
            "/v1/clinical/dictation",
            json={"transcript": "Lower right third molar may be horizontally impacted"},
        )
        self.assertEqual(r.status_code, 200)
        body = r.json()
        self.assertTrue(body["uncertainty_detected"])
        self.assertTrue(body["requires_clinician_review"])
        self.assertIn("may be", body["original_transcript"].lower())

    def test_clinical_dictation_does_not_invent_unsupported_finding(self):
        transcript = "The patient seems uncomfortable today"
        r = self.client().post(
            "/v1/clinical/dictation",
            json={"transcript": transcript},
        )
        self.assertEqual(r.status_code, 200)
        body = r.json()
        self.assertEqual(body["original_transcript"], transcript)
        self.assertEqual(body["findings"], [])
        self.assertTrue(body["uncertainty_detected"])
        self.assertTrue(body["requires_clinician_review"])


if __name__ == "__main__":
    unittest.main()
