"""Regression and integration tests for DentVoice AI Batch 1 features:
- Disambiguation of duplicate Priya Sharma records
- Rejection of nonexistent patient Preethi Sharma
- Spoken patient ID normalization
- Report retrieval and PDF download via report_pdf
- Clinical dictation workflow with uncertainty flags and clinician finalization
"""
import pytest
from voiceassistant.dental.service import find_patient, get_latest_report, AmbiguousPatientError, PatientNotFoundError
from voiceassistant.patient_resolver import extract_patient_id, resolve, select_from_candidates
from voiceassistant.report_pdf import build_report_pdf
from voiceassistant.dictation import build_draft, finalize, validate_draft
from pypdf import PdfReader
from io import BytesIO


def test_preethi_sharma_rejected():
    """Asking for Preethi Sharma when only Priya Sharma exists must reject without matching."""
    with pytest.raises(PatientNotFoundError) as exc_info:
        find_patient(name="Preethi Sharma")
    msg = str(exc_info.value)
    assert "couldn't find a patient named preethi sharma" in msg.lower() or "no patient matched" in msg.lower()


def test_priya_sharma_duplicate_disambiguation():
    """Priya Sharma has duplicate records (P001 and P002); must raise AmbiguousPatientError with candidates."""
    with pytest.raises(AmbiguousPatientError) as exc_info:
        find_patient(name="Priya Sharma")
    cands = exc_info.value.candidates
    assert len(cands) >= 2
    cand_pids = {c["patient_id"] for c in cands}
    assert "P001" in cand_pids and "P002" in cand_pids


def test_priya_sharma_resolved_with_spoken_id():
    """Resolving Priya Sharma with spoken ID variant 'P zero zero one' returns P001."""
    patient = find_patient(name="Priya Sharma", patient_id="P zero zero one")
    assert patient["patient_id"] == "P001"
    assert patient["name"] == "Priya Sharma"


def test_priya_sharma_resolved_with_dob():
    """Resolving Priya Sharma with DOB returns the exact matching record."""
    patient = find_patient(name="Priya Sharma", date_of_birth="1995-04-12")
    assert patient["patient_id"] == "P001"


def test_report_pdf_generation_content_and_download():
    """Generate real ReportLab PDF and verify patient details and report text."""
    report_data = get_latest_report(name="Priya Sharma", patient_id="P001")
    pdf_bytes = build_report_pdf(
        patient={"patient_id": report_data["patient_id"], "name": report_data["patient_name"]},
        reports=[dict(report_data["report"], patient_id="P001")],
        kind="report",
        synthetic=True,
    )
    assert pdf_bytes.startswith(b"%PDF")
    reader = PdfReader(BytesIO(pdf_bytes))
    full_text = "\n".join(p.extract_text() for p in reader.pages)
    assert "Priya Sharma" in full_text
    assert "P001" in full_text
    assert "Page 1 of" in full_text


def test_dictation_end_to_end_workflow():
    """Verify dictation draft building, tooth number conservation, and clinician finalization."""
    raw_tx = "Patient has deep caries on tooth thirty six. Recommended composite restoration."
    fake_llm = '{"observed_findings": ["deep caries"], "anatomical_sites": ["tooth 36", "tooth 46"], "recommendations": ["composite restoration"]}'
    draft = build_draft(raw_tx, fake_llm, patient_id="P001")
    
    # Anti-invention: tooth 46 was not spoken, so it must be removed
    assert "tooth 36" in draft["clinical_draft"]["anatomical_sites"]
    assert "tooth 46" not in draft["clinical_draft"]["anatomical_sites"]
    assert any("46" in flag["reason"] for flag in draft["uncertainty_flags"])
    
    # Finalize with clinician review
    finalized = finalize(draft, reviewer_id="DR_TEST", confirmed=True, acknowledge_flags=True)
    assert finalized["status"] == "finalized"
    assert finalized["review"]["reviewed_by"] == "DR_TEST"
    assert finalized["review"]["confirmed"] is True


def test_natural_report_phrase_extracts_name_and_triggers_intent():
    """Verify natural query 'Can I get the reports of Priya Sharma?' extracts Priya Sharma."""
    from voiceassistant.dental.report_intent import parse_report_request
    req = parse_report_request("Can I get the reports of Priya Sharma?")
    assert req is not None
    assert req.get("name") == "Priya Sharma"

    req_preethi = parse_report_request("Can I get the reports of Preethi Sharma?")
    assert req_preethi is not None
    assert req_preethi.get("name") == "Preethi Sharma"
