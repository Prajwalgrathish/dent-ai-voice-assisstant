import unittest

from voiceassistant.config import Settings, parse_dotenv
from voiceassistant.errors import ConfigError


class ConfigTests(unittest.TestCase):
    def test_defaults_target_local_ollama_piper_then_pyttsx3(self):
        s = Settings.from_env({})
        self.assertEqual(s.stt_provider, "faster_whisper")
        self.assertEqual(s.llm_base_url, "http://localhost:11434/v1")
        self.assertEqual(s.tts_providers, ("piper", "pyttsx3"))
        self.assertEqual(s.language, "en")

    def test_unknown_providers_rejected(self):
        for key, value in [("STT_PROVIDER", "bogus"), ("LLM_PROVIDER", "bogus"), ("TTS_PROVIDER", "piper,bogus")]:
            with self.subTest(key=key), self.assertRaises(ConfigError):
                Settings.from_env({key: value})

    def test_invalid_numbers_rejected(self):
        for key, value in [("LLM_TIMEOUT_S", "abc"), ("LLM_MAX_RETRIES", "99"), ("TTS_MAX_CHARS", "5")]:
            with self.subTest(key=key), self.assertRaises(ConfigError):
                Settings.from_env({key: value})

    def test_non_english_language_rejected_for_now(self):
        with self.assertRaises(ConfigError):
            Settings.from_env({"LANGUAGE": "hi"})

    def test_hosted_llm_requires_api_key(self):
        with self.assertRaises(ConfigError) as ctx:
            Settings.from_env({"LLM_BASE_URL": "https://api.example.com/v1"})
        self.assertIn("LLM_API_KEY", ctx.exception.user_message)
        s = Settings.from_env({"LLM_BASE_URL": "https://api.example.com/v1", "LLM_API_KEY": "k"})
        self.assertEqual(s.llm_api_key, "k")

    def test_local_llm_needs_no_key_and_bad_url_rejected(self):
        Settings.from_env({"LLM_BASE_URL": "http://127.0.0.1:1234/v1"})
        with self.assertRaises(ConfigError):
            Settings.from_env({"LLM_BASE_URL": "not-a-url"})

    def test_api_key_never_appears_in_repr(self):
        s = Settings.from_env({"LLM_BASE_URL": "https://api.example.com/v1", "LLM_API_KEY": "sk-super-secret"})
        self.assertNotIn("sk-super-secret", repr(s))

    def test_parse_dotenv(self):
        text = '# c\nA=1\nexport B="two words"\nC=x # trailing\n\nbadline\nD=\'q\'\n'
        self.assertEqual(parse_dotenv(text), {"A": "1", "B": "two words", "C": "x", "D": "q"})


if __name__ == "__main__":
    unittest.main()
