"""Patient ambiguity, pronoun resolution and contextual report retrieval (AI Assistant, doctor side).

Pure logic is tested directly; conversation behaviour runs through the real Streamlit page (AppTest) against a real
backend on a free port with fake providers. Expected values come from the ACTUAL dataset (patients.json), never from
hard-coded guesses. Zero- and one-report patients do not exist in the real data, so those cases use a temporary
COPY of the dataset (service.DATA_PATH is pointed at it); the real file is never modified.
"""

from __future__ import annotations

import copy
import json
import os
import socket
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from tests.helpers import FakeLLM, FakeSTT, FakeTTS, TmpCase
from voiceassistant.dental import service
from voiceassistant.dental.report_intent import parse_contextual_report_reference as ctx
from voiceassistant.dental.service import (
    AmbiguousPatientError,
    PatientNotFoundError,
    find_patient,
    get_report_history,
    list_patient_candidates,
    select_report,
)

try:
    import httpx  # noqa: F401
    import multipart  # noqa: F401
    import uvicorn
    from streamlit.testing.v1 import AppTest

    import dentvoice_mic
    from voiceassistant.api import create_app

    HAVE_DEPS = True
except ImportError:
    HAVE_DEPS = False

from tests.test_voice_workflow import APP, ScriptedMic, _free_port  # noqa: E402

REAL = json.loads(Path(service.DATA_PATH).read_text(encoding="utf-8"))
PIDS = [p["patient_id"] for p in REAL]
BY_ID = {p["patient_id"]: p for p in REAL}
NAME_COUNT: dict[str, int] = {}
for _p in REAL:
    NAME_COUNT[_p["name"]] = NAME_COUNT.get(_p["name"], 0) + 1
DUP_NAMES = sorted(n for n, c in NAME_COUNT.items() if c > 1)
PRONOUNS = ("he", "she", "they", "him", "her", "them", "his", "their", "hers", "theirs")
NOT_NAMES = {x.casefold() for x in PRONOUNS} | {
    "that patient", "the same patient", "that patient's report", "the report", "that report", "it", "the latest one",
}


def history(pid):
    """Newest first, from the real record."""
    return sorted(BY_ID[pid]["reports"], key=lambda r: (r["date"], r["report_id"]), reverse=True)


# ───────────────────────────── pure logic ─────────────────────────────
class PatientIdentificationTests(unittest.TestCase):
    def test_every_patient_is_found_by_canonical_id_and_by_full_name_unless_the_name_is_shared(self):
        for p in REAL:
            with self.subTest(pid=p["patient_id"]):
                self.assertEqual(find_patient(patient_id=p["patient_id"])["patient_id"], p["patient_id"])
                self.assertEqual(find_patient(name=p["name"], patient_id=p["patient_id"])["patient_id"], p["patient_id"])
                if NAME_COUNT[p["name"]] == 1:
                    self.assertEqual(find_patient(name=p["name"])["patient_id"], p["patient_id"])  # no clarification
                else:
                    with self.assertRaises(AmbiguousPatientError):
                        find_patient(name=p["name"])

    def test_duplicate_name_groups_list_each_patient_id_exactly_once(self):
        self.assertTrue(DUP_NAMES, "the dataset should contain a duplicate-name group")
        for name in DUP_NAMES:
            with self.subTest(name=name):
                ids = [c["patient_id"] for c in list_patient_candidates(name)]
                self.assertEqual(sorted(ids), sorted(p["patient_id"] for p in REAL if p["name"] == name))
                self.assertEqual(len(ids), len(set(ids)))

    def test_candidates_are_deduplicated_by_patient_id_even_if_a_row_is_repeated(self):
        # load_patients() already rejects duplicate IDs; this proves the candidate list is safe even if one slipped in.
        data = copy.deepcopy(REAL) + [copy.deepcopy(BY_ID["P001"])]
        with mock.patch.object(service, "load_patients", return_value=data):
            ids = [c["patient_id"] for c in list_patient_candidates("Priya Sharma")]
            self.assertEqual(sorted(ids), ["P001", "P002"])
            self.assertEqual([c["patient_id"] for c in list_patient_candidates("Priya")].count("P001"), 1)

    def test_a_repeated_patient_id_in_the_dataset_is_rejected_outright(self):
        with _dataset(copy.deepcopy(REAL) + [copy.deepcopy(BY_ID["P001"])]):
            with self.assertRaises(ValueError):
                service.load_patients()

    def test_conflicting_name_and_id_is_never_resolved_silently(self):
        with self.assertRaises(AmbiguousPatientError):
            find_patient(name="Arjun Rao", patient_id="P004")

    def test_dob_resolves_a_duplicate_name_to_the_matching_patient_only(self):
        for pid in ("P001", "P002"):
            with self.subTest(pid=pid):
                got = find_patient(name="Priya Sharma", date_of_birth=BY_ID[pid]["date_of_birth"])
                self.assertEqual(got["patient_id"], pid)


class ContextualReferenceParserTests(unittest.TestCase):
    TEMPLATES = (
        (("he", "she", "they"), "What did {p} have in the latest report?"),
        (("him", "her", "them"), "Open the latest report for {p}."),
        (("his", "her", "their"), "Show {p} latest report."),
        (("his", "hers", "theirs"), "The latest report is {p}; open it."),
    )

    def test_every_pronoun_template_is_a_latest_report_reference(self):
        for prons, tpl in self.TEMPLATES:
            for p in prons:
                with self.subTest(pronoun=p):
                    self.assertEqual(ctx(tpl.format(p=p)), {"selector": "latest", "report_type": ""})

    def test_selector_phrases(self):
        cases = {
            "the latest one": "latest", "the latest report": "latest", "the previous report": "previous",
            "the previous one": "previous", "the report before that one": "previous", "the old report": "earlier",
            "the earlier examination": "earlier", "that report": "active", "the report": "active",
        }
        for text, want in cases.items():
            with self.subTest(text=text):
                self.assertEqual(ctx(text, has_active_report=True)["selector"], want)

    def test_type_is_recognised_and_bare_examination_is_only_a_type_for_latest(self):
        self.assertEqual(ctx("her OPG report")["report_type"], "OPG")
        self.assertEqual(ctx("their last examination"), {"selector": "latest", "report_type": "Dental Examination"})
        self.assertEqual(ctx("the earlier examination")["report_type"], "")

    def test_position_case_punctuation_and_fillers(self):
        for text in ("SHOW HIS PREVIOUS REPORT!!!", "show his, uh, previous report", "Doctor, could you please open the previous report for her?",
                     "his previous report, please.", "I would like to look at the previous report of theirs"):
            with self.subTest(text=text):
                self.assertEqual(ctx(text)["selector"], "previous")

    def test_look_alike_words_are_not_pronouns_and_unrelated_sentences_are_not_report_requests(self):
        for text in ("other", "there", "whether", "the other day", "Hershey", "what time does he arrive?", "she is late today",
                     "they said hello", "give him my regards", "is her appointment at nine?", "thanks, that helps them"):
            with self.subTest(text=text):
                self.assertIsNone(ctx(text, has_active_report=True))

    def test_look_alike_words_next_to_a_report_word_still_need_a_real_reference(self):
        self.assertIsNone(ctx("there was another thing, whether the other day"))
        self.assertIsNone(ctx("Hershey is nice"))


class ReportSelectionTests(unittest.TestCase):
    def sel(self, pid, *a, **k):
        return select_report(history(pid), *a, **k)

    def test_latest_previous_and_before_that_come_from_the_real_history_for_every_patient(self):
        for pid in PIDS:
            h = history(pid)
            with self.subTest(pid=pid):
                self.assertEqual(self.sel(pid, "latest")["report"], h[0])
                self.assertEqual(self.sel(pid, "previous", active_report_id=h[0]["report_id"])["report"], h[1])
                self.assertEqual(self.sel(pid, "earlier", active_report_id=h[0]["report_id"])["report"], h[1])
                self.assertEqual(self.sel(pid, "previous", active_report_id=h[1]["report_id"])["status"], "no_earlier")

    def test_type_present_gives_latest_of_that_type_and_missing_type_never_substitutes(self):
        for pid in PIDS:
            with self.subTest(pid=pid):
                opg = [r for r in history(pid) if r["type"] == "OPG"][0]
                self.assertEqual(self.sel(pid, "latest", "OPG")["report"], opg)
                self.assertEqual(self.sel(pid, "latest", "Bitewing")["status"], "no_type")
                self.assertIsNone(self.sel(pid, "latest", "Bitewing")["report"])

    def test_zero_one_and_many_reports(self):
        self.assertEqual(select_report([], "latest")["status"], "none")
        one = [history("P003")[0]]
        self.assertEqual(select_report(one, "latest")["report"], one[0])
        self.assertEqual(select_report(one, "previous", active_report_id=one[0]["report_id"])["status"], "no_earlier")
        three = [{"report_id": "R3", "type": "OPG", "date": "2026-03-01"}, {"report_id": "R2", "type": "OPG", "date": "2026-02-01"},
                 {"report_id": "R1", "type": "OPG", "date": "2026-01-01"}]
        self.assertEqual(select_report(three, "previous", active_report_id="R3")["report"]["report_id"], "R2")
        self.assertEqual(select_report(three, "previous", active_report_id="R2")["report"]["report_id"], "R1")
        asked = select_report(three, "earlier", active_report_id="R3")
        self.assertEqual((asked["status"], [r["report_id"] for r in asked["options"]]), ("ask", ["R2", "R1"]))

    def test_history_is_for_one_canonical_patient_only(self):
        for pid in PIDS:
            with self.subTest(pid=pid):
                h = get_report_history(pid)
                self.assertEqual(h["patient_id"], pid)
                self.assertEqual([r["report_id"] for r in h["reports"]], [r["report_id"] for r in history(pid)])
        with self.assertRaises(PatientNotFoundError):
            get_report_history("P999")


class _dataset:
    """Point the service at a temporary COPY of the dataset for the duration of a block."""

    def __init__(self, data):
        self.dir = tempfile.mkdtemp(prefix="va_ds_")
        self.path = Path(self.dir) / "patients.json"
        self.path.write_text(json.dumps(data), encoding="utf-8")
        self.patch = mock.patch.object(service, "DATA_PATH", self.path)

    def __enter__(self):
        self.patch.start()
        return self

    def __exit__(self, *exc):
        self.patch.stop()
        for f in Path(self.dir).glob("*"):
            f.unlink()
        os.rmdir(self.dir)


# ───────────────────────────── conversation (real page, real backend) ─────────────────────────────
@unittest.skipUnless(HAVE_DEPS, "streamlit AppTest / uvicorn not installed")
class ContextBase(TmpCase):
    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.mkdtemp(prefix="va_ctx_")
        from voiceassistant.config import Settings
        from voiceassistant.pipeline import VoicePipeline

        settings = Settings.from_env({"STT_PROVIDER": "fake", "LLM_PROVIDER": "fake", "TTS_PROVIDER": "fake", "TMP_DIR": cls._tmp})
        pipeline = VoicePipeline(FakeSTT(), FakeLLM(), FakeTTS(), settings)
        cls.port = _free_port()
        cls.server = uvicorn.Server(uvicorn.Config(create_app(pipeline), host="127.0.0.1", port=cls.port, log_level="error"))
        cls.thread = threading.Thread(target=cls.server.run, daemon=True)
        cls.thread.start()
        for _ in range(100):
            if cls.server.started:
                break
            time.sleep(0.05)
        assert cls.server.started, "backend did not start"
        cls._env = mock.patch.dict(os.environ, {"DENTVOICE_API_URL": f"http://127.0.0.1:{cls.port}"})
        cls._env.start()
        cls._mic = mock.patch.object(dentvoice_mic, "_component", ScriptedMic())
        cls._mic.start()

    @classmethod
    def tearDownClass(cls):
        cls._mic.stop()
        cls._env.stop()
        cls.server.should_exit = True
        cls.thread.join(timeout=5)

    def app(self):
        at = AppTest.from_file(APP, default_timeout=30)
        at.run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        return at

    def say(self, at, text):
        at.chat_input[0].set_value(text).run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        return at.session_state["chat"][-1]["text"]

    def open_patient(self, at, pid):
        reply = self.say(at, f"Show the latest report for {pid}")
        self.assertEqual(at.session_state["active_patient"]["patient_id"], pid, reply)
        return reply

    def assert_evidence(self, reply, pid, report):
        for needle in (BY_ID[pid]["name"], pid, report["report_id"], report["date"]):
            self.assertIn(needle, reply)

    def assert_active(self, at, pid, report):
        self.assertEqual(at.session_state["active_patient"]["patient_id"], pid)
        got = at.session_state["active_report"]
        self.assertEqual((got["patient_id"], got["report"]["report_id"], got["report"]["date"]), (pid, report["report_id"], report["date"]))

    def assert_no_report_shown(self, at, reply, before):
        self.assertNotIn("Report date", reply)
        self.assertNotIn("Findings", reply)
        self.assertEqual(at.session_state["active_report"], before)


def _make_patient_tests():
    """One test per patient ID and behaviour (the ID is in every test name)."""

    def pronouns(pid):
        def t(self):
            at = self.app()
            self.open_patient(at, pid)
            latest = history(pid)[0]
            forms = [("What did {p} have in the latest report?", ("he", "she", "they")),
                     ("Open the latest report for {p}.", ("him", "her", "them")),
                     ("Show {p} latest report.", ("his", "her", "their")),
                     ("The latest report is {p}; open it.", ("his", "hers", "theirs"))]
            for tpl, prons in forms:
                for p in prons:
                    with self.subTest(pid=pid, sentence=tpl.format(p=p)):
                        reply = self.say(at, tpl.format(p=p))
                        self.assertNotIn("Which patient", reply)
                        self.assertNotIn("?", reply.split("Findings")[0].replace("Anything else?", ""))
                        self.assert_active(at, pid, latest)
                        self.assert_evidence(reply, pid, latest)
        return t

    def references(pid):
        def t(self):
            h = history(pid)
            at = self.app()
            for text, want in (("the latest one", h[0]), ("the latest report", h[0])):
                self.open_patient(at, pid)
                with self.subTest(pid=pid, text=text):
                    reply = self.say(at, text)
                    self.assert_active(at, pid, want)
                    self.assert_evidence(reply, pid, want)
            for text in ("the previous report", "the previous one", "the report before that one", "the old report", "the earlier examination"):
                self.open_patient(at, pid)  # active = latest, so previous/before that/old/earlier = the one older report
                with self.subTest(pid=pid, text=text):
                    reply = self.say(at, text)
                    self.assert_active(at, pid, h[1])
                    self.assert_evidence(reply, pid, h[1])
                    self.assertNotIn("Which patient", reply)
        return t

    def multi_turn(pid):
        def t(self):
            h = history(pid)
            at = self.app()
            self.open_patient(at, pid)
            for filler in ("hello there", "what can you do?", "tell me a joke", "thanks", "what is a root canal?"):
                self.say(at, filler)
            self.assertEqual(at.session_state["active_patient"]["patient_id"], pid)  # small talk never loses the patient
            reply = self.say(at, "Show her previous report")
            self.assert_active(at, pid, h[1])
            self.assert_evidence(reply, pid, h[1])
            reply = self.say(at, "and the previous report")  # walking back past the oldest report
            self.assertIn("no earlier", reply.lower())
            self.assertIn(pid, reply)
            self.assert_active(at, pid, h[1])
        return t

    def placement_case_fillers(pid):
        def t(self):
            h = history(pid)
            at = self.app()
            for text in ("Previous report, please open it for him", "Could you, when you have a moment today, open his previous report",
                         "SHOW HIS PREVIOUS REPORT", "show his previous report!!!", "show his, uh, previous report",
                         "Um, so, the previous report of theirs, if that is alright"):
                self.open_patient(at, pid)
                with self.subTest(pid=pid, text=text):
                    reply = self.say(at, text)
                    self.assert_active(at, pid, h[1])
                    self.assert_evidence(reply, pid, h[1])
        return t

    def types(pid):
        def t(self):
            h = history(pid)
            at = self.app()
            self.open_patient(at, pid)
            opg = [r for r in h if r["type"] == "OPG"][0]
            exam = [r for r in h if r["type"] == "Dental Examination"][0]
            reply = self.say(at, "Show her OPG report")
            self.assert_active(at, pid, opg)
            self.assert_evidence(reply, pid, opg)
            reply = self.say(at, "their last examination")
            self.assert_active(at, pid, exam)
            self.assert_evidence(reply, pid, exam)
        return t

    def again(pid):
        def t(self):
            h = history(pid)
            at = self.app()
            self.open_patient(at, pid)
            self.say(at, "show his previous report")
            self.assert_active(at, pid, h[1])
            reply = self.say(at, "open his latest report again")
            self.assert_active(at, pid, h[0])
            self.assert_evidence(reply, pid, h[0])
            self.assertEqual(at.session_state["active_patient"]["patient_id"], pid)
        return t

    def unrelated(pid):
        def t(self):
            at = self.app()
            self.open_patient(at, pid)
            before = at.session_state["active_report"]
            for text in ("what time does he arrive?", "she is late today", "they went home early", "give him my regards",
                         "is her appointment at nine?", "talk about the other day", "whether it rains there", "Hershey chocolate is great"):
                with self.subTest(pid=pid, text=text):
                    reply = self.say(at, text)
                    self.assert_no_report_shown(at, reply, before)
                    self.assertEqual(at.session_state["active_patient"]["patient_id"], pid)
        return t

    def pronoun_without_a_patient(pid):
        def t(self):
            at = self.app()  # fresh session: nothing identified yet, so a pronoun cannot be resolved -> ask, never guess
            reply = self.say(at, "Open the latest report for him")
            self.assertIn("Which patient", reply)
            self.assertIsNone(at.session_state["active_patient"])
        return t

    for pid in PIDS:
        for fn in (pronouns, references, multi_turn, placement_case_fillers, types, again, unrelated, pronoun_without_a_patient):
            setattr(ContextBase, f"test_{pid}_{fn.__name__}", fn(pid))


# Only the generated tests live on the concrete class, so the base runs nothing by itself.
@unittest.skipUnless(HAVE_DEPS, "streamlit AppTest / uvicorn not installed")
class PerPatientContextTests(ContextBase):
    pass


_make_patient_tests_target = PerPatientContextTests


def _install():
    # generated onto the concrete class (the loop above wrote onto ContextBase; move them over)
    for name in [n for n in vars(ContextBase) if n.startswith("test_P")]:
        setattr(PerPatientContextTests, name, vars(ContextBase)[name])
        delattr(ContextBase, name)


_make_patient_tests()
_install()


@unittest.skipUnless(HAVE_DEPS, "streamlit AppTest / uvicorn not installed")
class IdentificationConversationTests(ContextBase):
    def test_unique_full_names_open_directly_without_a_question(self):
        for p in REAL:
            if NAME_COUNT[p["name"]] != 1:
                continue
            with self.subTest(pid=p["patient_id"]):
                at = self.app()
                reply = self.say(at, f"Show the latest report for {p['name']}")
                self.assertNotIn("Which patient", reply)
                self.assert_active(at, p["patient_id"], history(p["patient_id"])[0])

    def test_duplicate_name_asks_once_then_the_answer_resumes_the_original_request_for_each_patient(self):
        for name in DUP_NAMES:
            for p in [x for x in REAL if x["name"] == name]:
                pid = p["patient_id"]
                for how, answer in (("id", pid), ("dob", p["date_of_birth"])):
                    with self.subTest(pid=pid, answer=how):
                        at = self.app()
                        ask = self.say(at, f"Show the latest OPG report for {name}")
                        self.assertIn("Multiple patients match that name.", ask)
                        for other in [x for x in REAL if x["name"] == name]:  # privacy: nobody is listed
                            self.assertNotIn(other["patient_id"], ask)
                            self.assertNotIn(other["date_of_birth"], ask)
                        reply = self.say(at, answer)
                        opg = [r for r in history(pid) if r["type"] == "OPG"][0]
                        self.assert_active(at, pid, opg)  # original request (OPG, latest) was resumed
                        self.assertIsNone(at.session_state["pending_report_name"])
                        for needle in (name, pid, opg["date"]):  # the existing (unchanged) report-opening wording
                            self.assertIn(needle, reply)
                        self.say(at, "and the previous one")  # context kept after the clarification
                        older = [r for r in history(pid) if r["date"] < opg["date"]]
                        if older:
                            self.assert_active(at, pid, older[0])
                        else:
                            self.assertEqual(at.session_state["active_patient"]["patient_id"], pid)

    def test_context_is_isolated_between_sessions(self):
        a, b = self.app(), self.app()
        self.open_patient(a, "P003")
        reply = self.say(b, "show his latest report")
        self.assertIn("Which patient", reply)
        self.assertIsNone(b.session_state["active_patient"])
        self.assertEqual(a.session_state["active_patient"]["patient_id"], "P003")

    def test_P001_P002_switching_patients_never_leaks_the_other_patients_report(self):
        at = self.app()
        self.open_patient(at, "P001")
        self.open_patient(at, "P002")
        self.say(at, "her previous report")
        self.assert_active(at, "P002", history("P002")[1])
        self.open_patient(at, "P001")
        self.say(at, "their previous report")
        self.assert_active(at, "P001", history("P001")[1])

    def test_pronouns_and_phrases_are_never_sent_to_the_patient_resolver_as_names(self):
        import voiceassistant.patient_resolver as pr
        import api_client  # the module the Streamlit page imports (frontend/ is on the path)
        DentVoiceClient = api_client.DentVoiceClient

        seen_resolver, seen_client = [], []
        real_resolve, real_latest = pr.resolve, DentVoiceClient.latest_report

        def spy_resolve(pool, *a, **k):
            seen_resolver.append(k.get("name", a[0] if a else None))
            return real_resolve(pool, *a, **k)

        def spy_latest(self_, **k):
            seen_client.append(k.get("name", ""))
            return real_latest(self_, **k)

        with mock.patch.object(pr, "resolve", spy_resolve), mock.patch.object(DentVoiceClient, "latest_report", spy_latest):
            at = self.app()
            self.open_patient(at, "P005")
            seen_resolver.clear(); seen_client.clear()
            phrases = [f"Open the latest report for {p}." for p in ("him", "her", "them")] + [
                "Show his latest report", "the previous report", "that patient's report", "the same patient's latest report",
                "that report", "show the report", "open the latest one", "her OPG report", "their last examination"]
            for text in phrases:
                self.say(at, text)
            self.assertEqual(at.session_state["active_patient"]["patient_id"], "P005")
        self.assertTrue(seen_client is not None)
        names = [str(n or "").strip().casefold() for n in seen_resolver + seen_client]
        self.assertFalse([n for n in names if n in NOT_NAMES or any(w in PRONOUNS for w in n.split())], names)
        self.assertEqual([n for n in seen_resolver if n], [], "contextual turns must not call the name resolver at all")


@unittest.skipUnless(HAVE_DEPS, "streamlit AppTest / uvicorn not installed")
class ZeroOneAndManyReportTests(ContextBase):
    """Temporary dataset copy: P003 has no reports, P004 exactly one, P005 three. Real data is untouched."""

    def dataset(self):
        data = copy.deepcopy(REAL)
        for p in data:
            if p["patient_id"] == "P003":
                p["reports"] = []
            elif p["patient_id"] == "P004":
                p["reports"] = p["reports"][:1]
            elif p["patient_id"] == "P005":
                old = copy.deepcopy(p["reports"][0]); old.update(report_id="R900", date="2026-01-05")
                p["reports"] = [old] + p["reports"]
        return data

    def test_P003_zero_reports_names_the_patient_and_id_and_never_asks_which_patient(self):
        with _dataset(self.dataset()):
            at = self.app()
            at.session_state["active_patient"] = {"name": BY_ID["P003"]["name"], "patient_id": "P003"}
            for text in ("show his report", "her latest report", "their OPG report", "the previous report", "open it again, the report"):
                with self.subTest(pid="P003", text=text):
                    reply = self.say(at, text)
                    self.assertIn("No reports are on file", reply)
                    self.assertIn(BY_ID["P003"]["name"], reply)
                    self.assertIn("P003", reply)
                    self.assertNotIn("Which patient", reply)
                    self.assertEqual(at.session_state["active_patient"]["patient_id"], "P003")

    def test_P004_exactly_one_report_opens_it_and_says_no_earlier_report_exists(self):
        only = BY_ID["P004"]["reports"][0]
        with _dataset(self.dataset()):
            at = self.app()
            at.session_state["active_patient"] = {"name": BY_ID["P004"]["name"], "patient_id": "P004"}
            reply = self.say(at, "show his report")
            self.assert_active(at, "P004", only)
            self.assert_evidence(reply, "P004", only)
            for text in ("the previous report", "the old report", "the report before that one", "her earlier examination"):
                with self.subTest(pid="P004", text=text):
                    reply = self.say(at, text)
                    self.assertIn("no earlier", reply.lower())
                    self.assertIn("P004", reply)
                    self.assert_active(at, "P004", only)
            other = "OPG" if only["type"] != "OPG" else "Dental Examination"
            reply = self.say(at, f"their {other} report")
            self.assertIn(f"no {other.lower()} report", reply.lower())
            self.assertNotIn(only["report_id"], reply)
            self.assert_active(at, "P004", only)

    def test_P005_several_older_reports_asks_which_and_the_answer_opens_that_report(self):
        data = self.dataset()
        with _dataset(data):
            at = self.app()
            at.session_state["active_patient"] = {"name": BY_ID["P005"]["name"], "patient_id": "P005"}
            self.say(at, "his latest report")
            self.assert_active(at, "P005", history("P005")[0])
            reply = self.say(at, "the old report")
            self.assertIn("Which one", reply)
            self.assertIn("R900", reply)
            self.assertIn(history("P005")[1]["report_id"], reply)
            reply = self.say(at, "R900")
            self.assert_active(at, "P005", {"report_id": "R900", "date": "2026-01-05"})
            self.assertIn("2026-01-05", reply)
            # 'previous' walks one step at a time from the active report
            self.say(at, "his latest report")
            self.say(at, "the previous report")
            self.assert_active(at, "P005", history("P005")[1])
            self.say(at, "the report before that one")
            self.assert_active(at, "P005", {"report_id": "R900", "date": "2026-01-05"})


if __name__ == "__main__":
    unittest.main()
