"""First-name query 'Open Priya's report': three patients match, so nothing is retrieved and nothing is leaked."""

from __future__ import annotations

import os
import unittest

from frontend.api_client import ApiError, DentVoiceClient
from tests import test_report_context as trc
from voiceassistant.dental import service
from voiceassistant.dental.report_intent import parse_report_request
from voiceassistant.dental.service import AmbiguousPatientError, get_latest_report, list_patient_candidates

REAL = trc.REAL
PRIYAS = [p for p in REAL if "priya" in p["name"].casefold().split()]
GENERIC = "Multiple patients match that name."
PHRASES = ("Open Priya's report", "open priya's report", "OPEN PRIYA'S REPORT", "Show Priya's latest report",
           "Open Priya report", "Can I get the latest report of Priya?", "Open Priya's latest OPG report")


def leaks(text):
    bad = [p["patient_id"] for p in REAL] + [p["date_of_birth"] for p in REAL] + [p["name"] for p in REAL]
    bad += [r["report_id"] for p in REAL for r in p["reports"]] + ["born", "Findings", "Report date", "Impression"]
    return [b for b in bad if b.casefold() in text.casefold()]


class BackendFirstNameLookupTests(unittest.TestCase):
    def test_three_patients_match_priya_in_the_real_dataset(self):
        self.assertEqual(sorted(p["patient_id"] for p in PRIYAS), ["P001", "P002", "P006"])
        self.assertEqual(sorted(c["patient_id"] for c in list_patient_candidates("Priya")), ["P001", "P002", "P006"])

    def test_the_backend_lookup_refuses_a_first_name_however_it_is_spelled_or_requested(self):
        for name in ("Priya", "priya", "PRIYA", " Priya ", "Priya's"):
            for kw in ({}, {"report_type": "OPG"}):
                with self.subTest(name=name, **kw):
                    with self.assertRaises(AmbiguousPatientError):
                        get_latest_report(name=name, **kw)

    def test_a_valid_id_retrieves_only_that_patients_report(self):
        for p in PRIYAS:
            with self.subTest(pid=p["patient_id"]):
                got = get_latest_report(name="Priya", patient_id=p["patient_id"])
                self.assertEqual(got["patient_id"], p["patient_id"])
                self.assertEqual(got["report"], trc.history(p["patient_id"])[0])

    def test_an_unknown_id_is_rejected_not_replaced_by_a_guess(self):
        with self.assertRaises(service.PatientNotFoundError):
            get_latest_report(name="Priya", patient_id="P999")

    def test_a_full_name_that_identifies_one_patient_still_works(self):
        self.assertEqual(get_latest_report(name="Priya Naik")["patient_id"], "P006")
        self.assertEqual(get_latest_report(name="Arjun Rao")["patient_id"], "P003")

    def test_a_first_name_with_a_dob_that_matches_one_patient_is_the_doctors_own_identifier(self):
        self.assertEqual(get_latest_report(name="Priya", date_of_birth="1988-11-03")["patient_id"], "P002")


class ParserKeepsTheNameTests(unittest.TestCase):
    def test_a_first_name_is_passed_on_as_a_name_with_or_without_an_apostrophe(self):
        for text in PHRASES:
            with self.subTest(text=text):
                self.assertEqual(parse_report_request(text).get("name", "").casefold(), "priya")

    def test_full_name_and_unknown_name_extraction_is_unchanged(self):
        self.assertEqual(parse_report_request("Can I get the reports of Priya Sharma?")["name"], "Priya Sharma")
        self.assertEqual(parse_report_request("Can I get the reports of Preethi Sharma?")["name"], "Preethi Sharma")


class PriyaConversationTests(trc.ContextBase):
    def asked(self, at, text, active=None):
        before = at.session_state["active_report"]
        reply = self.say(at, text)
        self.assertIn(GENERIC, reply)
        self.assertEqual(leaks(reply), [], reply)
        self.assertEqual(at.session_state["active_report"], before, "no report may be retrieved")
        self.assertEqual((at.session_state["active_patient"] or {}).get("patient_id"), active)
        self.assertEqual(at.session_state["pending_report_name"].casefold(), "priya")
        return reply

    def test_P001_P002_P006_first_name_asks_and_retrieves_nothing(self):
        for text in PHRASES:
            with self.subTest(text=text):
                self.asked(self.app(), text)

    def test_P003_an_already_open_patient_is_not_substituted_for_the_named_first_name(self):
        for text in PHRASES:
            with self.subTest(text=text):
                at = self.app()
                self.open_patient(at, "P003")
                self.asked(at, text, active="P003")

    def test_P001_the_first_and_other_ordinals_never_choose_between_unlisted_patients(self):
        for answer in ("the first", "the second patient", "third one", "Priya", "yes"):
            with self.subTest(answer=answer):
                at = self.app()
                self.say(at, "Open Priya's report")
                self.say(at, answer)
                self.assertIsNone(at.session_state["active_report"])
                self.assertIsNone(at.session_state["active_patient"])

    def test_P001_P002_P006_the_intended_patient_is_identified_by_id_and_only_that_report_opens(self):
        for p in PRIYAS:
            pid = p["patient_id"]
            with self.subTest(pid=pid):
                at = self.app()
                self.asked(at, "Open Priya's report")
                reply = self.say(at, pid)
                self.assert_active(at, pid, trc.history(pid)[0])
                self.assertIn(pid, reply)
                self.assertIsNone(at.session_state["pending_report_name"])

    def test_P001_a_wrong_or_unknown_id_opens_nothing(self):
        at = self.app()
        self.asked(at, "Open Priya's report")
        self.say(at, "P999")
        self.assertIsNone(at.session_state["active_report"])

    def test_P003_P004_P005_unique_full_names_still_open_directly(self):
        for pid in ("P003", "P004", "P005"):
            with self.subTest(pid=pid):
                at = self.app()
                name = trc.BY_ID[pid]["name"]
                reply = self.say(at, f"Open {name}'s report")
                self.assertNotIn(GENERIC, reply)
                self.assert_active(at, pid, trc.history(pid)[0])

    def test_P006_full_name_priya_naik_opens_directly_while_priya_alone_does_not(self):
        at = self.app()
        self.say(at, "Open Priya Naik's report")
        self.assert_active(at, "P006", trc.history("P006")[0])

    def test_the_generated_speech_for_the_question_carries_no_identifying_detail(self):
        from unittest import mock

        import api_client  # the module the Streamlit page itself imports (frontend/ is on the path)

        spoken = []
        real = api_client.DentVoiceClient.tts

        def spy(self_, text):
            spoken.append(text)
            return real(self_, text)

        with mock.patch.object(api_client.DentVoiceClient, "tts", spy):
            at = self.app()
            spoken.clear()
            self.say(at, "Open Priya's report")
        self.assertTrue(spoken, "the question is spoken")
        for text in spoken:
            self.assertIn("Multiple patients match", text)
            self.assertEqual(leaks(text), [], text)

    def test_P001_api_returns_the_generic_409_for_a_first_name_and_leaks_nothing(self):
        client = DentVoiceClient(os.environ["DENTVOICE_API_URL"])
        with self.assertRaises(ApiError) as ctx:
            client.latest_report(name="Priya")
        self.assertEqual(ctx.exception.status, 409)
        self.assertEqual(leaks(ctx.exception.message), [])


if __name__ == "__main__":
    unittest.main()
