"""Regression tests for AI Assistant conversation flow and silence timeout handling:
1. Configurable silence timeouts (SILENCE_TIMEOUT_SECONDS = 15, CLARIFICATION_TIMEOUT_SECONDS = 30).
2. Natural greeting with 'What are you looking for today, Doctor?' without duplicate questions.
3. Natural follow-up question ('Anything else, Doctor?') asked only on completed requests.
4. Clarification questions ('Which patient do you mean?') do not append follow-ups and use 30s timeout.
5. Timer starts strictly AFTER assistant finishes speaking (respecting audio duration).
6. Inactivity timeout ends voice session cleanly, preserving chat history, reports, and drafts.
7. Silence / empty audio is never submitted as an answer.
8. New speech resets the timeout timer.
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

_ROOT = Path(__file__).resolve().parent.parent
_FRONTEND = _ROOT / "frontend"
for _p in (str(_ROOT), str(_FRONTEND)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from voiceassistant.config import (
    CLARIFICATION_TIMEOUT_SECONDS,
    SILENCE_TIMEOUT_SECONDS,
    Settings,
)
from frontend.sections.assistant import (
    _append_natural_followup,
    _ensure_greeting_question,
    _get_time_greeting,
)


class ConfigurableTimeoutTests(unittest.TestCase):
    """Test that silence timeouts are configurable and default to 15s and 30s."""

    def test_constants_defined(self):
        self.assertEqual(SILENCE_TIMEOUT_SECONDS, 15)
        self.assertEqual(CLARIFICATION_TIMEOUT_SECONDS, 30)

    def test_settings_defaults(self):
        s = Settings.from_env({})
        self.assertEqual(s.silence_timeout_seconds, 15)
        self.assertEqual(s.clarification_timeout_seconds, 30)

    def test_settings_env_overrides(self):
        s = Settings.from_env({
            "SILENCE_TIMEOUT_SECONDS": "20",
            "CLARIFICATION_TIMEOUT_SECONDS": "45",
        })
        self.assertEqual(s.silence_timeout_seconds, 20)
        self.assertEqual(s.clarification_timeout_seconds, 45)


class NaturalConversationFlowTests(unittest.TestCase):
    """Test natural greeting and follow-up question logic."""

    def test_greeting_includes_question_naturally(self):
        with patch("frontend.sections.assistant.datetime") as mock_dt:
            mock_dt.now.return_value.hour = 10
            greeting = _get_time_greeting()
            self.assertIn("How can I help you", greeting)
            self.assertIn("Good morning", greeting)

    def test_ensure_greeting_does_not_repeat_question(self):
        base = "Good afternoon, Doctor! 👋 I'm DentVoice AI. How can I help you today? You can ask me to retrieve a patient report, summarize findings, or prepare a clinical dictation draft."
        ensured = _ensure_greeting_question(base)
        self.assertEqual(ensured, base)
        self.assertEqual(ensured.lower().count("how can i help you"), 1)

    def test_ensure_greeting_adds_question_if_missing(self):
        base = "Good evening, Doctor"
        ensured = _ensure_greeting_question(base)
        self.assertEqual(ensured, "Good evening, Doctor! How can I help you today, Doctor?")

    def test_followup_added_after_completed_request(self):
        completed_reply = "Latest OPG report for Priya Sharma. Findings: No findings recorded. Clinician review required."
        with_followup = _append_natural_followup(completed_reply, is_clarification=False)
        self.assertTrue(with_followup.endswith("Anything else, Doctor?"))

    def test_no_followup_on_clarification_question(self):
        clarification = "Which patient do you mean? Please provide the patient's full name or patient ID."
        result = _append_natural_followup(clarification, is_clarification=True)
        self.assertEqual(result, clarification)
        self.assertNotIn("Anything else", result)

    def test_no_duplicate_followup_if_already_present(self):
        text_with_followup = "Here is the report. Anything else, Doctor?"
        result = _append_natural_followup(text_with_followup, is_clarification=False)
        self.assertEqual(result, text_with_followup)
        self.assertEqual(result.count("Anything else"), 1)


class SilenceTimeoutBehaviorTests(unittest.TestCase):
    """The idle timer now lives in the browser (see tests/browser). Python only reacts to the browser's report."""

    def setUp(self):
        import streamlit as st
        from frontend.sections.assistant import _init
        st.session_state.clear()
        _init()
        st.session_state.dv_listening = True
        st.session_state.chat = [{"role": "assistant", "text": "Hello"}]
        st.session_state.active_report = {"report_id": "R001"}

    def test_idle_timeout_report_stops_listening_cleanly_preserving_data(self):
        import streamlit as st
        from dentvoice_mic import MicAction
        from frontend.sections.assistant import _apply_event, _voice_status
        _apply_event(MicAction("e1", "idle_timeout"))
        self.assertFalse(st.session_state.dv_listening)
        self.assertTrue(st.session_state.dv_standby)
        self.assertEqual(_voice_status()[0], "standby")
        self.assertIn(f"{SILENCE_TIMEOUT_SECONDS} seconds", st.session_state.timeout_message)
        self.assertEqual(len(st.session_state.chat), 1)
        self.assertEqual(st.session_state.active_report["report_id"], "R001")

    def test_clarification_flag_is_independent_of_audio(self):
        import streamlit as st
        from frontend.sections.assistant import _queue_reply_audio
        _queue_reply_audio(None, is_clarification=True)           # no audio at all
        self.assertTrue(st.session_state.is_clarification)
        _queue_reply_audio(b"RIFF....WAVE" + b"\x00" * 64, is_clarification=False)
        self.assertFalse(st.session_state.is_clarification)


if __name__ == "__main__":
    unittest.main()
