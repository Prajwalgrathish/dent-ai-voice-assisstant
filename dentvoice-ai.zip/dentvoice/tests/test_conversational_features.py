"""Regression tests for conversational voice-first features:
1. Time-appropriate session greeting logic.
2. Voice-command navigation to Clinical Dictation and intent segregation.
3. Contextual follow-up and summary handling.
4. Explicit patient ID retrieval and summaries.
5. PDF report generation and download endpoints.
6. Clinical dictation workflow, structured schema preservation, and session conclusion.
"""

import sys
from pathlib import Path
import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient

# Ensure workspace root and frontend folder are discoverable in all test environments
_ROOT = Path(__file__).resolve().parent.parent
_FRONTEND = _ROOT / "frontend"
for _p in (str(_ROOT), str(_FRONTEND)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from voiceassistant.api import create_app
from voiceassistant.config import Settings
from voiceassistant.dental.pdf import generate_patient_report_pdf
from voiceassistant.dental.report_intent import (
    is_dictation_intent,
    is_pdf_intent,
    is_summary_intent,
    parse_report_request,
)
from voiceassistant.dental.service import get_latest_report
from voiceassistant.factory import build_pipeline
from frontend.sections.assistant import _get_time_greeting


class SessionGreetingTests(unittest.TestCase):
    """The greeting follows the doctor's LOCAL hour (spec wording: morning / afternoon / evening / night)."""

    def _greeting_at(self, hour):
        with patch("frontend.sections.assistant.datetime") as mock_dt:
            mock_dt.now.return_value.hour = hour
            return _get_time_greeting()

    def test_morning_greeting(self):
        self.assertEqual(self._greeting_at(9), "Good morning, Doctor. Welcome to DentVoice AI. How can I help you?")

    def test_afternoon_greeting(self):
        self.assertEqual(self._greeting_at(14), "Good afternoon, Doctor. How can I help you?")

    def test_evening_greeting(self):
        self.assertEqual(self._greeting_at(19), "Good evening, Doctor. How can I help you?")

    def test_night_greeting(self):
        self.assertEqual(self._greeting_at(23), "Hello, Doctor. How can I help you tonight?")
        self.assertEqual(self._greeting_at(2), "Hello, Doctor. How can I help you tonight?")


class DictationNavigationIntentTests(unittest.TestCase):
    """Test voice commands that open Clinical Dictation vs requests that stay in Assistant."""

    def test_dictation_navigation_phrases_trigger_intent(self):
        phrases = [
            "Open Clinical Dictation.",
            "I want to dictate a clinical note.",
            "I want to create a draft.",
            "Let me record some clinical notes.",
            "I need to prepare a patient report.",
            "I want to dictate a report.",
            "Start clinical dictation please",
            "Switch to clinical dictation",
        ]
        for phrase in phrases:
            with self.subTest(phrase=phrase):
                self.assertTrue(
                    is_dictation_intent(phrase),
                    f"Expected is_dictation_intent=True for '{phrase}'",
                )

    def test_report_requests_do_not_trigger_dictation_navigation(self):
        non_dictation_phrases = [
            "Show me Priya Sharma's latest report.",
            "Summarize her report.",
            "Download that report as a PDF.",
            "Find the OPG report for Meera Nair.",
            "Show me Arjun Rao's report.",
            "What is in her report?",
            "Can I see the examination report?",
        ]
        for phrase in non_dictation_phrases:
            with self.subTest(phrase=phrase):
                self.assertFalse(
                    is_dictation_intent(phrase),
                    f"Expected is_dictation_intent=False for '{phrase}'",
                )


class ContextualSummaryAndFollowUpTests(unittest.TestCase):
    """Test contextual follow-up requests and explicit patient ID handling."""

    def test_summary_intent_detection(self):
        self.assertTrue(is_summary_intent("Summarize her report."))
        self.assertTrue(is_summary_intent("Can you summarize the report?"))
        self.assertTrue(is_summary_intent("Give me a summary of her report"))
        self.assertFalse(is_summary_intent("Show me the latest report"))

    def test_explicit_patient_id_in_report_request(self):
        parsed = parse_report_request("Summarize report for P003")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.get("patient_id"), "P003")

    def test_explicit_patient_id_retrieves_correct_record(self):
        data = get_latest_report(patient_id="P003")
        self.assertEqual(data["patient_id"], "P003")
        self.assertEqual(data["patient_name"], "Arjun Rao")
        self.assertEqual(data["report"]["report_id"], "R006")


class PdfGenerationAndDownloadTests(unittest.TestCase):
    """Test PDF generation, schema completeness, and API endpoint."""

    def test_pdf_intent_detection(self):
        self.assertTrue(is_pdf_intent("Download that report as a PDF."))
        self.assertTrue(is_pdf_intent("Download report as PDF"))
        self.assertTrue(is_pdf_intent("Export as PDF please"))
        self.assertTrue(is_pdf_intent("Can I get a PDF of the report?"))
        self.assertFalse(is_pdf_intent("Show me the report"))

    def test_pdf_bytes_generation_and_headers(self):
        test_report = {
            "report_id": "R006",
            "type": "Dental Examination",
            "date": "2026-10-05",
            "findings": ["Synthetic example: routine examination documented."],
            "impression": "Synthetic training report. Clinician review required.",
        }
        pdf = generate_patient_report_pdf(
            patient_name="Arjun Rao",
            patient_id="P003",
            report=test_report,
            date_of_birth="2001-02-18",
            phone_contact="DEMO-0003",
        )
        self.assertTrue(pdf.startswith(b"%PDF-1.4"))
        self.assertIn(b"%%EOF", pdf)
        self.assertIn(b"Arjun Rao", pdf)
        self.assertIn(b"P003", pdf)
        self.assertIn(b"Dental Examination", pdf)
        self.assertIn(b"SYNTHETIC DATA", pdf)
        self.assertIn(b"CLINICIAN REVIEW REQUIRED", pdf)

    def test_pdf_api_endpoint_success(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post("/v1/dental/reports/pdf", json={"patient_id": "P003"})
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.headers["content-type"], "application/pdf")
        self.assertIn("DentVoice_Report_P003_R006.pdf", res.headers.get("content-disposition", ""))
        self.assertTrue(res.content.startswith(b"%PDF-1.4"))

    def test_pdf_api_endpoint_ambiguous_returns_409(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post("/v1/dental/reports/pdf", json={"name": "Priya Sharma"})
        self.assertEqual(res.status_code, 409)

    def test_pdf_api_endpoint_not_found_returns_404(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post("/v1/dental/reports/pdf", json={"patient_id": "P999"})
        self.assertEqual(res.status_code, 404)


class ClinicalDictationWorkflowTests(unittest.TestCase):
    """Test clinical dictation schema preservation and completion logic."""

    def test_clinical_dictation_schema_preserved(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post(
            "/v1/clinical/dictation",
            json={"transcript": "Lower right third molar is possibly horizontally impacted"},
        )
        self.assertEqual(res.status_code, 200)
        data = res.json()

        # Strict preservation of established fields
        required_keys = {
            "original_transcript",
            "findings",
            "anatomical_site",
            "readable_draft",
            "uncertainty_detected",
            "uncertainty_note",
            "requires_clinician_review",
            "synthetic_data",
        }
        self.assertTrue(required_keys.issubset(data.keys()))
        self.assertTrue(data["uncertainty_detected"])
        self.assertEqual(data["findings"][0]["certainty"], "uncertain_as_dictated")
        self.assertEqual(data["findings"][0]["anatomical_site"], "Lower right third molar")

    def test_tts_endpoint_functional(self):
        app = create_app(build_pipeline(Settings(stt_provider="fake", llm_provider="fake", tts_providers=("fake",))))
        client = TestClient(app)
        res = client.post(
            "/v1/tts",
            json={"text": "Opening Clinical Dictation, Doctor. You can start recording whenever you're ready."},
        )
        self.assertEqual(res.status_code, 200)
        body = res.json()
        self.assertIn("audio_wav_base64", body)
        self.assertEqual(body["tts_engine"], "fake_tts")


if __name__ == "__main__":
    unittest.main()
