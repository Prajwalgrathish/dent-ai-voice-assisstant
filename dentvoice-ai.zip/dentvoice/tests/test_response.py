import unittest

from voiceassistant.response import chunk_text


class ChunkTextTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(chunk_text("   \n ", 50), [])

    def test_short_text_single_chunk(self):
        self.assertEqual(chunk_text("Hello there.", 50), ["Hello there."])

    def test_splits_on_sentences_and_respects_limit(self):
        text = "First sentence here. Second sentence here. Third sentence here."
        chunks = chunk_text(text, 30)
        self.assertEqual(chunks, ["First sentence here.", "Second sentence here.", "Third sentence here."])
        self.assertTrue(all(len(c) <= 30 for c in chunks))

    def test_packs_sentences_greedily(self):
        chunks = chunk_text("A b. C d. E f. G h.", 12)
        self.assertEqual(chunks, ["A b. C d.", "E f. G h."])

    def test_long_sentence_split_on_spaces_without_losing_words(self):
        text = " ".join(f"word{i}" for i in range(40))
        chunks = chunk_text(text, 40)
        self.assertTrue(all(len(c) <= 40 for c in chunks))
        self.assertEqual(" ".join(chunks), text)

    def test_unbreakable_token_hard_split(self):
        chunks = chunk_text("x" * 95, 40)
        self.assertEqual("".join(chunks), "x" * 95)
        self.assertTrue(all(len(c) <= 40 for c in chunks))


if __name__ == "__main__":
    unittest.main()
