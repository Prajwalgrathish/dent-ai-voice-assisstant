"""Branding, CSS and small HTML helpers for DentVoice AI (navy + teal)."""

from __future__ import annotations

import base64
import html

import streamlit as st

NAVY = "#0B1F3A"
TEAL = "#14B8A6"

# Tooth silhouette with a sound-wave (five rounded bars) inside it.
_LOGO_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
<stop offset="0" stop-color="#2DD4BF"/><stop offset="1" stop-color="#0D9488"/></linearGradient></defs>
<path fill="url(#g)" d="M32 12C26 8 14 9 13 21C12.5 28 16 33 17 40C18 48 19.5 56 24 56C28 56 28.5 46 32 46C35.5 46 36 56 40 56C44.5 56 46 48 47 40C48 33 51.5 28 51 21C50 9 38 8 32 12Z"/>
<g fill="#FFFFFF">
<rect x="20.3" y="24" width="3.4" height="8" rx="1.7"/>
<rect x="25.3" y="20" width="3.4" height="16" rx="1.7"/>
<rect x="30.3" y="15" width="3.4" height="26" rx="1.7"/>
<rect x="35.3" y="20" width="3.4" height="16" rx="1.7"/>
<rect x="40.3" y="24" width="3.4" height="8" rx="1.7"/>
</g></svg>"""


def logo_img(size: int = 44) -> str:
    uri = "data:image/svg+xml;base64," + base64.b64encode(_LOGO_SVG.encode()).decode()
    return f'<img src="{uri}" width="{size}" height="{size}" alt="DentVoice AI logo"/>'


_CSS = """
<style>
html, body, [class*="css"] { font-family: "Inter","Segoe UI",system-ui,sans-serif; }
.stApp { background: #F3F7FA; }
header[data-testid="stHeader"] { background: transparent; }
.block-container { padding-top: 1.4rem; max-width: 1220px; }

/* ---------- sidebar ---------- */
section[data-testid="stSidebar"] {
  background: linear-gradient(180deg, #0B1F3A 0%, #0F2A50 100%);
  border-right: 1px solid #12315C;
}
section[data-testid="stSidebar"] label,
section[data-testid="stSidebar"] .stMarkdown p,
section[data-testid="stSidebar"] [data-testid="stCaptionContainer"],
section[data-testid="stSidebar"] [data-testid="stWidgetLabel"] p { color: #DCEAF4 !important; }
section[data-testid="stSidebar"] input {
  background: #0E2A4F !important; color: #FFFFFF !important; border: 1px solid #28508A !important;
}
section[data-testid="stSidebar"] hr { border-color: #1D3F6E; }
section[data-testid="stSidebar"] [role="radiogroup"] { gap: .25rem; }
section[data-testid="stSidebar"] [role="radiogroup"] label {
  padding: .6rem .8rem; border-radius: 10px; border-left: 3px solid transparent; width: 100%;
}
section[data-testid="stSidebar"] [role="radiogroup"] label > div:first-child { display: none; }
section[data-testid="stSidebar"] [role="radiogroup"] label:hover { background: rgba(255,255,255,.06); }
section[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) {
  background: rgba(20,184,166,.18); border-left-color: #14B8A6;
}
section[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) p { color: #FFFFFF !important; font-weight: 600; }
.dv-brand { display:flex; align-items:center; gap:.7rem; padding:.2rem 0 1rem 0; }
.dv-brand-name { font-size:1.35rem; font-weight:700; color:#FFFFFF; line-height:1.1; }
.dv-brand-name span { color:#2DD4BF; }
.dv-brand-tag { font-size:.72rem; letter-spacing:.08em; text-transform:uppercase; color:#8FB3D1; }

/* ---------- page header ---------- */
.dv-header {
  background: linear-gradient(110deg, #0B1F3A 0%, #12315C 70%, #0F766E 130%);
  border-radius: 16px; padding: 1.2rem 1.5rem; margin-bottom: 1.1rem;
  border-bottom: 4px solid #14B8A6; box-shadow: 0 4px 14px rgba(11,31,58,.18);
}
.dv-header-title { color:#FFFFFF; font-size:1.55rem; font-weight:700; }
.dv-header-sub { color:#B9D3E6; font-size:.92rem; margin-top:.15rem; }

/* ---------- cards, chips, notes ---------- */
.dv-card {
  background:#FFFFFF; border:1px solid #DCE5EC; border-radius:14px;
  padding:1rem 1.2rem; box-shadow:0 1px 3px rgba(11,31,58,.06); margin-bottom:.8rem;
}
.dv-card h4 { margin:0 0 .4rem 0; color:#0B1F3A; font-size:1rem; }
.dv-label { font-size:.72rem; letter-spacing:.07em; text-transform:uppercase; color:#5B6B80; margin-bottom:.1rem; }
.dv-value { font-size:1.05rem; font-weight:600; color:#0B1F3A; }
.dv-chip {
  display:inline-block; padding:.18rem .65rem; border-radius:999px; font-size:.78rem;
  font-weight:600; margin:0 .3rem .3rem 0; background:#E6EEF4; color:#0B1F3A;
}
.dv-chip.ok   { background:#D1F5EE; color:#0B6B60; }
.dv-chip.warn { background:#FEF3C7; color:#92400E; }
.dv-chip.bad  { background:#FEE2E2; color:#991B1B; }
.dv-chip.navy { background:#0B1F3A; color:#FFFFFF; }
.dv-note { border-radius:10px; padding:.6rem .9rem; font-size:.88rem; margin:.4rem 0; border-left:4px solid #14B8A6; background:#E8F8F5; color:#0B3B36; }
.dv-note.warn { border-left-color:#F59E0B; background:#FFF8E6; color:#7A4A06; }
.dv-note.bad  { border-left-color:#DC2626; background:#FEECEC; color:#7F1D1D; }

/* ---------- native widgets ---------- */
[data-testid="stChatMessage"] { background:#FFFFFF; border:1px solid #DCE5EC; border-radius:14px; }
.stButton > button, .stDownloadButton > button { border-radius:10px; font-weight:600; }
.stTextArea textarea, .stTextInput input { border-radius:10px; }
[data-testid="stExpander"] { background:#FFFFFF; border-radius:12px; border:1px solid #DCE5EC; }
/* ---------- replay players stay visible (compact): they are the manual way to hear a reply when the browser
   blocks automatic audio. New replies are played and reported by the microphone component, not by these. ---------- */
div[data-testid="stAudio"] audio { height: 38px; }
</style>
"""


def apply_theme() -> None:
    st.markdown(_CSS, unsafe_allow_html=True)


def sidebar_brand() -> None:
    st.markdown(
        f'<div class="dv-brand">{logo_img(46)}<div>'
        '<div class="dv-brand-name">DentVoice <span>AI</span></div>'
        '<div class="dv-brand-tag">Clinical voice workspace</div></div></div>',
        unsafe_allow_html=True,
    )


def page_header(title: str, subtitle: str) -> None:
    st.markdown(
        f'<div class="dv-header"><div class="dv-header-title">{html.escape(title)}</div>'
        f'<div class="dv-header-sub">{html.escape(subtitle)}</div></div>',
        unsafe_allow_html=True,
    )


def chip(text: str, kind: str = "") -> str:
    """Return chip HTML (text is escaped). kind: ok | warn | bad | navy | ''."""
    return f'<span class="dv-chip {kind}">{html.escape(str(text))}</span>'


def note(text: str, kind: str = "") -> None:
    """Render a callout. kind: '' (info) | warn | bad."""
    st.markdown(f'<div class="dv-note {kind}">{html.escape(text)}</div>', unsafe_allow_html=True)


def field(label: str, value: str) -> str:
    return (f'<div class="dv-label">{html.escape(label)}</div>'
            f'<div class="dv-value">{html.escape(str(value) if value not in (None, "") else "—")}</div>')
