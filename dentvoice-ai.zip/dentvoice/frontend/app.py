"""DentVoice AI - Streamlit frontend.

Run from this folder so .streamlit/config.toml (the navy/teal theme) is picked up:
    streamlit run app.py
The backend is NOT started here; run the existing FastAPI app separately.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

# The sections import the backend package (voiceassistant) that lives one folder up; make that work
# no matter which directory `streamlit run` is started from.
_ROOT = str(Path(__file__).resolve().parent.parent)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import streamlit as st

import theme
from api_client import ApiError, DentVoiceClient
from sections import assistant, dictation, patient_voice, reports

st.set_page_config(page_title="DentVoice AI", page_icon="🦷", layout="wide")
theme.apply_theme()

from api_client import _setting  # noqa: E402

DEFAULT_API_URL = _setting("DENTVOICE_API_URL", "http://127.0.0.1:8000")
PAGES = {
    "AI Assistant": assistant,
    "Patient Reports": reports,
    "Clinical Dictation": dictation,
    "Patient Voice Assistant": patient_voice,
}
HEALTH_TTL_SECONDS = 20


def _refresh_health(client: DentVoiceClient, force: bool = False) -> None:
    ss = st.session_state
    stale = time.time() - ss.get("health_at", 0) > HEALTH_TTL_SECONDS
    if force or stale or ss.get("health_url") != client.base_url:
        try:
            ss["health"], ss["health_error"] = client.health(), None
        except ApiError as exc:
            ss["health"], ss["health_error"] = None, exc.message
        ss["health_at"], ss["health_url"] = time.time(), client.base_url


def render_sidebar() -> tuple[DentVoiceClient, str]:
    # A section may ask to switch pages (e.g. "Open Clinical Dictation"). That has to happen BEFORE the radio
    # below is created: Streamlit forbids changing a widget's key after the widget exists in the same run.
    pending = st.session_state.pop("pending_nav", None)
    if pending in PAGES:
        st.session_state["nav"] = pending
    with st.sidebar:
        theme.sidebar_brand()
        st.session_state.setdefault("nav", "AI Assistant")
        page = st.radio("Navigation", list(PAGES), label_visibility="collapsed", key="nav")
        st.divider()

        api_url = st.text_input("Backend URL", value=DEFAULT_API_URL, key="api_url",
                                help="Local FastAPI server. Override the default with $env:DENTVOICE_API_URL.")
        client = DentVoiceClient(api_url)
        _refresh_health(client)

        health, error = st.session_state.get("health"), st.session_state.get("health_error")
        if health:
            st.markdown(
                theme.chip("Backend online", "ok")
                + theme.chip(f"STT {health.get('stt', '?')}", "navy")
                + theme.chip(f"LLM {health.get('llm', '?')}", "navy")
                + theme.chip(f"TTS {health.get('tts', '?')}", "navy"),
                unsafe_allow_html=True,
            )
        else:
            st.markdown(theme.chip("Backend offline", "bad"), unsafe_allow_html=True)
            st.caption(error or "No response from the backend.")
        if st.button("Check connection", use_container_width=True):
            _refresh_health(client, force=True)
            st.rerun()

        st.divider()
        st.caption("Local-only. Patient data is synthetic demo data. All clinical output requires "
                   "clinician review.")
    return client, page


def main() -> None:
    client, page = render_sidebar()
    PAGES[page].render(client)


main()
