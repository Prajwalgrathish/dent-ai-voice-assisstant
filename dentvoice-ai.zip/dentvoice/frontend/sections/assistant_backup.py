"""AI Assistant: chat with text input and microphone / audio-file controls.

Backend calls: /v1/turn (typed or reviewed speech), /v1/stt (transcribe for review),
/v1/turn/audio (one-step voice turn).
"""

from __future__ import annotations

import re
from contextlib import nullcontext

import streamlit as st

import theme
from api_client import ALLOWED_AUDIO_EXTENSIONS, ApiError, DentVoiceClient, decode_audio

HAS_MIC = hasattr(st, "audio_input")  # Streamlit >= 1.39


def _init() -> None:
    ss = st.session_state
    ss.setdefault("chat", [])          # list of message dicts
    ss.setdefault("auto_play", True)
    ss.setdefault("mic_nonce", 0)      # bumping it resets the recorder / uploader widgets
    ss.setdefault("pending_stt", None)  # transcript awaiting review: {"confidence","low","provider"}
    ss.setdefault("assistant_mode", "Text")
    ss.setdefault("pending_report_name", None)  # report request awaiting DOB, patient ID, or contact


def _transcript_meta(t: dict | None) -> tuple[str, bool]:
    if not t:
        return "voice input", False
    conf = t.get("confidence")
    conf_txt = f" · confidence {conf:.0%}" if isinstance(conf, (int, float)) else ""
    return f"voice · {t.get('provider') or 'stt'}{conf_txt}", bool(t.get("low_confidence"))


def _add_turn(user_text: str, user_meta: str, user_warn: bool, resp: dict) -> None:
    ss = st.session_state
    ss.chat.append({"role": "user", "text": user_text, "meta": user_meta,
                    "warn": "Low transcription confidence. Please double-check this text." if user_warn else None})
    audio = decode_audio(resp.get("audio_wav_base64"))
    warn = None
    if resp.get("tts_error"):
        warn = f"Spoken reply unavailable ({resp['tts_error']}). The text reply is still valid."
    elif not audio:
        warn = "No audio was returned for this reply."
    ss.chat.append({
        "role": "assistant", "text": resp.get("reply_text", ""),
        "meta": f"spoken by {resp['tts_engine']}" if audio and resp.get("tts_engine") else None,
        "warn": warn, "audio": audio, "autoplay": bool(audio) and ss.auto_play,
    })


def _add_error(user_text: str | None, user_meta: str, exc: ApiError) -> None:
    ss = st.session_state
    if user_text:
        ss.chat.append({"role": "user", "text": user_text, "meta": user_meta})
    stage = f" ({exc.stage})" if exc.stage else ""
    ss.chat.append({"role": "assistant", "text": "", "error": f"{exc.message}{stage}"})


def _reset_voice_widgets() -> None:
    st.session_state.mic_nonce += 1
    st.session_state.pending_stt = None
    st.session_state.pop("voice_text", None)


def _render_history() -> None:
    chat = st.session_state.chat
    if not chat:
        st.markdown(
            '<div class="dv-card"><h4>How can I help?</h4>Choose Text to type, or Voice to speak naturally. '
            'Patient-report requests are routed to the existing report API; ordinary questions go to the assistant.</div>',
            unsafe_allow_html=True)
    for msg in chat:
        with st.chat_message(msg["role"], avatar="🧑‍⚕️" if msg["role"] == "user" else "🦷"):
            if msg.get("error"):
                st.error(msg["error"])
                continue
            st.markdown(msg["text"])
            if msg.get("meta"):
                st.caption(msg["meta"])
            if msg.get("warn"):
                st.warning(msg["warn"])
            if msg.get("audio"):
                st.audio(msg["audio"], format="audio/wav", autoplay=msg.pop("autoplay", False))


def _voice_panel(client: DentVoiceClient) -> None:
    ss = st.session_state
    with nullcontext():
        audio_bytes, filename = None, "recording.wav"
        tabs = st.tabs(["Microphone", "Upload audio file"])
        with tabs[0]:
            if HAS_MIC:
                rec = st.audio_input("Record your question", key=f"mic_{ss.mic_nonce}")
                if rec is not None:
                    audio_bytes, filename = rec.getvalue(), "recording.wav"
            else:
                st.info("This Streamlit version has no microphone widget. Upgrade with "
                        "`pip install -U streamlit`, or use the upload tab.")
        with tabs[1]:
            up = st.file_uploader("Audio file", type=list(ALLOWED_AUDIO_EXTENSIONS), key=f"up_{ss.mic_nonce}")
            if up is not None:
                audio_bytes, filename = up.getvalue(), up.name

        c1, c2 = st.columns(2)
        review = c1.button("Transcribe & review", disabled=audio_bytes is None, use_container_width=True,
                           help="Speech-to-text only. You can correct the text before it is sent.")
        direct = c2.button("Send voice directly", disabled=audio_bytes is None, use_container_width=True,
                           help="One step: speech-to-text, assistant reply and spoken answer.")

        if review and audio_bytes:
            try:
                with st.spinner("Transcribing…"):
                    t = client.stt(audio_bytes, filename)
                ss.pending_stt = {"confidence": t.get("confidence"), "low": bool(t.get("low_confidence")),
                                  "provider": t.get("provider", "")}
                ss["voice_text"] = t.get("text", "")  # set before the text_area below is created
            except ApiError as exc:
                st.error(f"{exc.message}" + (f" ({exc.stage})" if exc.stage else ""))
            else:
                st.rerun()

        if direct and audio_bytes:
            try:
                with st.spinner("Listening, thinking and speaking…"):
                    resp = client.turn_audio(audio_bytes, filename)
                meta, low = _transcript_meta(resp.get("transcript"))
                _add_turn(resp.get("user_text", ""), meta, low, resp)
            except ApiError as exc:
                _add_error(None, "", exc)
            _reset_voice_widgets()
            st.rerun()

        if ss.pending_stt:
            p = ss.pending_stt
            st.markdown("**Review transcript**")
            conf = p.get("confidence")
            if isinstance(conf, (int, float)):
                st.caption(f"Engine: {p.get('provider') or 'stt'} · confidence {conf:.0%}")
            if p.get("low"):
                theme.note("Low transcription confidence. Check the text carefully before sending.", "warn")
            st.text_area("Transcript (editable)", key="voice_text", height=110, max_chars=4000)
            s1, s2 = st.columns(2)
            if s1.button("Send to assistant", type="primary", use_container_width=True,
                         disabled=not ss.get("voice_text", "").strip()):
                text = ss["voice_text"].strip()
                meta, low = _transcript_meta({"provider": p["provider"], "confidence": p["confidence"]})
                try:
                    with st.spinner("Thinking…"):
                        resp = client.turn(text, "speech")
                    _add_turn(text, meta + " · reviewed", low, resp)
                except ApiError as exc:
                    _add_error(text, meta, exc)
                _reset_voice_widgets()
                st.rerun()
            if s2.button("Discard", use_container_width=True):
                _reset_voice_widgets()
                st.rerun()


def _report_name_from_prompt(text: str) -> str | None:
    """Recognize explicit report-retrieval requests and route them to the report API."""
    patterns = (
        r"(?i)^\s*(?:please\s+)?(?:show|fetch|get|retrieve|open|find)\s+(?:me\s+)?(?:the\s+)?(?:latest|most recent|last)?\s*(?:dental\s+)?report\s+for\s+(.+?)\s*[?.!]*\s*$",
        r"(?i)^\s*(?:what is|what's)\s+(?:the\s+)?(?:latest|most recent)\s+(?:dental\s+)?report\s+for\s+(.+?)\s*[?.!]*\s*$",
    )
    for pattern in patterns:
        match = re.match(pattern, text)
        if match:
            name = match.group(1).strip().strip("\"'.,?! ")
            if name and len(name) <= 120:
                return name
    return None

def _report_reply(client: DentVoiceClient, name: str, *, patient_id: str = "", dob: str = "", contact: str = "") -> str:
    """Use the deterministic report endpoint; never ask the general LLM to retrieve records."""
    data = client.latest_report(name=name, patient_id=patient_id, date_of_birth=dob, phone_contact=contact)
    report = data.get("report") or {}
    lines = [
        f"Latest report for {data.get('patient_name') or name}",
        f"Patient ID: {data.get('patient_id') or 'Not returned'}",
        f"Report: {report.get('type') or 'Not specified'}",
        f"Date: {report.get('date') or 'Not specified'}",
    ]
    findings = report.get("findings") or []
    if findings:
        lines.append("Findings:")
        lines.extend(f"- {item}" for item in findings)
    else:
        lines.append("Findings: No findings recorded.")
    if report.get("impression"):
        lines.append(f"Impression: {report['impression']}")
    if data.get("synthetic_data"):
        lines.append("Synthetic demo data — not a real patient record.")
    if data.get("requires_clinician_review"):
        lines.append("Clinician review required.")
    return "\n".join(lines)


def _identifier_from_followup(text: str) -> dict | None:
    """Extract only explicit demo identifiers from a clarification turn."""
    dob = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", text)
    if dob:
        return {"dob": dob.group(1)}
    patient_id = re.search(r"\b(P\d{3})\b", text, flags=re.IGNORECASE)
    if patient_id:
        return {"patient_id": patient_id.group(1).upper()}
    contact = re.search(r"\b(DEMO-\d{4})\b", text, flags=re.IGNORECASE)
    if contact:
        return {"contact": contact.group(1).upper()}
    # Accept an explicitly labelled registered contact/phone number, not arbitrary numbers.
    phone = re.search(r"(?:phone|contact|registered number|mobile)\s*(?:is|:)?\s*([+\d][\d ()-]{6,20}\d)", text, flags=re.IGNORECASE)
    if phone:
        return {"contact": re.sub(r"\s+", "", phone.group(1))}
    return None


def _add_text_reply(user_text: str, user_meta: str, reply: str) -> None:
    """Append a deterministic report reply without falsely claiming TTS ran."""
    ss = st.session_state
    ss.chat.append({"role": "user", "text": user_text, "meta": user_meta})
    ss.chat.append({"role": "assistant", "text": reply, "meta": "retrieved from local patient-report API"})


def _clarification_reply(text: str) -> str:
    return (f"I found more than one patient matching '{text}'. Please reply with the patient's date of birth "
            "(YYYY-MM-DD), patient ID (for example P001), or full registered contact. "
            "I'll use that detail to retrieve the report.")


def render(client: DentVoiceClient) -> None:
    _init()
    ss = st.session_state
    theme.page_header("AI Assistant", "Ask by typing or speaking. Everything runs on your local backend.")

    top = st.columns([3, 1.4, 1.2])
    top[0].caption("Each message is handled on its own: the backend does not keep conversation memory yet.")
    ss.auto_play = top[1].toggle("Auto-play replies", value=ss.auto_play)
    if top[2].button("Clear chat", use_container_width=True, disabled=not ss.chat):
        ss.chat = []
        _reset_voice_widgets()
        st.rerun()

    mode = st.radio("Input mode", ["Text", "Voice"], horizontal=True, key="assistant_mode")
    _render_history()

    if mode == "Voice":
        st.caption("Speak normally. Record your question, then send it to the local assistant.")
        _voice_panel(client)
    else:
        prompt = st.chat_input("Type your message…", max_chars=4000)
        if prompt and prompt.strip():
            text = prompt.strip()
            with st.chat_message("user", avatar="🧑‍⚕️"):
                st.markdown(text)
            meta = "typed input · speech recognition not used"
            report_name = _report_name_from_prompt(text)
            pending_name = ss.get("pending_report_name")
            identifier = _identifier_from_followup(text) if pending_name else None
            try:
                with st.chat_message("assistant", avatar="🦷"), st.spinner("Verifying patient and retrieving report…" if (report_name or (pending_name and identifier)) else "Thinking…"):
                    if report_name:
                        # A new report request always starts a deterministic report lookup.
                        try:
                            reply = _report_reply(client, report_name)
                            ss.pending_report_name = None
                            _add_text_reply(text, meta, reply)
                        except ApiError as exc:
                            if exc.ambiguous or exc.status == 409:
                                ss.pending_report_name = report_name
                                _add_text_reply(text, meta, _clarification_reply(report_name))
                            else:
                                raise
                    elif pending_name and identifier:
                        # Continue the pending report request with the explicit identity detail.
                        try:
                            reply = _report_reply(
                                client, pending_name,
                                patient_id=identifier.get("patient_id", ""),
                                dob=identifier.get("dob", ""),
                                contact=identifier.get("contact", ""),
                            )
                            ss.pending_report_name = None
                            _add_text_reply(text, meta, reply)
                        except ApiError as exc:
                            if exc.ambiguous or exc.status == 409:
                                _add_text_reply(text, meta,
                                    "That detail did not uniquely identify the patient. Please provide the patient ID or full registered contact.")
                            elif exc.status == 404:
                                _add_text_reply(text, meta,
                                    "I couldn't find a matching patient/report using that detail. Please check it and try again.")
                            else:
                                raise
                    elif pending_name:
                        # Do not lose the pending report intent when the user gives a non-identifier follow-up.
                        _add_text_reply(text, meta,
                            "I'm still waiting for the patient's DOB (YYYY-MM-DD), patient ID (for example P001), "
                            "or full registered contact to retrieve the report.")
                    else:
                        resp = client.turn(text, "typed")
                        _add_turn(text, meta, False, resp)
            except ApiError as exc:
                _add_error(text, meta, exc)
            st.rerun()
