"""Patient Voice Assistant: patients enter ONLY their Patient ID, then ask about their own reports.

Everything here goes through the patient endpoints of the backend (/v1/patient/*). The browser/Streamlit side
never reads patient data directly and never tells the backend which patient to use: the backend derives the
patient from the bearer token it issued at login. Speech in = /v1/stt, speech out = backend TTS.

Demo limitation (also in the README): Patient-ID-only access is for demonstration. A real deployment needs
real patient authentication.
"""

from __future__ import annotations

import base64
import html

import streamlit as st

try:
    import theme
    from api_client import ALLOWED_AUDIO_EXTENSIONS, ApiError, DentVoiceClient, decode_audio
except ImportError:
    from frontend import theme
    from frontend.api_client import ALLOWED_AUDIO_EXTENSIONS, ApiError, DentVoiceClient, decode_audio

HAS_MIC = hasattr(st, "audio_input")
MAX_CHARS = 1000
SUGGESTIONS = (
    "Explain my report.",
    "Describe my findings.",
    "What does this finding mean?",
    "Can you explain this in simple English?",
    "What are molar teeth?",
)

_CSS = """
<style>
.pva-box { border-radius:10px; padding:.65rem .9rem; margin:.35rem 0; font-size:.95rem; line-height:1.45; border-left:4px solid #94A3B8; background:#F1F5F9; color:#0B1F3A; }
.pva-doc { border-left-color:#0D9488; background:#E8F8F5; }
.pva-gen { border-left-color:#3B82F6; background:#EEF4FF; }
.pva-plain { border-left-color:#8B5CF6; background:#F5F0FF; }
.pva-unc { border-left-color:#64748B; background:#F1F5F9; font-style:italic; }
.pva-ref { border-left-color:#F59E0B; background:#FFF8E6; color:#7A4A06; }
.pva-note { border-left-color:#94A3B8; background:#F8FAFC; color:#475569; font-size:.85rem; }
.pva-tag { display:block; font-size:.68rem; letter-spacing:.07em; text-transform:uppercase; font-weight:700; opacity:.75; margin-bottom:.15rem; }
</style>
"""

_SECTION_STYLE = {
    "documented": ("pva-doc", "Documented in your report"),
    "plain": ("pva-plain", "In plain English"),
    "general": ("pva-gen", "General information, not from your report"),
    "uncertain": ("pva-unc", "What isn't known from your report"),
    "refusal": ("pva-ref", "What I can't do"),
    "context": ("pva-note", ""),
    "note": ("pva-note", ""),
}


def _init() -> None:
    ss = st.session_state
    ss.setdefault("pva_token", None)
    ss.setdefault("pva_patient", None)      # {"first_name": ...}
    ss.setdefault("pva_reports", [])        # [{"report_id","type","date"}]
    ss.setdefault("pva_chat", [])           # message dicts
    ss.setdefault("pva_speak", True)
    ss.setdefault("pva_nonce", 0)
    ss.setdefault("pva_error", None)
    ss.setdefault("pva_notice", None)


def _reset_session(message: str | None = None) -> None:
    ss = st.session_state
    for key in ("pva_token", "pva_patient", "pva_error"):
        ss[key] = None
    ss.pva_reports, ss.pva_chat = [], []
    ss.pva_notice = message
    ss.pva_nonce += 1


def _audio_html(wav: bytes, autoplay: bool) -> str:
    b64 = base64.b64encode(wav).decode("ascii")
    return f'<audio controls {"autoplay" if autoplay else ""} src="data:audio/wav;base64,{b64}" style="width:100%;margin-top:.3rem;"></audio>'


def _fmt_ms(value) -> str:
    return f"{int(round(value))} ms" if isinstance(value, (int, float)) else "n/a"


# ───────────────────────────── login ─────────────────────────────
def _render_login(client: DentVoiceClient) -> None:
    ss = st.session_state
    left, right = st.columns([1.1, 1], gap="large")
    with left:
        st.markdown("##### Enter your Patient ID")
        with st.form("pva_login_form", clear_on_submit=False):
            pid = st.text_input("Patient ID", placeholder="e.g. P001", max_chars=40, key="pva_pid_input")
            submitted = st.form_submit_button("Access my reports", type="primary", use_container_width=True)
        if submitted:
            ss.pva_notice = None
            if not pid.strip():
                ss.pva_error = "Please enter your Patient ID."
            else:
                try:
                    with st.spinner("Checking your Patient ID…"):
                        resp = client.patient_login(pid.strip())
                    ss.pva_token = resp["session_token"]
                    ss.pva_patient = resp.get("patient") or {}
                    ss.pva_reports = resp.get("reports") or []
                    ss.pva_chat = []
                    ss.pva_error = None
                    ss.pva_nonce += 1
                    st.rerun()
                except ApiError as exc:
                    ss.pva_error = exc.message
        if ss.pva_error:
            st.error(ss.pva_error)
        if ss.pva_notice:
            st.info(ss.pva_notice)
    with right:
        st.markdown(
            '<div class="dv-card"><h4>How this works</h4>'
            "Enter the Patient ID printed on your card. You can then <b>speak or type</b> questions about your own "
            "dental reports and hear or read the answers in English.<br><br>"
            "<b>Demo notice:</b> for this demonstration your Patient ID is the only thing checked. "
            "A real clinic system must verify patients more strongly (for example a one-time code sent to your registered phone).</div>",
            unsafe_allow_html=True,
        )
        st.caption("Demo Patient IDs: P001 to P006 (synthetic data).")


# ───────────────────────────── conversation ─────────────────────────────
def _send(client: DentVoiceClient, text: str, input_mode: str, meta: str = "") -> None:
    ss = st.session_state
    text = " ".join((text or "").split())
    if not text:
        return
    ss.pva_chat.append({"role": "user", "text": text, "meta": meta or f"{input_mode} question"})
    try:
        with st.spinner("Looking at your report…"):
            resp = client.patient_chat(ss.pva_token, text, input_mode=input_mode, speak=ss.pva_speak)
    except ApiError as exc:
        if exc.status == 401:
            _reset_session("Your session has ended. Please enter your Patient ID again.")
        else:
            ss.pva_chat.append({"role": "assistant", "error": exc.message})
        st.rerun()
        return
    audio = decode_audio(resp.get("audio_wav_base64"))
    warn = None
    if ss.pva_speak and not audio:
        warn = "The spoken version isn't available right now. The written answer below is complete."
    ss.pva_chat.append({
        "role": "assistant", "text": resp.get("answer", ""), "sections": resp.get("sections") or [],
        "evidence": resp.get("evidence") or [], "grounding": resp.get("grounding"), "intent": resp.get("intent"),
        "refusal": resp.get("refusal"), "timings": resp.get("timings_ms") or {}, "audio": audio,
        "autoplay": bool(audio), "warn": warn, "guardrail": resp.get("guardrail") or {},
    })
    st.rerun()


def _render_assistant_message(msg: dict, idx: int) -> None:
    if msg.get("error"):
        st.error(msg["error"])
        return
    sections = msg.get("sections") or [{"kind": "note", "text": msg.get("text", "")}]
    for s in sections:
        css, label = _SECTION_STYLE.get(s.get("kind"), ("pva-note", ""))
        tag = f'<span class="pva-tag">{html.escape(label)}</span>' if label else ""
        st.markdown(f'<div class="pva-box {css}">{tag}{html.escape(s.get("text", ""))}</div>', unsafe_allow_html=True)
    evidence = msg.get("evidence") or []
    if evidence:
        with st.expander("Source: where this came from", expanded=False):
            for ev in evidence:
                st.markdown(f"**{ev.get('type', 'Report')}** · {ev.get('date', '')} · ID `{ev.get('report_id', '')}`")
                for quote in ev.get("quotes") or []:
                    st.markdown(f"> {quote}")
    if msg.get("warn"):
        st.warning(msg["warn"])
    if msg.get("audio"):
        # Visible controls: if the browser blocks automatic playback the patient can simply press play.
        st.audio(msg["audio"], format="audio/wav", autoplay=bool(msg.pop("autoplay", False)))
    t = msg.get("timings") or {}
    if t:
        parts = [f"total {_fmt_ms(t.get('total'))}"]
        if "llm_generate" in t and t["llm_generate"]:
            parts.append(f"model {_fmt_ms(t['llm_generate'])}")
        if "tts" in t:
            parts.append(f"speech {_fmt_ms(t['tts'])}")
        st.caption("Answered in " + " · ".join(parts) + " (measured by the server)")


def _render_session(client: DentVoiceClient) -> None:
    ss = st.session_state
    first = (ss.pva_patient or {}).get("first_name") or "there"
    head = st.columns([3, 1.2])
    head[0].markdown(
        theme.chip(f"Signed in: {first}", "ok") + theme.chip(f"{len(ss.pva_reports)} report(s) on file", "navy")
        + theme.chip("Synthetic demo data", "warn"),
        unsafe_allow_html=True,
    )
    if head[1].button("End session", use_container_width=True):
        client.patient_logout(ss.pva_token)
        _reset_session("You have been signed out.")
        st.rerun()

    with st.expander("My reports on file", expanded=False):
        for r in ss.pva_reports:
            st.markdown(f"- **{r.get('type')}** · {r.get('date')} · `{r.get('report_id')}`")
        st.caption("Ask about one by name, for example “Explain my OPG report”.")

    ss.pva_speak = st.toggle("Speak answers aloud", value=ss.pva_speak, help="Uses the same English text-to-speech as the rest of the app.")

    if not ss.pva_chat:
        st.markdown(
            f'<div class="dv-card">Hello {html.escape(first)}. Ask me about your report in your own words: speak with the microphone '
            "below, or type. Try one of these:</div>",
            unsafe_allow_html=True,
        )
        cols = st.columns(len(SUGGESTIONS))
        for col, q in zip(cols, SUGGESTIONS):
            if col.button(q, key=f"pva_sugg_{q}", use_container_width=True):
                _send(client, q, "typed", "suggested question")
    for i, msg in enumerate(ss.pva_chat):
        with st.chat_message(msg["role"], avatar="🧑" if msg["role"] == "user" else "🦷"):
            if msg["role"] == "user":
                st.markdown(msg["text"])
                if msg.get("meta"):
                    st.caption(msg["meta"])
            else:
                _render_assistant_message(msg, i)

    # Speak a question
    st.markdown("##### Ask by voice")
    if HAS_MIC:
        rec = st.audio_input("Press the microphone, speak your question, then press stop", key=f"pva_mic_{ss.pva_nonce}")
        if rec is not None:
            ss.pva_nonce += 1  # reset the recorder for the next question
            try:
                with st.spinner("Listening…"):
                    t = client.stt(rec.getvalue(), "patient_question.wav")
            except ApiError as exc:
                st.error(exc.message + " You can type your question instead.")
                return
            text = (t.get("text") or "").strip()
            if not text:
                st.warning("I couldn't hear a question. Please try again or type it below.")
                return
            conf = t.get("confidence")
            meta = f"spoken · {t.get('provider') or 'stt'}" + (f" · confidence {conf:.0%}" if isinstance(conf, (int, float)) else "")
            if t.get("low_confidence"):
                meta += " · low confidence: please check the wording"
            _send(client, text, "speech", meta)
    else:
        st.info("Microphone capture is not available in this browser build. Upload audio or type your question.")
    with st.expander("Upload a recorded question instead", expanded=False):
        up = st.file_uploader("Audio file", type=list(ALLOWED_AUDIO_EXTENSIONS), key=f"pva_up_{ss.pva_nonce}")
        if up is not None and st.button("Ask using this recording", key="pva_up_btn"):
            try:
                t = client.stt(up.getvalue(), up.name)
            except ApiError as exc:
                st.error(exc.message)
            else:
                if (t.get("text") or "").strip():
                    ss.pva_nonce += 1
                    _send(client, t["text"], "speech", f"uploaded audio · {t.get('provider') or 'stt'}")
                else:
                    st.warning("No speech was detected in that recording.")

    prompt = st.chat_input("…or type your question here", max_chars=MAX_CHARS, key="pva_chat_input")
    if prompt and prompt.strip():
        _send(client, prompt.strip(), "typed")

    st.caption("This assistant explains what your report says in plain English. It cannot diagnose, advise on treatment or "
               "replace your dentist.")


def render(client: DentVoiceClient) -> None:
    _init()
    st.markdown(_CSS, unsafe_allow_html=True)
    theme.page_header(
        "Patient Voice Assistant",
        "Ask about your own dental reports by voice or text and get plain-English answers.",
    )
    if st.session_state.pva_token:
        _render_session(client)
    else:
        _render_login(client)
