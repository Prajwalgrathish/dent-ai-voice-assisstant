"""Clinical Dictation: Prominent Record/Stop control, editable transcript, structured clinical draft.

Features:
- Prominent direct Record/Stop button on the main page.
- Direct speech-to-text transcription via Faster-Whisper.
- Editable transcript before generating structured draft.
- Strict preservation of the existing JSON schema (anatomical_site, findings list, certainty, uncertainty_detected).
- Uncertainty flagging and clinician review notices.
- Post-report completion prompt: “Your report is ready. Would you like me to turn off?”
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

try:
    import theme
    from api_client import ALLOWED_AUDIO_EXTENSIONS, ApiError, DentVoiceClient
except ImportError:
    from frontend import theme
    from frontend.api_client import ALLOWED_AUDIO_EXTENSIONS, ApiError, DentVoiceClient

MAX_CHARS = 4000  # matches ClinicalDictationRequest.transcript
HAS_MIC = hasattr(st, "audio_input")
CERTAINTY_LABEL = {
    "uncertain_as_dictated": "⚠ Uncertain as dictated",
    "dictated_not_independently_verified": "Dictated · not independently verified",
}


def _init() -> None:
    ss = st.session_state
    ss.setdefault("dict_draft", None)       # last /v1/clinical/dictation response
    ss.setdefault("dict_stt", None)         # {"confidence","low","provider"} from last transcription
    ss.setdefault("dict_nonce", 0)
    ss.setdefault("dict_text", "")
    ss.setdefault("dict_session_status", "active")  # "active" | "concluded"
    ss.setdefault("dict_show_turn_off_prompt", False)


def _norm(text: str) -> str:
    return " ".join((text or "").split())


def _capture_direct(client: DentVoiceClient) -> None:
    """Prominent direct Record/Stop control directly on the main page."""
    ss = st.session_state

    st.markdown("##### 1 · Record Clinical Dictation")

    c1, c2 = st.columns([3, 1])
    with c1:
        st.caption("Press **Record** to dictate, and **Stop** when finished. Speech is transcribed directly.")
    with c2:
        if ss.dict_session_status == "concluded":
            st.markdown(theme.chip("Session Concluded", "ok"), unsafe_allow_html=True)
        else:
            st.markdown(theme.chip("Session Active", "navy"), unsafe_allow_html=True)

    if HAS_MIC:
        rec = st.audio_input(
            "Dictate clinical notes",
            key=f"dmic_main_{ss.dict_nonce}",
            label_visibility="collapsed",
        )
        if rec is not None:
            audio_bytes = rec.getvalue()
            try:
                with st.spinner("Transcribing dictation with Faster-Whisper…"):
                    t = client.stt(audio_bytes, "dictation.wav")
                ss["dict_text"] = t.get("text", "")
                ss.dict_stt = {
                    "confidence": t.get("confidence"),
                    "low": bool(t.get("low_confidence")),
                    "provider": t.get("provider", ""),
                }
                ss.dict_draft = None
                ss.dict_show_turn_off_prompt = False
                ss.dict_session_status = "active"
                ss.dict_nonce += 1
                st.rerun()
            except ApiError as exc:
                st.error(exc.message + (f" ({exc.stage})" if exc.stage else ""))
    else:
        st.info("Browser microphone capture widget is not available in this build. Please upload audio or type below.")

    # Optional secondary audio file uploader
    with st.expander("📁 Or upload an audio file instead", expanded=False):
        up = st.file_uploader(
            "Audio file",
            type=list(ALLOWED_AUDIO_EXTENSIONS),
            key=f"dup_{ss.dict_nonce}",
        )
        if up is not None and st.button("Transcribe uploaded file", key="btn_dup_transcribe", use_container_width=True):
            try:
                with st.spinner("Transcribing uploaded audio file…"):
                    t = client.stt(up.getvalue(), up.name)
                ss["dict_text"] = t.get("text", "")
                ss.dict_stt = {
                    "confidence": t.get("confidence"),
                    "low": bool(t.get("low_confidence")),
                    "provider": t.get("provider", ""),
                }
                ss.dict_draft = None
                ss.dict_show_turn_off_prompt = False
                ss.dict_session_status = "active"
                ss.dict_nonce += 1
                st.rerun()
            except ApiError as exc:
                st.error(exc.message + (f" ({exc.stage})" if exc.stage else ""))


def _warnings(draft: dict) -> list[tuple[str, str]]:
    """Collect (severity, message) pairs. Severity: bad | warn."""
    ss = st.session_state
    out: list[tuple[str, str]] = []
    if ss.dict_stt and ss.dict_stt.get("low"):
        out.append(("warn", "Speech recognition had low confidence. Compare the transcript with the audio."))
    if draft.get("uncertainty_detected"):
        out.append(("warn", draft.get("uncertainty_note") or "Uncertain wording detected in the dictation."))
    if not draft.get("findings"):
        out.append(("warn", "No structured findings could be extracted. Only the original transcript is reliable."))
    if _norm(ss.dict_text) != _norm(draft.get("original_transcript", "")):
        out.append(("bad", "The transcript was edited after this draft was generated. Regenerate the draft."))
    if draft.get("requires_clinician_review"):
        out.append(("warn", "Clinician review required before this draft is used in patient care."))
    if draft.get("synthetic_data"):
        out.append(("warn", "Backend marks this output as synthetic/demo data."))
    return out


def _render_draft(draft: dict) -> None:
    ss = st.session_state

    # Completion turn-off question asked when structured report is ready
    if ss.get("dict_show_turn_off_prompt"):
        st.markdown("---")
        if ss.get("dict_session_status") == "concluded":
            st.success("✅ **Dictation session concluded.** Your report is ready and preserved for clinical sign-off.")
            if st.button("Start New Dictation Session", use_container_width=True):
                ss.dict_session_status = "active"
                ss.dict_show_turn_off_prompt = False
                ss.dict_draft = None
                ss.dict_text = ""
                ss.dict_nonce += 1
                st.rerun()
        else:
            st.info("🤖 **Your report is ready. Would you like me to turn off?**")
            p1, p2 = st.columns(2)
            if p1.button("Yes, turn off dictation session", type="primary", use_container_width=True):
                ss.dict_session_status = "concluded"
                st.rerun()
            if p2.button("No, continue editing", use_container_width=True):
                ss.dict_show_turn_off_prompt = False
                st.rerun()
        st.markdown("---")

    st.markdown("##### Uncertainty & safety warnings")
    items = _warnings(draft)
    if items:
        for kind, msg in items:
            theme.note(msg, kind)
    else:
        theme.note("No uncertainty flags were raised. Review is still required.")

    st.markdown("##### Structured clinical draft")
    st.markdown(
        f'<div class="dv-card">{theme.field("Anatomical site", draft.get("anatomical_site") or "Not identified")}</div>',
        unsafe_allow_html=True,
    )

    findings = draft.get("findings") or []
    if findings:
        df = pd.DataFrame([{
            "Site": f.get("anatomical_site", ""),
            "Finding": f.get("finding", ""),
            "Certainty": CERTAINTY_LABEL.get(f.get("certainty", ""), f.get("certainty", "")),
            "Source text": f.get("source_text", ""),
        } for f in findings])
        st.dataframe(df, hide_index=True, use_container_width=True)

    st.markdown("##### Readable draft (editable)")
    if "dict_readable_seed" not in ss or ss.dict_readable_seed != draft.get("readable_draft"):
        ss["dict_readable"] = draft.get("readable_draft", "")
        ss.dict_readable_seed = draft.get("readable_draft")
    st.text_area(
        "Edit the wording before sign-off",
        key="dict_readable",
        height=140,
        label_visibility="collapsed",
    )

    stale = _norm(ss.dict_text) != _norm(draft.get("original_transcript", ""))
    # Clinician Review and Finalization Workflow
    dict_draft_obj = draft.get("dictation_draft")
    if dict_draft_obj and dict_draft_obj.get("uncertainty_flags"):
        st.markdown("###### Draft Uncertainty Flags")
        for flag in dict_draft_obj["uncertainty_flags"]:
            st.warning(f"Field: `{flag.get('field')}` — {flag.get('reason')}")

    col_rev1, col_rev2 = st.columns([2, 1])
    reviewer_id = col_rev1.text_input("Reviewer Clinician ID", value=ss.get("dict_reviewer_id", "DR01"), key="dict_reviewer_id_input")
    ack_flags = col_rev2.checkbox("Acknowledge uncertainty flags", value=True, key="dict_ack_flags")

    reviewed = st.checkbox(
        "I have reviewed this draft against the original clinical evidence and confirm its accuracy.",
        key="dict_reviewed",
        disabled=stale,
    )

    finalized_json = None
    if reviewed and not stale and reviewer_id.strip():
        try:
            from voiceassistant.dictation import finalize
            if dict_draft_obj:
                # Ensure patient ID is attached for finalization
                draft_to_fin = dict(dict_draft_obj)
                draft_to_fin["patient_id"] = draft_to_fin.get("patient_id") or "P001"
                finalized = finalize(draft_to_fin, reviewer_id=reviewer_id.strip(), confirmed=True, acknowledge_flags=ack_flags)
                import json
                finalized_json = json.dumps(finalized, indent=2)
                st.success(f"Finalized and confirmed by clinician {reviewer_id.strip()}.")
        except Exception as exc:
            st.error(f"Cannot finalize draft: {exc}")

    c_dl1, c_dl2 = st.columns(2)
    c_dl1.download_button(
        "Download reviewed draft (.txt)",
        data=_export_text(draft),
        file_name="clinical_draft.txt",
        mime="text/plain",
        disabled=not reviewed or stale,
        help="Saved only to your computer. Nothing is written to the backend or patient record.",
        use_container_width=True,
    )
    if finalized_json:
        c_dl2.download_button(
            "Download Finalized JSON",
            data=finalized_json,
            file_name="clinical_dictation_finalized.json",
            mime="application/json",
            use_container_width=True,
        )

    with st.expander("Raw backend response & structured draft"):
        st.json(draft)


def _export_text(draft: dict) -> str:
    ss = st.session_state
    lines = [
        "CLINICAL DRAFT (reviewed by clinician)",
        "",
        "Original transcript:",
        draft.get("original_transcript", ""),
        "",
        "Draft:",
        ss.get("dict_readable", ""),
        "",
    ]
    for f in draft.get("findings") or []:
        lines.append(
            f"- {f.get('anatomical_site')}: {f.get('finding')} "
            f"[{CERTAINTY_LABEL.get(f.get('certainty', ''), f.get('certainty', ''))}]"
        )
    if draft.get("synthetic_data"):
        lines += ["", "Note: synthetic/demo data."]
    return "\n".join(lines)


def render(client: DentVoiceClient) -> None:
    _init()
    ss = st.session_state

    # Voice navigation confirmation when arriving from AI Assistant
    inc = ss.pop("dict_incoming_speech", None)
    if inc:
        st.info(f"🎙️ **DentVoice AI:** {inc['text']}")
        if inc.get("audio"):
            st.audio(inc["audio"], format="audio/wav", autoplay=inc.get("autoplay", True))

    theme.page_header(
        "Clinical Dictation",
        "Record or dictate clinical notes into an editable draft. Uncertainty is flagged, never hidden.",
    )

    # 1. Prominent Record/Stop control on the main page
    _capture_direct(client)

    # 2. Editable Transcript
    st.markdown("##### 2 · Review & Edit Transcript")
    st.text_area(
        "Dictation transcript",
        key="dict_text",
        height=150,
        max_chars=MAX_CHARS,
        placeholder="e.g. Lower left first molar shows possible distal caries. Dictate using the button above or type here.",
        label_visibility="collapsed",
    )
    if ss.dict_stt:
        conf = ss.dict_stt.get("confidence")
        conf_txt = f" · confidence {conf:.0%}" if isinstance(conf, (int, float)) else ""
        st.caption(f"Transcribed by {ss.dict_stt.get('provider') or 'stt'}{conf_txt}. Edit freely before generating draft.")

    b1, b2 = st.columns([1.3, 1])
    if b1.button(
        "Generate structured draft",
        type="primary",
        use_container_width=True,
        disabled=not ss.dict_text.strip(),
    ):
        try:
            with st.spinner("Building structured clinical draft…"):
                ss.dict_draft = client.dictation(ss.dict_text.strip())
            ss.dict_show_turn_off_prompt = True
            ss.pop("dict_readable_seed", None)
            ss.pop("dict_reviewed", None)
            st.rerun()
        except ApiError as exc:
            ss.dict_draft = None
            st.error(exc.message)

    if b2.button("Clear", use_container_width=True):
        for key in (
            "dict_text",
            "dict_draft",
            "dict_stt",
            "dict_readable",
            "dict_readable_seed",
            "dict_reviewed",
            "dict_show_turn_off_prompt",
        ):
            ss.pop(key, None)
        ss.dict_session_status = "active"
        ss.dict_nonce += 1
        st.rerun()

    if ss.dict_draft:
        st.divider()
        _render_draft(ss.dict_draft)
