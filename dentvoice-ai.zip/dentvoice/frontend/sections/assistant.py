"""AI Assistant: Conversational, voice-first dental assistant.

Features:
- Time-appropriate greeting on first load ("Hi Doctor, good morning/afternoon/evening..."), spoken aloud.
- Seamless voice-first conversation with live state management (Listening, Processing, Speaking, Paused, Stopped).
- Voice commands for direct navigation to Clinical Dictation ("Open Clinical Dictation", "I want to create a draft").
- Contextual follow-up memory ("Summarize her report", "Download that report as a PDF").
- Direct PDF report generation and in-chat download button.
- Typing always available simultaneously via st.chat_input.
"""

from __future__ import annotations

import base64
import json
import re
import time
from datetime import datetime
from typing import Optional

import streamlit as st

try:
    from frontend import theme
    from frontend.api_client import ALLOWED_AUDIO_EXTENSIONS, ApiError, DentVoiceClient, decode_audio
except ImportError:
    import theme
    from api_client import ALLOWED_AUDIO_EXTENSIONS, ApiError, DentVoiceClient, decode_audio
try:
    from dentvoice_mic import MicAction, MicError, PlaybackEvent, Utterance, dentvoice_mic_events
except ImportError:
    from frontend.dentvoice_mic import MicAction, MicError, PlaybackEvent, Utterance, dentvoice_mic_events
from voiceassistant.config import CLARIFICATION_TIMEOUT_SECONDS, SILENCE_TIMEOUT_SECONDS
from voiceassistant.voice_commands import greeting_for_hour, is_listen_command
from voiceassistant.dental.pdf import generate_patient_report_pdf
from voiceassistant.dental.service import list_patient_candidates, select_report
from voiceassistant.dental.report_intent import (
    parse_contextual_report_reference,
    is_clinical_statement,
    is_dictation_intent,
    is_explain_intent,
    is_pdf_intent,
    is_summary_intent,
    parse_report_request,
    strip_dictation_prefix,
)
from voiceassistant.explain import explain_findings
from voiceassistant.speech_cleaner import clean_text_for_speech

FOLLOW_UP_QUESTIONS = (
    "Anything else, Doctor?",
    "Would you like me to find anything else?",
    "Would you like me to turn off for now?",
)


def _ensure_greeting_question(text: str) -> str:
    """Ensure the greeting asks naturally without repeating questions."""
    lowered = text.casefold()
    if "how can i help you" in lowered or "what are you looking for" in lowered:
        return text
    clean = text.rstrip(".! ")
    return f"{clean}! How can I help you today, Doctor?"


def _local_hour() -> int:
    """The doctor's LOCAL hour, from the browser. Order: the browser's UTC offset (needs no time-zone database, which
    Windows Python does not ship), then its named time zone, then this machine's clock."""
    try:
        from datetime import timedelta, timezone
        offset = st.context.timezone_offset            # minutes, JS getTimezoneOffset() sign: UTC+5:30 -> -330
        if isinstance(offset, (int, float)):
            return (datetime.now(timezone.utc) - timedelta(minutes=offset)).hour
    except Exception:
        pass
    try:
        from zoneinfo import ZoneInfo
        tz = st.context.timezone
        if tz:
            return datetime.now(ZoneInfo(tz)).hour
    except Exception:
        pass
    return datetime.now().hour


def _get_time_greeting() -> str:
    """Greeting for the doctor's local time of day (morning / afternoon / evening / night variants)."""
    return greeting_for_hour(_local_hour())


def _get_spoken_greeting() -> str:
    """What is spoken is exactly what is written, so the screen and the voice never disagree."""
    return _get_time_greeting()


def _append_natural_followup(text: str, is_clarification: bool = False) -> str:
    """After completing a request and finishing its spoken response, ask a short follow-up question.
    Do not ask repetitive follow-up questions during clarification turns.
    """
    if is_clarification or not text:
        return text
    lowered = text.casefold()
    for q in FOLLOW_UP_QUESTIONS:
        if q.casefold() in lowered:
            return text
    if any(phrase in lowered for phrase in ("anything else", "what are you looking for", "turn off for now")):
        return text
    clean = text.rstrip()
    return f"{clean} Anything else, Doctor?"


def _init() -> None:
    ss = st.session_state
    ss.setdefault("chat", [])                  # list of message dicts
    ss.setdefault("auto_play", True)
    ss.setdefault("greeted", False)            # the time-of-day greeting is created exactly once per session
    ss.setdefault("mic_nonce", 0)
    ss.setdefault("is_clarification", False)   # True while the assistant waits for a clarification answer
    ss.setdefault("timeout_message", None)     # one-line notice shown under the status chip
    ss.setdefault("active_patient", None)      # {"name": "...", "patient_id": "..."}
    ss.setdefault("active_report", None)       # full report dict from last retrieval
    ss.setdefault("pending_report_name", None)  # report request awaiting disambiguation
    ss.setdefault("pending_report_type", "")
    ss.setdefault("pending_intent", None)       # "download_pdf" | "summary" | "view_report"
    ss.setdefault("pending_candidates", None)   # list of candidate dicts
    ss.setdefault("report_history", None)       # [{"report_id","type","date"}] of the ACTIVE patient only
    ss.setdefault("pending_report_choice", None)  # {"patient_id","options":[report dicts]} while "which one?" is open
    ss.setdefault("awaiting_patient", False)    # "which patient?" asked, nothing identified yet
    # --- voice workflow: every value below is set from an EVENT the browser reported, never from a guess ---
    ss.setdefault("dv_turn_id", None)
    ss.setdefault("dv_last_event_id", None)
    ss.setdefault("dv_seen_events", [])        # ids of component events already handled (bounded)
    ss.setdefault("voice_wanted", True)        # hands-free is the default experience
    ss.setdefault("dv_listening", False)       # True only after the browser reported capture is really running
    ss.setdefault("dv_user_paused", False)     # the doctor paused deliberately
    ss.setdefault("dv_standby", False)         # the browser stopped capture after the idle timeout
    ss.setdefault("dv_playing_id", None)       # id of the audio the browser is playing RIGHT NOW (else None)
    ss.setdefault("dv_audio", None)            # {"id","b64"} waiting to be played by the browser
    ss.setdefault("dv_audio_done", [])         # audio ids that started / ended / failed (never replayed)
    ss.setdefault("dv_audio_blocked", False)   # browser refused automatic playback
    ss.setdefault("dv_mic_error", None)
    ss.setdefault("dv_resume_nonce", 0)


def _mark_seen(event_id: str) -> bool:
    """True the first time an event id is seen. The component keeps re-sending its last few events on every rerun."""
    seen = st.session_state.dv_seen_events
    if event_id in seen:
        return False
    seen.append(event_id)
    del seen[:-200]
    return True


def _queue_reply_audio(audio_bytes: bytes | None, is_clarification: bool = False, *, audio_id: str | None = None) -> None:
    """Hand a reply's audio to the BROWSER player. Nothing here claims the assistant is speaking: the status only
    changes when the browser reports that playback really started (and really ended)."""
    ss = st.session_state
    ss.is_clarification = is_clarification
    ss.timeout_message = None
    if audio_bytes and ss.get("auto_play", True):
        ss.dv_audio = {
            "id": audio_id or f"a{len(ss.chat)}-{int(time.time() * 1000) % 10_000_000}",
            "b64": base64.b64encode(audio_bytes).decode("ascii"),
        }
        ss.dv_audio_blocked = False
    else:
        ss.dv_audio = None


def _voice_status() -> tuple[str, str]:
    """(key, label) derived ONLY from browser-reported facts."""
    ss = st.session_state
    if ss.get("dv_mic_error"):
        return "error", "Microphone problem"
    if ss.get("dv_playing_id"):
        return "speaking", "Speaking…"
    if ss.get("dv_listening"):
        return "listening", "Listening for your answer…" if ss.get("is_clarification") else "Listening…"
    if ss.get("dv_standby"):
        return "standby", f"Stopped after {SILENCE_TIMEOUT_SECONDS} seconds of silence"
    if ss.get("dv_user_paused"):
        return "paused", "Paused"
    return "idle", "Microphone off"


def _request_resume() -> None:
    """Ask the browser to (re)start listening. The status stays 'off' until the browser confirms capture is running."""
    ss = st.session_state
    ss.voice_wanted = True
    ss.dv_user_paused = False
    ss.dv_standby = False
    ss.dv_mic_error = None
    ss.timeout_message = None
    ss.dv_resume_nonce += 1


def _greet_if_needed(client: DentVoiceClient) -> None:
    """Create the time-of-day greeting ONCE per session. It is shown and queued for the browser to speak; reruns,
    microphone toggles, timeouts and navigating between sections never create or speak it again."""
    ss = st.session_state
    if ss.get("greeted"):
        return
    ss.greeted = True
    text = _get_time_greeting()
    audio = None
    meta = None
    warn = None
    try:
        tts_resp = client.tts(clean_text_for_speech(text))
        audio = decode_audio(tts_resp.get("audio_wav_base64"))
        meta = f"spoken by {tts_resp.get('tts_engine', 'tts')}"
    except Exception:
        warn = "The spoken greeting is unavailable right now. Listening can still start; replies will be written."
    ss.chat.append({
        "role": "assistant",
        "text": text,
        "spoken_text": text,
        "meta": meta,
        "warn": warn,
        "audio": audio,
        "is_greeting": True,
    })
    _queue_reply_audio(audio, is_clarification=False, audio_id="greeting")


def _transcript_meta(t: dict | None) -> tuple[str, bool]:
    if not t:
        return "voice input", False
    conf = t.get("confidence")
    conf_txt = f" · confidence {conf:.0%}" if isinstance(conf, (int, float)) else ""
    return f"voice · {t.get('provider') or 'stt'}{conf_txt}", bool(t.get("low_confidence"))


def _add_turn(
    user_text: str,
    user_meta: str,
    user_warn: bool,
    resp: dict,
    is_clarification: bool = False,
    client: Optional[DentVoiceClient] = None,
) -> None:
    ss = st.session_state
    ss.chat.append({
        "role": "user",
        "text": user_text,
        "meta": user_meta,
        "warn": "Low transcription confidence. Please double-check this text." if user_warn else None,
        "llm": True,
    })
    reply_text = resp.get("reply_text", "")
    if not is_clarification:
        reply_text = _append_natural_followup(reply_text, is_clarification=False)

    audio = decode_audio(resp.get("audio_wav_base64"))
    if client and reply_text != resp.get("reply_text", ""):
        try:
            clean_reply = clean_text_for_speech(reply_text)
            tts_res = client.tts(clean_reply)
            new_audio = decode_audio(tts_res.get("audio_wav_base64"))
            if new_audio:
                audio = new_audio
                resp["tts_engine"] = tts_res.get("tts_engine", resp.get("tts_engine"))
        except Exception:
            pass

    warn = None
    if resp.get("tts_error"):
        warn = f"Spoken reply unavailable ({resp['tts_error']}). The text reply is still valid."
    elif not audio:
        warn = "No audio was returned for this reply."
    ss.chat.append({
        "role": "assistant",
        "text": reply_text,
        "meta": f"spoken by {resp['tts_engine']}" if audio and resp.get("tts_engine") else None,
        "warn": warn,
        "audio": audio,
        "llm": True,
        "llm_text": resp.get("reply_text", ""),
    })
    _queue_reply_audio(audio, is_clarification=is_clarification)


MAX_LLM_HISTORY = 8


def _llm_history() -> list[dict]:
    """Earlier general-chat turns for the LLM, so "and what about the second one?" keeps its context.

    Only turns that were themselves sent to the LLM are included. Retrieved patient reports, dictation drafts and
    report PDFs never go back into a model prompt (they may be sent to a hosted provider).
    """
    history = []
    for msg in st.session_state.get("chat", []):
        if msg.get("llm") and msg.get("text"):
            history.append({"role": msg["role"], "content": msg.get("llm_text") or msg["text"]})
    return history[-MAX_LLM_HISTORY:]


def _add_error(user_text: str | None, user_meta: str, exc: ApiError) -> None:
    ss = st.session_state
    if user_text:
        ss.chat.append({"role": "user", "text": user_text, "meta": user_meta})
    stage = f" ({exc.stage})" if exc.stage else ""
    ss.chat.append({"role": "assistant", "text": "", "error": f"{exc.message}{stage}"})


def _add_text_reply(
    user_text: str | None,
    user_meta: str,
    reply: str,
    client: Optional[DentVoiceClient] = None,
    is_clarification: bool = False,
) -> None:
    ss = st.session_state
    if user_text:
        ss.chat.append({"role": "user", "text": user_text, "meta": user_meta})
    audio = None
    meta = "retrieved from local patient-report API"
    if client:
        try:
            clean_reply = clean_text_for_speech(reply)
            tts_res = client.tts(clean_reply)
            audio = decode_audio(tts_res.get("audio_wav_base64"))
            meta = f"spoken by {tts_res.get('tts_engine', 'tts')}"
        except Exception:
            pass
    ss.chat.append({
        "role": "assistant",
        "text": reply,
        "meta": meta,
        "audio": audio,
    })
    _queue_reply_audio(audio, is_clarification=is_clarification)


def _format_report_data(data: dict, heading: str = "Latest") -> str:
    patient_name = data.get("patient_name") or "Unknown"
    patient_id = data.get("patient_id") or "Not returned"
    report = data.get("report") or {}
    report_type = report.get("type") or "Dental report"
    report_date = report.get("date") or "Not specified"

    lines = [
        f"{heading} {report_type} for {patient_name}.",
        f"Patient ID: {patient_id}.",
        f"Report date: {report_date}.",
    ]
    findings = report.get("findings") or []
    if isinstance(findings, list) and findings:
        findings_str = "; ".join(str(f) for f in findings)
        lines.append(f"Findings: {findings_str}")
    else:
        lines.append("Findings: No findings recorded.")

    if report.get("impression"):
        lines.append(f"Impression: {report['impression']}")

    lines.append("This is synthetic demonstration data. Clinician review is required.")
    return " ".join(lines)


AMBIGUOUS_PATIENT_REPLY = (
    "Multiple patients match that name. Please provide the intended patient's ID "
    "or use the authorized patient lookup workflow."
)


def _clarification_reply(text: str, candidates: list[dict] | tuple | None = None) -> str:
    """Privacy: never list, name, number or describe the matching patients (no names, IDs, dates of birth)."""
    if candidates and len(candidates) == 1:
        # A single close match is only a name to confirm; its ID and date of birth are not read out.
        return f"Do you mean {candidates[0].get('name', 'that patient')}? Say yes to confirm, or give the patient ID."
    return AMBIGUOUS_PATIENT_REPLY


_WORD_DIGITS = {
    "zero": "0", "oh": "0", "one": "1", "two": "2", "three": "3", "four": "4",
    "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9",
}


def _normalize_spoken_id(text: str) -> str:
    """Normalize spoken digit forms (e.g. 'P-001', 'P 0 0 1', 'P zero zero one') to 'P001'."""
    t = re.sub(
        r"\b(" + "|".join(_WORD_DIGITS) + r")\b",
        lambda m: _WORD_DIGITS[m.group(1).lower()],
        text,
        flags=re.IGNORECASE,
    )
    t = re.sub(r"(?<=\d)[\s\-.,](?=\d)", "", t)  # "0 0 1" -> "001"
    return re.sub(r"\bP[\s\-]+(?=\d)", "P", t, flags=re.IGNORECASE)  # "P-001" -> "P001"


def _identifier_from_followup(text: str, candidates: tuple = ()) -> dict | None:
    from voiceassistant.patient_resolver import extract_patient_id, select_from_candidates
    cleaned = " ".join((text or "").strip().split())

    # 1. Spoken Patient ID via patient_resolver
    pid = extract_patient_id(cleaned)
    if pid:
        return {"patient_id": pid}

    # 2. Candidate selection ("the first", a name, a date of birth). Only the patient ID is returned: the candidate
    #    list carries a MASKED contact ("DEMO-••01") which can never match the real record.
    if candidates and not is_clinical_statement(cleaned):
        if len(candidates) == 1 and re.fullmatch(r"(?:yes|yeah|yep|yup|correct|that'?s (?:right|correct)|confirm(?:ed)?|right|ok(?:ay)?|sure)[\s.!]*", cleaned, re.IGNORECASE):
            return {"patient_id": candidates[0].get("patient_id")}
        if re.fullmatch(r"(?:no|nope|nah|cancel|never ?mind|stop)[\s.!]*", cleaned, re.IGNORECASE):
            return {"cancel": True}
        if len(cleaned.split()) <= 8:
            sel = select_from_candidates(cleaned, candidates)
            # An ordinal ("the first") only means something when the doctor was shown the list; it never is, so with
            # several candidates it must not pick one (it falls through to the ID request below).
            if sel.status == "matched" and sel.patient and not (sel.reason == "ordinal" and len(candidates) != 1):
                return {"patient_id": sel.patient.get("patient_id")}

    # 3. ISO Date of birth (YYYY-MM-DD)
    dob = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", cleaned)
    if dob:
        return {"dob": dob.group(1)}

    # 4. Contact (DEMO-XXXX or phone)
    contact = re.search(r"\b(DEMO-\d{4})\b", cleaned, flags=re.IGNORECASE)
    if contact:
        return {"contact": contact.group(1).upper()}
    phone = re.search(
        r"(?:phone|contact|registered number|mobile)\s*(?:is|:)?\s*([+\d][\d ()-]{6,20}\d)",
        cleaned,
        flags=re.IGNORECASE,
    )
    if phone:
        return {"contact": re.sub(r"\s+", "", phone.group(1))}

    # 5. Ordinals fallback (short answers only: "I dictated the third molar..." is not a selection)
    if len(cleaned.split()) > 6:
        return None
    if re.search(r"\b(?:the\s+)?first(?:\s+(?:patient|one|record|choice|option))?\b|\b1st\b", cleaned, re.IGNORECASE):
        return {"ordinal": 0}
    if re.search(r"\b(?:the\s+)?second(?:\s+(?:patient|one|record|choice|option))?\b|\b2nd\b", cleaned, re.IGNORECASE):
        return {"ordinal": 1}
    if re.search(r"\b(?:the\s+)?third(?:\s+(?:patient|one|record|choice|option))?\b|\b3rd\b", cleaned, re.IGNORECASE):
        return {"ordinal": 2}

    return None


def _resolve_candidate_by_ordinal(name: str, ordinal: int) -> dict | None:
    """Resolve an ordinal reference (first, second) among candidate patient records."""
    # Privacy: the matching patients are never listed to the doctor, so "the first" cannot mean anything. An ordinal is
    # honoured only when exactly one patient matched (nothing to choose between); otherwise the ID is required.
    try:
        candidates = list_patient_candidates(name)
        if len(candidates) == 1 and ordinal == 0:
            return candidates[0]
    except Exception:
        pass
    return None


def _fulfill_report_intent(
    client: DentVoiceClient,
    data: dict,
    intent: str = "view_report",
    heading: str = "Latest",
    lead: str = "",
) -> None:
    """Fulfill the doctor's intended action on a verified patient report."""
    ss = st.session_state
    p_name = data.get("patient_name") or "Patient"
    p_id = data.get("patient_id") or "P"
    rep = data.get("report") or {}
    r_id = rep.get("report_id") or "R"
    r_type = rep.get("type", "Dental Examination")
    r_date = rep.get("date", "Unknown date")

    ss.active_patient = {
        "name": p_name,
        "patient_id": p_id,
    }
    ss.active_report = data
    ss.pending_report_name = None
    ss.pending_report_type = ""
    ss.pending_intent = None
    ss.pending_candidates = None

    if intent == "download_pdf":
        try:
            pdf_bytes = client.report_pdf(
                name=p_name,
                patient_id=p_id,
                report_type=r_type,
            )
        except Exception:
            try:
                from voiceassistant.report_pdf import build_report_pdf
                pdf_bytes = build_report_pdf(
                    patient={"patient_id": p_id, "name": p_name},
                    reports=[dict(rep, patient_id=p_id)],
                    kind="report",
                    synthetic=data.get("synthetic_data", True),
                )
            except Exception:
                pdf_bytes = generate_patient_report_pdf(
                    patient_name=p_name,
                    patient_id=p_id,
                    report=rep,
                    synthetic_data=data.get("synthetic_data", True),
                    requires_clinician_review=data.get("requires_clinician_review", True),
                )

        base_msg = f"Here is the generated PDF report for {p_name} (ID: {p_id}). You can download it directly below."
        reply_msg = _append_natural_followup(base_msg, is_clarification=False)
        audio = None
        try:
            clean_msg = clean_text_for_speech(reply_msg)
            tts_res = client.tts(clean_msg)
            audio = decode_audio(tts_res.get("audio_wav_base64"))
        except Exception:
            pass

        filename = f"DentVoice_Report_{p_id}_{r_id}.pdf"
        ss.chat.append({
            "role": "assistant",
            "text": reply_msg,
            "meta": "generated clinical PDF report",
            "audio": audio,
                "pdf_bytes": pdf_bytes,
            "pdf_name": filename,
        })
        _queue_reply_audio(audio, is_clarification=False)

    elif intent == "explain":
        findings = [str(f) for f in (rep.get("findings") or [])]
        exp = explain_findings(findings, impression=rep.get("impression"), audience="clinician")
        shown = "; ".join(str(f).rstrip(". ") for f in findings) if findings else "no findings recorded"
        parts = [
            f"{r_type} for {p_name} (ID {p_id}, {r_date}).",
            f"What the report says: {shown}.",
            "In plain English: " + exp.plain,
        ]
        if exp.recognised:
            parts.append("What this kind of wording means: " + exp.means + " " + exp.matters)
        parts.append(exp.uncertain)
        parts.append("Synthetic demo data. Clinician review is required.")
        reply_msg = _append_natural_followup(" ".join(parts), is_clarification=False)
        audio = None
        try:
            tts_res = client.tts(clean_text_for_speech(reply_msg))
            audio = decode_audio(tts_res.get("audio_wav_base64"))
        except Exception:
            pass
        ss.chat.append({
            "role": "assistant", "text": reply_msg, "meta": "plain-English report explanation · from the report only",
            "audio": audio,
        })
        _queue_reply_audio(audio, is_clarification=False)

    elif intent == "summary":
        findings = rep.get("findings") or []
        findings_text = "; ".join(str(f).rstrip(". ") for f in findings) if findings else "No findings recorded"
        imp = (rep.get("impression") or "Clinician review required.").rstrip(". ")
        base_summary = (
            f"Summary of {r_type} for {p_name} (ID: {p_id}, Date: {r_date}): "
            f"Findings: {findings_text}. Impression: {imp}. "
            "Synthetic demo data. Clinician review required."
        )
        reply_msg = _append_natural_followup(base_summary, is_clarification=False)
        audio = None
        try:
            clean_msg = clean_text_for_speech(reply_msg)
            tts_res = client.tts(clean_msg)
            audio = decode_audio(tts_res.get("audio_wav_base64"))
        except Exception:
            pass
        ss.chat.append({
            "role": "assistant",
            "text": reply_msg,
            "meta": "clinical report summary",
            "audio": audio,
            })
        _queue_reply_audio(audio, is_clarification=False)

    else:
        # view_report / default
        reply_text = (lead + " " if lead else "") + _format_report_data(data, heading)
        reply_text = _append_natural_followup(reply_text, is_clarification=False)
        audio = None
        meta_label = "retrieved from local patient-report API"
        if client:
            try:
                clean_msg = clean_text_for_speech(reply_text)
                tts_res = client.tts(clean_msg)
                audio = decode_audio(tts_res.get("audio_wav_base64"))
                meta_label = f"spoken by {tts_res.get('tts_engine', 'tts')}"
            except Exception:
                pass
        ss.chat.append({
            "role": "assistant",
            "text": reply_text,
            "meta": meta_label,
            "audio": audio,
            })
        _queue_reply_audio(audio, is_clarification=False)


_PRONOUN_REFERENCE = re.compile(
    r"\b(?:her|his|their|hers|she|he|them|this patient|that patient|the same patient|same patient|the patient)\b", re.IGNORECASE
)


def _handle_listen_command(client: DentVoiceClient, cleaned: str, meta: str, input_mode: str) -> None:
    """Resume listening. Spoken: the microphone is already on, so just acknowledge. Typed: ask the browser to restart
    capture and say plainly that it is only 'listening' once the browser confirms it."""
    ss = st.session_state
    pending = ss.get("pending_report_name")
    waiting = f" I'm still waiting to know which patient you mean for {pending}." if pending else ""
    if input_mode == "speech" and ss.get("dv_listening"):
        reply = "I'm listening, Doctor." + waiting
        _add_text_reply(cleaned, meta, reply, client=client, is_clarification=bool(pending))
    else:
        _request_resume()
        reply = ("Resuming the microphone. If your browser asks for permission, please allow it; "
                 "the status above says Listening once the microphone is really on." + waiting)
        ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
        ss.chat.append({"role": "assistant", "text": reply, "meta": "voice control"})
        ss.is_clarification = bool(pending)
    st.rerun()


def _run_report_request(
    client: DentVoiceClient,
    cleaned: str,
    meta: str,
    *,
    name: str = "",
    patient_id: str = "",
    dob: str = "",
    report_type: str = "",
    intent: str = "view_report",
) -> None:
    """Fetch a report; on duplicate names ask which patient (and REMEMBER the request), never guess."""
    ss = st.session_state
    ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
    try:
        data = client.latest_report(name=name, patient_id=patient_id, date_of_birth=dob, report_type=report_type)
        _fulfill_report_intent(client, data, intent=intent)
        return
    except (ApiError, Exception) as exc:  # noqa: BLE001 - every failure becomes a spoken, non-leaky message
        exc_msg = getattr(exc, "message", str(exc))
        status = getattr(exc, "status", None)
        ambiguous = getattr(exc, "ambiguous", False) or status == 409
        lowered = exc_msg.lower()
        if ambiguous or "multiple" in lowered or "ambiguous" in lowered:
            ss.pending_report_name = name or patient_id
            ss.pending_report_type = report_type
            ss.pending_intent = intent
            ss.awaiting_patient = False
            try:
                ss.pending_candidates = list_patient_candidates(name or patient_id)
            except Exception:
                ss.pending_candidates = None
            _add_text_reply(None, "", _clarification_reply(name or patient_id, ss.pending_candidates), client=client, is_clarification=True)
        elif status == 404 or "not found" in lowered or "couldn't find" in lowered:
            _add_text_reply(
                None, "",
                _append_natural_followup(exc_msg or "I couldn't find a matching patient or report. Please check the details and try again.", is_clarification=False),
                client=client, is_clarification=False,
            )
        else:
            _add_text_reply(None, "", f"I encountered a problem retrieving the report: {exc_msg}", client=client, is_clarification=False)


def _evidence(name: str, pid: str, report: dict | None = None) -> str:
    base = f"{name} (ID {pid})"
    if report:
        return f"{base}, report {report.get('report_id')}, dated {report.get('date')}."
    return base


def _run_contextual_report(client: DentVoiceClient, cleaned: str, meta: str, ref: dict, choice: dict | None = None) -> None:
    """'his previous report' / 'her OPG report' / 'open it again': always for the ACTIVE patient's canonical ID.
    The patient is never searched by name here, so a pronoun can never reach the patient resolver."""
    ss = st.session_state
    active = ss.get("active_patient") or {}
    pid = active.get("patient_id", "")
    ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
    try:
        hist = client.report_history(pid)
    except ApiError as exc:
        _add_text_reply(None, "", f"I couldn't load the reports for patient ID {pid}: {exc.message}", client=client, is_clarification=False)
        return
    name, reports = hist.get("patient_name") or active.get("name", ""), hist.get("reports") or []
    ss.report_history = [{"report_id": r.get("report_id"), "type": r.get("type"), "date": r.get("date")} for r in reports]
    cur = ss.get("active_report") or {}
    cur_id = ((cur.get("report") or {}).get("report_id")) if cur.get("patient_id") == pid else None
    rtype = ref.get("report_type", "")
    sel = select_report(reports, ref.get("selector", "latest"), rtype, cur_id)
    who = _evidence(name, pid)
    status = sel["status"]
    if status == "ok":
        rep = sel["report"]
        data = {"patient_id": pid, "patient_name": name, "report": rep,
                "source": {"report_id": rep.get("report_id"), "date": rep.get("date"), "type": rep.get("type")},
                "requires_clinician_review": True, "synthetic_data": True}
        heading = {"latest": "Latest", "active": "Current"}.get(ref.get("selector"), "Earlier")
        ss.pending_report_choice = None
        _fulfill_report_intent(client, data, intent="view_report", heading=heading, lead=_evidence(name, pid, rep))
        return
    ss.pending_report_choice = None
    if status == "none":
        msg = f"No reports are on file for {who}."
    elif status == "no_type":
        msg = f"There is no {rtype} report on file for {who}."
    elif status == "no_earlier":
        a = sel.get("anchor") or {}
        only = f" The only {rtype + ' ' if rtype else ''}report on file is {a.get('report_id')}, dated {a.get('date')}." if a else ""
        msg = f"There is no earlier {rtype + ' ' if rtype else ''}report for {who}.{only}"
    else:  # ask: several older reports
        ss.pending_report_choice = {"patient_id": pid, "options": sel["options"]}
        listed = "; ".join(f"{r.get('report_id')} ({r.get('type')}, {r.get('date')})" for r in sel["options"])
        msg = f"{who} has several earlier reports: {listed}. Which one do you mean?"
        _add_text_reply(None, "", msg, client=client, is_clarification=True)
        return
    _add_text_reply(None, "", _append_natural_followup(msg, is_clarification=False), client=client, is_clarification=False)


def _answer_report_choice(cleaned: str) -> dict | None:
    """Match the doctor's answer to 'which earlier report?' against the offered options only."""
    options = (st.session_state.get("pending_report_choice") or {}).get("options") or []
    low = cleaned.casefold()
    for r in options:
        if str(r.get("report_id", "")).casefold() in low or (r.get("date") and str(r["date"]) in low):
            return r
    by_type = [r for r in options if str(r.get("type", "")).casefold() in low]
    if len(by_type) == 1:
        return by_type[0]
    if re.search(r"\b(?:latest|newest|most recent|first)\b", low):
        return options[0] if options else None
    if re.search(r"\b(?:oldest|last)\b", low):
        return options[-1] if options else None
    return None


def _handle_user_turn(
    client: DentVoiceClient,
    text: str,
    input_mode: str = "typed",
    audio_meta: str = "",
    audio_warn: bool = False,
    force_dictation: bool = False,
) -> None:
    """Unified handler for typed and spoken user requests."""
    ss = st.session_state
    cleaned = " ".join((text or "").strip().split())
    if not cleaned:
        return

    meta = audio_meta or f"{input_mode} input · speech recognition not used"

    # -1. "Listen to me" / "Start listening" / "Listen": resume hands-free listening. Pending clarification, the
    #     active patient and the chat are left exactly as they are. Handled before every other rule so it is never
    #     mistaken for an answer to "which patient?" or sent to the language model.
    if is_listen_command(cleaned):
        _handle_listen_command(client, cleaned, meta, input_mode)
        return

    # 0. Clinical dictation, done right here in the assistant: an explicit "Dictate: ..." prefix, a recording the
    #    doctor marked as dictation, or a spoken/typed clinical observation ("Lower right third molar is impacted").
    dictated = strip_dictation_prefix(cleaned)
    if force_dictation or dictated or is_clinical_statement(cleaned):
        _handle_dictation(client, dictated or cleaned, meta, audio_warn)
        return

    # 1. Voice command navigation to Clinical Dictation
    if is_dictation_intent(cleaned):
        conf_text = "Opening Clinical Dictation, Doctor. You can start recording whenever you're ready."
        audio = None
        try:
            clean_conf = clean_text_for_speech(conf_text)
            tts_res = client.tts(clean_conf)
            audio = decode_audio(tts_res.get("audio_wav_base64"))
        except Exception:
            pass
        ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
        ss.chat.append({
            "role": "assistant",
            "text": conf_text,
            "meta": "navigating to Clinical Dictation",
            "audio": audio,
            })
        ss["dict_incoming_speech"] = {
            "text": conf_text,
            "audio": audio,
            }
        ss.pending_nav = "Clinical Dictation"  # applied by app.py BEFORE the sidebar radio is created
        st.rerun()
        return

    # 2. Check for Pending Clarification Response
    pending_name = ss.get("pending_report_name")
    pending_type = ss.get("pending_report_type", "")
    pending_intent = ss.get("pending_intent", "view_report")

    if pending_name:
        candidates_tuple = tuple(ss.get("pending_candidates") or ())
        identifier = _identifier_from_followup(cleaned, candidates=candidates_tuple)
        if identifier and identifier.get("cancel"):
            ss.pending_report_name = None
            ss.pending_report_type = ""
            ss.pending_intent = None
            ss.pending_candidates = None
            _add_text_reply(cleaned, meta, "No problem. Tell me the patient's full name or ID whenever you're ready.", client=client)
            st.rerun()
            return
        if not identifier and len(cleaned.split()) > 4:
            # A long, unrelated message is a NEW request, not an answer to "which patient?". Drop the stale question.
            ss.pending_report_name = None
            ss.pending_report_type = ""
            ss.pending_intent = None
            ss.pending_candidates = None
            pending_name = None
        if identifier:
            resolved_pid = identifier.get("patient_id", "")
            resolved_dob = identifier.get("dob", "")
            resolved_contact = identifier.get("contact", "")
            if identifier.get("ordinal") is not None:
                cand = _resolve_candidate_by_ordinal(pending_name, identifier["ordinal"])
                if cand:
                    resolved_pid = cand["patient_id"]  # the ID is the key; dob/contact here are masked or redundant
                else:
                    ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
                    _add_text_reply(
                        None,
                        "",
                        AMBIGUOUS_PATIENT_REPLY,
                        client=client,
                        is_clarification=True,
                    )
                    st.rerun()
                    return

            try:
                data = client.latest_report(
                    name=pending_name,
                    patient_id=resolved_pid or None,
                    date_of_birth=resolved_dob or None,
                    phone_contact=resolved_contact or None,
                    report_type=pending_type or None,
                )
                ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
                _fulfill_report_intent(client, data, intent=pending_intent)
                st.rerun()
                return
            except (ApiError, Exception) as exc:
                ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
                exc_msg = getattr(exc, "message", str(exc))
                status = getattr(exc, "status", None)
                ambig = getattr(exc, "ambiguous", False)
                is_ambig = ambig or status == 409 or "found" in exc_msg.lower() or "multiple" in exc_msg.lower() or "ambiguous" in exc_msg.lower()
                if is_ambig:
                    _add_text_reply(
                        None,
                        "",
                        "That detail did not uniquely identify the patient. Please provide the patient ID (for example P001) or date of birth.",
                        client=client,
                        is_clarification=True,
                    )
                elif status == 404 or "not found" in exc_msg.lower() or "couldn't find" in exc_msg.lower():
                    _add_text_reply(
                        None,
                        "",
                        f"I couldn't find a matching record for {pending_name} with that detail. Please confirm the patient ID (for example P001) or date of birth.",
                        client=client,
                        is_clarification=True,
                    )
                else:
                    _add_text_reply(
                        None,
                        "",
                        f"I encountered a problem retrieving the report: {exc_msg}",
                        client=client,
                        is_clarification=False,
                    )
                st.rerun()
                return

    # 3. PDF Download Request
    if is_pdf_intent(cleaned):
        ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
        req = parse_report_request(cleaned)
        if req and (req.get("name") or req.get("patient_id")):
            name = req.get("name", "")
            pid = req.get("patient_id", "")
            dob = req.get("date_of_birth", "")
            rtype = req.get("report_type", "")
            try:
                data = client.latest_report(
                    name=name,
                    patient_id=pid,
                    date_of_birth=dob,
                    report_type=rtype,
                )
                _fulfill_report_intent(client, data, intent="download_pdf")
            except ApiError as exc:
                if exc.ambiguous or exc.status == 409:
                    ss.pending_report_name = name or pid
                    ss.pending_report_type = rtype
                    ss.pending_intent = "download_pdf"
                    try:
                        from voiceassistant.dental.service import list_patient_candidates
                        ss.pending_candidates = list_patient_candidates(name or pid)
                    except Exception:
                        ss.pending_candidates = None
                    _add_text_reply(
                        None,
                        "",
                        _clarification_reply(name or pid, ss.pending_candidates),
                        client=client,
                        is_clarification=True,
                    )
                elif exc.status == 404:
                    not_found = _append_natural_followup(
                        "I couldn't find a matching patient or report. Please check the details and try again.",
                        is_clarification=False,
                    )
                    _add_text_reply(None, "", not_found, client=client, is_clarification=False)
                else:
                    raise
        elif ss.get("active_report"):
            _fulfill_report_intent(client, ss.active_report, intent="download_pdf")
        else:
            ss.pending_intent = "download_pdf"
            reply_msg = "Which patient's report would you like to download as a PDF? Please provide the patient's full name or ID."
            _add_text_reply(None, "", reply_msg, client=client, is_clarification=True)
        st.rerun()
        return

    # 4. Contextual Follow-up ("Summarize her report", "Explain her report in simple English")
    wants_explain = is_explain_intent(cleaned, has_active_report=bool(ss.get("active_report")))
    if (is_summary_intent(cleaned) or wants_explain) and not any(term in cleaned.casefold() for term in ("dictat", "draft")):
        ctx_intent = "explain" if wants_explain else "summary"
        ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
        explicit_req = parse_report_request(cleaned)
        if explicit_req and (explicit_req.get("name") or explicit_req.get("patient_id")):
            name = explicit_req.get("name", "")
            pid = explicit_req.get("patient_id", "")
            dob = explicit_req.get("date_of_birth", "")
            rtype = explicit_req.get("report_type", "")
            try:
                data = client.latest_report(
                    name=name,
                    patient_id=pid,
                    date_of_birth=dob,
                    report_type=rtype,
                )
                _fulfill_report_intent(client, data, intent=ctx_intent)
            except ApiError as exc:
                if exc.ambiguous or exc.status == 409:
                    ss.pending_report_name = name or pid
                    ss.pending_report_type = rtype
                    ss.pending_intent = ctx_intent
                    try:
                        from voiceassistant.dental.service import list_patient_candidates
                        ss.pending_candidates = list_patient_candidates(name or pid)
                    except Exception:
                        ss.pending_candidates = None
                    _add_text_reply(
                        None,
                        "",
                        _clarification_reply(name or pid, ss.pending_candidates),
                        client=client,
                        is_clarification=True,
                    )
                else:
                    not_found = _append_natural_followup(
                        "I couldn't find a matching patient or report. Please check the details and try again.",
                        is_clarification=False,
                    )
                    _add_text_reply(None, "", not_found, client=client, is_clarification=False)
        elif ss.get("active_report"):
            _fulfill_report_intent(client, ss.active_report, intent=ctx_intent)
        else:
            ss.pending_intent = ctx_intent
            reply_msg = "Which patient do you mean? Please provide the patient's full name or patient ID."
            _add_text_reply(None, "", reply_msg, client=client, is_clarification=True)
        st.rerun()
        return

    # 4b. A "which patient?" question is open (nothing was identified yet): this message is the answer.
    if ss.get("awaiting_patient") and not ss.get("pending_report_name"):
        answer = parse_report_request(f"{cleaned} report")
        if answer and (answer.get("patient_id") or answer.get("name")):
            _run_report_request(
                client, cleaned, meta, name=answer.get("name", ""), patient_id=answer.get("patient_id", ""),
                dob=answer.get("date_of_birth", ""), report_type=ss.get("pending_report_type", "") or answer.get("report_type", ""),
                intent=ss.get("pending_intent") or "view_report",
            )
            ss.awaiting_patient = False
            st.rerun()
            return

    # 4c. "Which earlier report?" is open: this message picks one of the offered reports (same patient).
    choice = ss.get("pending_report_choice")
    if choice:
        picked = _answer_report_choice(cleaned)
        ss.pending_report_choice = None
        if picked and (ss.get("active_patient") or {}).get("patient_id") == choice.get("patient_id"):
            ss.chat.append({"role": "user", "text": cleaned, "meta": meta})
            _fulfill_report_intent(
                client,
                {"patient_id": choice["patient_id"], "patient_name": ss.active_patient["name"], "report": picked,
                 "source": {"report_id": picked.get("report_id"), "date": picked.get("date"), "type": picked.get("type")},
                 "requires_clinician_review": True, "synthetic_data": True},
                heading="Earlier", lead=_evidence(ss.active_patient["name"], choice["patient_id"], picked),
            )
            st.rerun()
            return

    # 5. Standard Report Intent Detection
    report_request = parse_report_request(cleaned)
    ctx_active = ss.get("active_patient") or {}
    if ctx_active.get("patient_id") and not (report_request and (report_request.get("name") or report_request.get("patient_id"))):
        ctx_ref = parse_contextual_report_reference(cleaned, has_active_report=bool(ss.get("active_report")))
        if ctx_ref:
            _run_contextual_report(client, cleaned, meta, ctx_ref)
            st.rerun()
            return
    if report_request:
        active = ss.get("active_patient") or {}
        if report_request.get("needs_patient") == "true" and active.get("patient_id"):
            # "Give her reports" / "show the OPG": the patient is already identified in this conversation.
            _run_report_request(
                client, cleaned, meta, patient_id=active["patient_id"],
                report_type=report_request.get("report_type", ""), intent="view_report",
            )
        elif report_request.get("needs_patient") == "true":
            ss.pending_intent = "view_report"
            ss.pending_report_type = report_request.get("report_type", "")
            ss.awaiting_patient = True
            _add_text_reply(
                cleaned,
                meta,
                "Which patient do you mean? Please provide the patient's full name or patient ID.",
                client=client,
                is_clarification=True,
            )
        else:
            ss.awaiting_patient = False
            _run_report_request(
                client, cleaned, meta,
                name=report_request.get("name", ""), patient_id=report_request.get("patient_id", ""),
                dob=report_request.get("date_of_birth", ""), report_type=report_request.get("report_type", ""),
                intent="view_report",
            )
        st.rerun()
        return

    # 6. General Conversational Turn
    try:
        resp = client.turn(cleaned, input_mode, history=_llm_history())
        _add_turn(cleaned, meta, audio_warn, resp, is_clarification=False, client=client)
    except ApiError as exc:
        _add_error(cleaned, meta, exc)
    st.rerun()


DRAFT_VIEW_KEYS = (
    "original_transcript", "anatomical_site", "findings", "readable_draft",
    "uncertainty_detected", "uncertainty_note", "requires_clinician_review", "synthetic_data",
)
_CERTAINTY = {
    "uncertain_as_dictated": "Uncertain as dictated",
    "dictated_not_independently_verified": "Dictated, not independently verified",
}


def _dictation_spoken_summary(draft: dict) -> str:
    """What the assistant says aloud. Built ONLY from the backend's draft, so nothing new is claimed."""
    findings = draft.get("findings") or []
    if findings:
        f = findings[0]
        core = f"I've prepared a draft. Site: {f.get('anatomical_site')}. Finding: {f.get('finding')}."
        if draft.get("uncertainty_detected"):
            core += " Your wording was uncertain, so I marked it as uncertain."
    else:
        core = "I've kept your dictation as the draft, but I couldn't safely separate it into a site and finding."
    return core + " This is only what you dictated. Clinician review is required before it is used."


def _handle_dictation(client: DentVoiceClient, text: str, meta: str, warn: bool = False) -> None:
    """Turn a dictated observation into the same editable structured draft the Clinical Dictation page makes."""
    ss = st.session_state
    try:
        with st.spinner("Building structured clinical draft…"):
            draft = client.dictation(text)
    except ApiError as exc:
        _add_error(text, meta, exc)
        st.rerun()
        return
    ss.chat.append({
        "role": "user", "text": text, "meta": meta + " · clinical dictation",
        "warn": "Low transcription confidence. Please double-check this text." if warn else None,
    })
    _add_text_reply(None, "", _dictation_spoken_summary(draft), client=client)
    last = ss.chat[-1]
    last["draft"] = draft
    last["meta"] = "clinical dictation draft · original transcript preserved"
    st.rerun()


def _open_in_dictation(draft: dict) -> None:
    """Hand the draft to the full Clinical Dictation workflow (review, sign-off, finalised JSON)."""
    ss = st.session_state
    ss["dict_text"] = draft.get("original_transcript", "")
    ss["dict_draft"] = draft
    ss["dict_stt"] = None
    ss["dict_show_turn_off_prompt"] = False
    ss["dict_session_status"] = "active"
    for key in ("dict_readable_seed", "dict_reviewed"):
        ss.pop(key, None)
    ss.pending_nav = "Clinical Dictation"


def _check_edited_draft(edited_text: str, draft: dict) -> tuple[dict | None, str | None]:
    """Validate the clinician's edits to the draft JSON. The original transcript can never be altered."""
    try:
        obj = json.loads(edited_text)
    except json.JSONDecodeError as exc:
        return None, f"This is not valid JSON yet ({exc.msg}, line {exc.lineno}). Fix it before saving."
    if not isinstance(obj, dict):
        return None, "The draft must be a JSON object."
    if obj.get("original_transcript") != draft.get("original_transcript"):
        return None, "The original transcript is preserved verbatim and cannot be edited. Edit findings or the readable draft instead."
    if obj.get("requires_clinician_review") is not True:
        return None, "requires_clinician_review must stay true until a clinician has signed off in Clinical Dictation."
    return obj, None


def _render_inline_draft(draft: dict, idx: int) -> None:
    with st.container(border=True):
        st.markdown("**Clinical draft** · editable · requires clinician review")
        flags = []
        if draft.get("uncertainty_detected"):
            flags.append(draft.get("uncertainty_note") or "Uncertain wording was detected in the dictation.")
        if not draft.get("findings"):
            flags.append("No structured finding could be extracted. Only the original transcript is reliable.")
        flags.append("Clinician review is required before this draft is used in patient care.")
        for f in flags:
            theme.note(f, "warn")
        st.caption("Original transcript (kept verbatim)")
        st.markdown(f"> {draft.get('original_transcript', '')}")
        findings = draft.get("findings") or []
        st.markdown(f"**Anatomical site:** {draft.get('anatomical_site') or 'Not identified'}")
        for f in findings:
            st.markdown(f"- **{f.get('anatomical_site')}**: {f.get('finding')} _({_CERTAINTY.get(f.get('certainty'), f.get('certainty'))})_")
        st.markdown("**Readable draft**")
        st.markdown(draft.get("readable_draft", ""))
        view = {k: draft.get(k) for k in DRAFT_VIEW_KEYS if k in draft}
        edited = st.text_area(
            "Editable structured JSON", value=json.dumps(view, indent=2), key=f"inline_draft_json_{idx}", height=260,
        )
        obj, err = _check_edited_draft(edited, draft)
        if err:
            st.error(err)
        c1, c2 = st.columns(2)
        c1.download_button(
            "Download draft JSON", data=json.dumps(obj if obj else view, indent=2), file_name="clinical_draft.json",
            mime="application/json", disabled=obj is None, key=f"inline_draft_dl_{idx}", use_container_width=True,
        )
        if c2.button("Open in Clinical Dictation to review and sign off", key=f"inline_draft_open_{idx}", use_container_width=True):
            merged = dict(draft)
            if obj:
                merged.update({k: v for k, v in obj.items() if k != "original_transcript"})
            _open_in_dictation(merged)
            st.rerun()


def _render_history() -> None:
    """Render chat messages directly with in-chat PDF download buttons where generated."""
    chat = st.session_state.chat
    for idx, msg in enumerate(chat):
        with st.chat_message(msg["role"], avatar="🧑‍⚕️" if msg["role"] == "user" else "🦷"):
            if msg.get("error"):
                st.error(msg["error"])
                continue
            st.markdown(msg["text"])
            if msg.get("meta"):
                st.caption(msg["meta"])
            if msg.get("warn"):
                st.warning(msg["warn"])
            if msg.get("audio"):
                # Playback of NEW replies is done (and reported) by the microphone component. This visible player is
                # the manual fallback: replay a reply, or hear it when the browser blocked automatic audio.
                st.audio(msg["audio"], format="audio/wav")
            if msg.get("draft"):
                _render_inline_draft(msg["draft"], idx)
            if msg.get("pdf_bytes"):
                st.download_button(
                    "📄 Download Clinical Report (PDF)",
                    data=msg["pdf_bytes"],
                    file_name=msg.get("pdf_name", "DentVoice_Report.pdf"),
                    mime="application/pdf",
                    key=f"chat_pdf_{idx}",
                )


def _apply_event(event) -> bool:
    """Apply ONE browser-reported event to the session. Returns True when the UI must refresh."""
    ss = st.session_state
    if isinstance(event, PlaybackEvent):
        audio = ss.get("dv_audio")
        if event.state == "started":
            ss.dv_playing_id, ss.dv_audio_blocked = event.audio_id or "audio", False
        elif event.state == "blocked":
            ss.dv_audio_blocked = True           # keep the audio queued: the component offers a one-tap "play"
            ss.dv_playing_id = None
            return True
        else:                                     # ended / failed: the browser says playback is over
            ss.dv_playing_id = None
            if event.state == "failed":
                ss.timeout_message = f"Audio could not be played ({event.message or 'unknown reason'}). The written reply is complete; use the player under the message to try again."
        if event.audio_id and event.audio_id not in ss.dv_audio_done:
            ss.dv_audio_done.append(event.audio_id)
            del ss.dv_audio_done[:-50]
        if audio and audio.get("id") == event.audio_id:
            ss.dv_audio = None
        return True
    if isinstance(event, MicAction):
        if event.action == "resume":              # capture is genuinely running
            ss.dv_listening, ss.dv_user_paused, ss.dv_standby = True, False, False
            ss.dv_mic_error, ss.timeout_message = None, None
        elif event.action == "pause":
            ss.dv_listening, ss.dv_user_paused = False, True
            ss.timeout_message = "Paused. Tap the microphone, press Resume, or type \"Listen to me\" to continue."
        elif event.action == "idle_timeout":
            ss.dv_listening, ss.dv_standby = False, True
            ss.timeout_message = (
                f"Stopped listening after {SILENCE_TIMEOUT_SECONDS} seconds of silence. Your conversation and any pending "
                "question are kept. Tap the microphone or press Resume to continue."
            )
        elif event.action == "needs_tap":
            ss.dv_listening = False
            ss.timeout_message = "Your browser needs one tap on the microphone before it will let me listen."
        else:
            return False
        return True
    return False


def _handle_mic_error(event: MicError) -> None:
    ss = st.session_state
    ss.dv_turn_id = event.id                  # releases the component's gate for that (empty) utterance
    if event.code == "empty_audio":
        return                                # nothing was said: never treated as a request
    ss.dv_listening = False
    ss.dv_mic_error = event.message
    ss.timeout_message = f"Microphone: {event.message}"


def _process_utterance(client: DentVoiceClient, event: Utterance) -> None:
    ss = st.session_state
    ss.dv_turn_id = event.id
    if not event.wav or len(event.wav) <= 44:
        return
    try:
        import logging
        log_asst = logging.getLogger("dentvoice.assistant")
        log_asst.info("[Assistant] Received utterance id=%s, wav_bytes=%d", event.id, len(event.wav))
        with st.spinner("Transcribing…"):
            t_resp = client.stt(event.wav, "voice_input.wav")
        text = (t_resp.get("text") or "").strip()
        if not text:
            ss.timeout_message = "I couldn't catch that. Please try speaking again."
            st.rerun()
            return
        ss.timeout_message = None
        meta, low = _transcript_meta(t_resp)
        _handle_user_turn(client, text, input_mode="speech", audio_meta=meta, audio_warn=low)
    except ApiError as exc:
        msg_lower = str(exc.message or "").lower()
        quiet = "no speech" in msg_lower or "too quiet" in msg_lower or "silent" in msg_lower
        ss.timeout_message = "I couldn't catch that. Please try speaking again." if quiet else f"Audio capture note: {exc.message}. Please try speaking again."
        st.rerun()
    except Exception:
        ss.timeout_message = "I couldn't catch that. Please try speaking again."
        st.rerun()


_STATUS_TONE = {"speaking": "ok", "listening": "ok", "standby": "warn", "paused": "warn", "error": "warn", "idle": "navy"}


def _render_voice_controls(client: DentVoiceClient) -> None:
    """Hands-free voice panel. The microphone component plays assistant audio, runs the idle timer and reports what
    really happened; this function only reacts to those reports."""
    ss = st.session_state
    key, label = _voice_status()

    c1, c2 = st.columns([3, 1.4])
    with c1:
        st.markdown(theme.chip(label, _STATUS_TONE[key]), unsafe_allow_html=True)
    with c2:
        if ss.dv_listening:
            if st.button("⏸ Pause listening", key="btn_pause_voice", use_container_width=True):
                ss.dv_user_paused, ss.dv_listening = True, False
                ss.timeout_message = "Paused. Tap the microphone, press Resume, or type \"Listen to me\" to continue."
                st.rerun()
        elif key != "speaking":
            if st.button("🎙️ Resume listening", key="btn_enable_voice", type="primary", use_container_width=True):
                _request_resume()
                st.rerun()

    if ss.get("timeout_message"):
        st.info(f"ℹ️ {ss.timeout_message}")
    if ss.get("dv_audio_blocked"):
        st.warning("Your browser blocked automatic audio. Press “Tap to hear the reply” in the microphone panel, or play the message below.")

    events = dentvoice_mic_events(
        key="assistant_dentvoice_mic",
        assistant_state="idle",
        turn_id=ss.dv_turn_id,
        auto_start=bool(ss.voice_wanted and not ss.dv_user_paused and not ss.dv_standby),
        paused=bool(ss.dv_user_paused),
        standby=bool(ss.dv_standby),
        audio=ss.dv_audio,
        done_ids=ss.dv_audio_done,
        idle_timeout_ms=SILENCE_TIMEOUT_SECONDS * 1000,
        clarify=bool(ss.is_clarification),
        clarify_timeout_ms=CLARIFICATION_TIMEOUT_SECONDS * 1000,
        resume_nonce=ss.dv_resume_nonce,
        min_rms=0.006,
        min_speech_ms=200,
        end_silence_ms=900,
        hold_timeout_ms=120000,
    )
    refresh = False
    for event in events:
        if not _mark_seen(event.id):
            continue
        ss.dv_last_event_id = event.id
        if isinstance(event, Utterance):
            _process_utterance(client, event)       # ends with st.rerun()
            return
        if isinstance(event, MicError):
            _handle_mic_error(event)
            refresh = True
        else:
            refresh = _apply_event(event) or refresh
    if refresh:
        st.rerun()

    # Optional Audio File Upload Alternative (preserved)
    with st.expander("📁 Upload audio file instead", expanded=False):
        up = st.file_uploader(
            "Audio file",
            type=list(ALLOWED_AUDIO_EXTENSIONS),
            key=f"asst_up_{ss.mic_nonce}",
        )
        as_dictation = st.checkbox(
            "Treat this recording as clinical dictation (make a draft report)",
            key=f"asst_up_dict_{ss.mic_nonce}",
        )
        if up is not None:
            if st.button("Transcribe & Process Audio", key="btn_asst_up", use_container_width=True):
                try:
                    with st.spinner("Transcribing audio file…"):
                        t_resp = client.stt(up.getvalue(), up.name)
                    text = t_resp.get("text", "").strip()
                    if not text:
                        st.warning("No speech was detected in the uploaded audio file.")
                        return
                    meta, low = _transcript_meta(t_resp)
                    ss.mic_nonce += 1
                    _handle_user_turn(client, text, input_mode="speech", audio_meta=meta, audio_warn=low,
                                      force_dictation=as_dictation)
                except ApiError as exc:
                    ss.mic_nonce += 1
                    _add_error(None, "audio file", exc)
                    st.rerun()


def render(client: DentVoiceClient) -> None:
    _init()
    ss = st.session_state

    # Initial time-based greeting on first load
    _greet_if_needed(client)

    theme.page_header(
        "AI Assistant",
        "Your voice-first dental clinical assistant. Ask about reports, dictate notes, or get summaries.",
    )

    # Top Control Bar
    top = st.columns([3, 1.2, 1.2])
    top[0].caption("Contextual patient and report memory is preserved across turns.")
    ss.auto_play = top[1].toggle("Auto-play replies", value=ss.auto_play)
    if top[2].button("Clear chat", use_container_width=True, disabled=not ss.chat):
        ss.chat = []
        ss.active_patient = None
        ss.active_report = None
        ss.report_history = None
        ss.pending_report_choice = None
        ss.pending_report_name = None
        ss.pending_report_type = ""
        ss.pending_intent = None
        ss.pending_candidates = None
        ss.is_clarification = False
        ss.dv_audio = None
        ss.mic_nonce += 1
        st.rerun()

    # Active Context Indicator
    if ss.get("active_patient") or ss.get("active_report"):
        p_name = (ss.get("active_patient") or {}).get("name") or (ss.get("active_report") or {}).get("patient_name", "")
        p_id = (ss.get("active_patient") or {}).get("patient_id") or (ss.get("active_report") or {}).get("patient_id", "")
        rep_type = ((ss.get("active_report") or {}).get("report") or {}).get("type", "Report")
        st.markdown(
            theme.chip(f"Active Patient: {p_name} ({p_id})", "navy")
            + theme.chip(f"Loaded: {rep_type}", "ok"),
            unsafe_allow_html=True,
        )

    # Voice Controls & Live Status
    _render_voice_controls(client)

    st.divider()

    # Chat History Display
    _render_history()

    # Typed Chat Input (always accessible)
    prompt = st.chat_input("Type your message or request…", max_chars=4000)
    if prompt and prompt.strip():
        _handle_user_turn(client, prompt.strip(), input_mode="typed")
