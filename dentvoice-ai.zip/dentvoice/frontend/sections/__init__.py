"""UI sections (one module per sidebar page). Each exposes render(client)."""
