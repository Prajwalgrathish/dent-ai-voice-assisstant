"""Patient Reports: patient search and latest-report viewer.

Backend calls: /v1/dental/patients/search, /v1/dental/reports/latest.
The backend never silently picks between patients, so ambiguity (409 or status "ambiguous")
is shown as a prompt for more identifying details rather than an error.
"""

from __future__ import annotations

import re

import streamlit as st

try:
    import theme
    from api_client import ApiError, DentVoiceClient
except ImportError:
    from frontend import theme
    from frontend.api_client import ApiError, DentVoiceClient

REPORT_TYPES = ["Any type (latest)", "OPG", "Dental Examination", "Other…"]
DOB_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
CLARIFICATION_HINT = {
    "full_name": "Enter the patient's full name (first and last).",
    "date_of_birth_or_contact": "Several patients share this name. Add a date of birth, patient ID or registered contact below.",
}


def _init() -> None:
    ss = st.session_state
    ss.setdefault("rep_search", None)   # last /search response
    ss.setdefault("rep_report", None)   # last /reports/latest response
    ss.setdefault("rep_message", None)  # (kind, text) shown under the search box


def _run_search(client: DentVoiceClient, name: str) -> None:
    ss = st.session_state
    ss.rep_report, ss.rep_search, ss.rep_message = None, None, None
    try:
        with st.spinner("Searching…"):
            ss.rep_search = client.search_patient(name)
    except ApiError as exc:
        ss.rep_message = ("info" if exc.status == 404 else "error", exc.message)


def _load_report(client: DentVoiceClient, **kwargs) -> None:
    ss = st.session_state
    ss.rep_message = None
    try:
        with st.spinner("Loading report…"):
            ss.rep_report = client.latest_report(**kwargs)
    except ApiError as exc:
        ss.rep_report = None
        if exc.ambiguous:
            ss.rep_message = ("warning", exc.message + " Add the date of birth, patient ID or registered contact.")
        elif exc.status == 404:
            ss.rep_message = ("info", exc.message)
        else:
            ss.rep_message = ("error", exc.message)


def _show_message() -> None:
    kind_text = st.session_state.rep_message
    if kind_text:
        getattr(st, kind_text[0])(kind_text[1])


def _render_report(data: dict, client: DentVoiceClient) -> None:
    report = data.get("report") or {}
    st.markdown(
        '<div class="dv-card">'
        + f'<div style="display:flex;gap:2.5rem;flex-wrap:wrap">'
        f'<div>{theme.field("Patient", data.get("patient_name"))}</div>'
        f'<div>{theme.field("Patient ID", data.get("patient_id"))}</div>'
        f'<div>{theme.field("Report type", report.get("type"))}</div>'
        f'<div>{theme.field("Report date", report.get("date"))}</div>'
        f'<div>{theme.field("Report ID", report.get("report_id"))}</div></div></div>',
        unsafe_allow_html=True,
    )

    badges = ""
    if data.get("synthetic_data"):
        badges += theme.chip("Synthetic demo data", "warn")
    if data.get("requires_clinician_review"):
        badges += theme.chip("Clinician review required", "bad")
    if badges:
        st.markdown(badges, unsafe_allow_html=True)

    st.markdown("##### Findings")
    findings = report.get("findings")
    if isinstance(findings, list) and findings:
        for item in findings:
            st.markdown(f"- {item}")
    else:
        st.caption("No findings recorded in this report.")

    st.markdown("##### Impression")
    st.markdown(report.get("impression") or "_No impression recorded._")

    known = {"report_id", "type", "date", "findings", "impression"}
    extra = {k: v for k, v in report.items() if k not in known}
    if extra:
        st.markdown("##### Additional fields")
        for key, value in extra.items():
            st.markdown(f"**{key.replace('_', ' ').title()}:** {value}")

    p_name = data.get("patient_name") or "Patient"
    p_id = data.get("patient_id") or "P"
    r_id = report.get("report_id") or "R"
    try:
        pdf_bytes = client.report_pdf(
            name=p_name,
            patient_id=p_id,
            report_type=report.get("type", ""),
        )
    except Exception:
        from voiceassistant.dental.pdf import generate_patient_report_pdf

        pdf_bytes = generate_patient_report_pdf(
            patient_name=p_name,
            patient_id=p_id,
            report=report,
            synthetic_data=data.get("synthetic_data", True),
            requires_clinician_review=data.get("requires_clinician_review", True),
        )

    safe_pid = "".join(c for c in p_id if c.isalnum() or c in "-_")
    safe_rid = "".join(c for c in str(r_id) if c.isalnum() or c in "-_")
    filename = f"DentVoice_Report_{safe_pid}_{safe_rid}.pdf"

    st.download_button(
        "📄 Download Report as PDF",
        data=pdf_bytes,
        file_name=filename,
        mime="application/pdf",
        key="btn_rep_download_pdf",
        use_container_width=True,
    )

    with st.expander("Raw backend response"):
        st.json(data)


def render(client: DentVoiceClient) -> None:
    _init()
    ss = st.session_state
    theme.page_header("Patient Reports", "Find a patient, verify identity, and read their latest report.")

    left, right = st.columns([1, 1.6], gap="large")

    with left:
        st.markdown("##### 1 · Find patient")
        name = st.text_input("Patient name", placeholder="e.g. Arjun Rao", key="rep_name")
        if st.button("Search patient", type="primary", use_container_width=True, disabled=not name.strip()):
            _run_search(client, name.strip())
            st.rerun()

        result = ss.rep_search
        ambiguous = bool(result and result.get("status") == "ambiguous")
        if result and result.get("status") == "matched":
            st.markdown(theme.chip("Match found", "ok") + theme.chip((result.get("patient") or {}).get("name", ""), "navy"),
                        unsafe_allow_html=True)
        elif ambiguous:
            theme.note(result.get("message", "Multiple patients match."), "warn")
            hint = CLARIFICATION_HINT.get(result.get("clarification_type", ""))
            if hint:
                st.caption(hint)
        _show_message()

        st.markdown("##### 2 · Verify & choose report")
        with st.expander("Identity details", expanded=ambiguous):
            patient_id = st.text_input("Patient ID (optional)", placeholder="e.g. P003", key="rep_pid")
            dob = st.text_input("Date of birth (optional)", placeholder="YYYY-MM-DD", key="rep_dob")
            phone = st.text_input("Registered contact (optional)", key="rep_phone",
                                  help="Enter the full registered value. Masked values shown elsewhere will not match.")
        type_choice = st.selectbox("Report type", REPORT_TYPES, key="rep_type")
        report_type = ""
        if type_choice == "Other…":
            report_type = st.text_input("Custom report type", key="rep_type_custom")
        elif type_choice != REPORT_TYPES[0]:
            report_type = type_choice

        dob_ok = not dob.strip() or bool(DOB_PATTERN.match(dob.strip()))
        if not dob_ok:
            st.warning("Date of birth must look like 2001-02-18.")
        can_load = bool(name.strip() or patient_id.strip()) and dob_ok
        if st.button("Load latest report", use_container_width=True, disabled=not can_load):
            _load_report(client, name=name, patient_id=patient_id, date_of_birth=dob,
                         phone_contact=phone, report_type=report_type)
            st.rerun()

    with right:
        st.markdown("##### Report viewer")
        if ss.rep_report:
            _render_report(ss.rep_report, client)
        else:
            st.markdown('<div class="dv-card">No report loaded yet. Search for a patient, then choose '
                        '<b>Load latest report</b>.</div>', unsafe_allow_html=True)
