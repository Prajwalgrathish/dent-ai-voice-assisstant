"""Thin HTTP client for the existing DentVoice FastAPI backend (voiceassistant/api.py).

Pure transport: no business logic lives here. Everything talks to the local backend only.

Endpoints used (all already defined in the backend):
    GET  /health
    POST /v1/turn                  {text, input_mode}                -> TurnResponse
    POST /v1/stt                   multipart file                    -> TranscriptOut
    POST /v1/turn/audio            multipart file                    -> TurnResponse
    POST /v1/dental/patients/search {name}                           -> {status, ...}
    POST /v1/dental/reports/latest {name, patient_id, date_of_birth, phone_contact, report_type}
    POST /v1/clinical/dictation    {transcript}                      -> clinical draft JSON

Patient Voice Assistant (patient-facing; authorised by a bearer token from the Patient-ID login, never by a name):
    POST   /v1/patient/session     {patient_id}                      -> {session_token, patient, reports}
    DELETE /v1/patient/session
    GET    /v1/patient/reports
    POST   /v1/patient/chat        {message, input_mode, speak}      -> grounded answer + evidence
"""

from __future__ import annotations

import base64
import binascii
import mimetypes
import os
from pathlib import Path
from typing import Any, Optional

import requests

ALLOWED_AUDIO_EXTENSIONS = ("wav", "mp3", "flac", "ogg", "m4a", "webm")  # mirrors voiceassistant/audio.py
START_HINT = "uvicorn voiceassistant.api:create_app --factory --port 8000"


def _setting(name: str, default: str = "") -> str:
    """Environment variable, else the project's .env (one folder up), so .env.example's variables work here too."""
    if name in os.environ:
        return os.environ[name]
    try:
        for line in (Path(__file__).resolve().parent.parent / ".env").read_text(encoding="utf-8-sig").splitlines():
            key, sep, value = line.strip().partition("=")
            if sep and key.strip() == name:
                return value.split(" #", 1)[0].strip().strip("\"'")
    except OSError:
        pass
    return default


class ApiError(Exception):
    """Any failure talking to the backend, with a message that is safe to show the user."""

    def __init__(self, message: str, *, status: Optional[int] = None, stage: Optional[str] = None,
                 ambiguous: bool = False):
        super().__init__(message)
        self.message = message
        self.status = status
        self.stage = stage  # backend pipeline stage: input | audio | stt | llm | tts | config
        self.ambiguous = ambiguous


def _parse_error(resp: requests.Response) -> ApiError:
    try:
        body = resp.json()
    except ValueError:
        return ApiError(f"The backend returned HTTP {resp.status_code}.", status=resp.status_code)

    detail = body.get("detail", body) if isinstance(body, dict) else body
    stage, ambiguous = None, resp.status_code == 409

    if isinstance(detail, dict):  # {"stage","message"} or {"status":"ambiguous","message"}
        message = str(detail.get("message") or detail)
        stage = detail.get("stage")
        ambiguous = ambiguous or detail.get("status") == "ambiguous"
    elif isinstance(detail, list):  # FastAPI/pydantic validation errors
        parts = []
        for item in detail:
            if isinstance(item, dict):
                loc = ".".join(str(p) for p in item.get("loc", [])[1:])
                parts.append(f"{loc}: {item.get('msg')}" if loc else str(item.get("msg")))
        message = "; ".join(parts) or "The request was rejected by the backend."
    else:
        message = str(detail)
    return ApiError(message, status=resp.status_code, stage=stage, ambiguous=ambiguous)


def decode_audio(b64: Optional[str]) -> Optional[bytes]:
    """Decode audio_wav_base64 from a TurnResponse. Returns None if absent or corrupt."""
    if not b64:
        return None
    try:
        return base64.b64decode(b64, validate=True)
    except (binascii.Error, ValueError):
        return None


class DentVoiceClient:
    def __init__(self, base_url: str, timeout: float = 180.0, clinician_key: Optional[str] = None):
        self.base_url = (base_url or "").strip().rstrip("/")
        self.timeout = timeout  # generous: a CPU-only local LLM can take a while
        # Only needed when the backend sets DENTVOICE_CLINICIAN_API_KEY. Never shown in the UI.
        self.clinician_key = clinician_key if clinician_key is not None else _setting("DENTVOICE_CLINICIAN_API_KEY")

    # -- transport ---------------------------------------------------------------------------
    def _request(self, method: str, path: str, *, timeout: Optional[float] = None, **kwargs) -> Any:
        url = f"{self.base_url}{path}"
        if self.clinician_key and "/v1/patient/" not in path:
            kwargs["headers"] = {**kwargs.get("headers", {}), "X-Clinician-Key": self.clinician_key}
        try:
            resp = requests.request(method, url, timeout=timeout or self.timeout, **kwargs)
        except requests.exceptions.ConnectionError:
            raise ApiError(f"Cannot reach the backend at {self.base_url}. Start it with: {START_HINT}") from None
        except requests.exceptions.Timeout:
            raise ApiError("The backend took too long to respond. A local model may still be loading; try again.") from None
        except requests.exceptions.RequestException as exc:
            raise ApiError(f"Request failed: {exc.__class__.__name__}.") from None
        if not resp.ok:
            raise _parse_error(resp)
        try:
            return resp.json()
        except ValueError:
            raise ApiError("The backend returned a response that is not valid JSON.") from None

    @staticmethod
    def _file_part(data: bytes, filename: str) -> dict:
        ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        return {"file": (filename, data, ctype)}

    # -- system ------------------------------------------------------------------------------
    def health(self) -> dict:
        return self._request("GET", "/health", timeout=3.0)

    # -- assistant ---------------------------------------------------------------------------
    def turn(self, text: str, input_mode: str = "typed", history: Optional[list] = None) -> dict:
        payload: dict = {"text": text, "input_mode": input_mode}
        if history:
            payload["history"] = history  # earlier [{"role","content"}] turns so follow-ups keep their context
        return self._request("POST", "/v1/turn", json=payload)

    def stt(self, audio: bytes, filename: str = "recording.wav") -> dict:
        return self._request("POST", "/v1/stt", files=self._file_part(audio, filename))

    def turn_audio(self, audio: bytes, filename: str = "recording.wav") -> dict:
        return self._request("POST", "/v1/turn/audio", files=self._file_part(audio, filename))

    # -- patients ----------------------------------------------------------------------------
    def search_patient(self, name: str) -> dict:
        return self._request("POST", "/v1/dental/patients/search", json={"name": name})

    @staticmethod
    def _identity_payload(name, patient_id, date_of_birth, phone_contact, report_type) -> dict:
        """Callers pass None for "not given"; every field is optional text."""
        def clean(value) -> str:
            return (value or "").strip()
        return {
            "name": clean(name),
            "patient_id": clean(patient_id) or None,
            "date_of_birth": clean(date_of_birth) or None,
            "phone_contact": clean(phone_contact) or None,
            "report_type": clean(report_type) or None,
        }

    def latest_report(self, *, name: str = "", patient_id: str = "", date_of_birth: str = "",
                      phone_contact: str = "", report_type: str = "") -> dict:
        payload = self._identity_payload(name, patient_id, date_of_birth, phone_contact, report_type)
        return self._request("POST", "/v1/dental/reports/latest", json=payload)

    def report_history(self, patient_id: str) -> dict:
        return self._request("POST", "/v1/dental/reports/history", json={"patient_id": (patient_id or "").strip()})

    def tts(self, text: str) -> dict:
        return self._request("POST", "/v1/tts", json={"text": text})

    def report_pdf(self, *, name: str = "", patient_id: str = "", date_of_birth: str = "",
                   phone_contact: str = "", report_type: str = "") -> bytes:
        payload = self._identity_payload(name, patient_id, date_of_birth, phone_contact, report_type)
        url = f"{self.base_url}/v1/dental/reports/pdf"
        headers = {"X-Clinician-Key": self.clinician_key} if self.clinician_key else {}
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=self.timeout)
        except requests.exceptions.RequestException as exc:
            raise ApiError(f"Request failed: {exc.__class__.__name__}.") from None
        if not resp.ok:
            raise _parse_error(resp)
        return resp.content

    # -- clinical dictation ------------------------------------------------------------------
    def dictation(self, transcript: str) -> dict:
        return self._request("POST", "/v1/clinical/dictation", json={"transcript": transcript})

    # -- Patient Voice Assistant -------------------------------------------------------------
    @staticmethod
    def _bearer(token: str) -> dict:
        return {"Authorization": f"Bearer {token}"}

    def patient_login(self, patient_id: str) -> dict:
        return self._request("POST", "/v1/patient/session", json={"patient_id": patient_id}, timeout=15.0)

    def patient_logout(self, token: str) -> None:
        try:
            self._request("DELETE", "/v1/patient/session", headers=self._bearer(token), timeout=5.0)
        except ApiError:
            pass  # the session is discarded locally either way

    def patient_reports(self, token: str) -> dict:
        return self._request("GET", "/v1/patient/reports", headers=self._bearer(token), timeout=15.0)

    def patient_chat(self, token: str, message: str, input_mode: str = "typed", speak: bool = True) -> dict:
        return self._request(
            "POST", "/v1/patient/chat", headers=self._bearer(token),
            json={"message": message, "input_mode": input_mode, "speak": speak},
        )
