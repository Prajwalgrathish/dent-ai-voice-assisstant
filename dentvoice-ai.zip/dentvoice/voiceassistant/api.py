"""FastAPI layer. Requires: pip install -r requirements-api.txt

Run:  uvicorn voiceassistant.api:create_app --factory --port 8000

NOTE: this module was written without FastAPI being installable in the authoring environment,
so it has only been syntax-checked there. Run tests/test_api.py on your machine.
"""

import base64
import hmac
import logging
import os
import uuid
from pathlib import Path
from typing import Literal, Optional

from fastapi import Depends, FastAPI, File, Header, HTTPException, Request, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field

from .audio import ALLOWED_EXTENSIONS
from .config import Settings
from .errors import VoiceAssistantError
from .factory import build_pipeline
from .models import TurnResult
from .pipeline import VoicePipeline
from .dental.pdf import generate_patient_report_pdf
from .dental.service import (
    AmbiguousPatientError,
    PatientNotFoundError,
    get_latest_report,
    get_report_history,
    list_patient_candidates,
)
from .speech_cleaner import clean_text_for_speech
from .patient.assistant import PatientAssistant, PatientInputError
from .patient.sessions import (
    LoginLimiter,
    PatientAuthError,
    PatientIdNotFound,
    PatientSession,
    SessionStore,
    TooManyAttempts,
    normalize_patient_id,
    short_hash,
)
from .patient.tools import PatientTools, ToolError
from .dental.service import load_patients

log = logging.getLogger(__name__)
_STATUS = {"input": 422, "audio": 422, "stt": 500, "llm": 502, "tts": 500, "config": 500}


class HistoryItem(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=4000)


class TurnRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    input_mode: Literal["typed", "speech"] = "typed"  # "speech" = text already came from /v1/stt
    history: list[HistoryItem] = Field(default_factory=list, max_length=20)  # earlier turns, so follow-ups keep context


class PatientLoginRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    patient_id: str = Field(min_length=1, max_length=40)


class PatientChatRequest(BaseModel):
    """Deliberately has no patient_id / name / report-owner field: the patient is the signed-in session, full stop."""

    model_config = ConfigDict(extra="forbid")
    message: str = Field(min_length=1, max_length=1000)
    input_mode: Literal["typed", "speech"] = "typed"
    speak: bool = False


class TranscriptOut(BaseModel):
    text: str
    confidence: Optional[float] = None
    low_confidence: bool = False
    provider: str = ""


class TurnResponse(BaseModel):
    input_mode: str
    user_text: str
    transcript: Optional[TranscriptOut] = None
    reply_text: str
    tts_engine: Optional[str] = None
    audio_wav_base64: Optional[str] = None  # None if TTS failed; reply_text is still valid
    tts_error: Optional[str] = None


def _fail(stage: str, message: str, status: Optional[int] = None):
    return HTTPException(status_code=status or _STATUS.get(stage, 500), detail={"stage": stage, "message": message})


def _to_response(pipeline: VoicePipeline, result: TurnResult) -> TurnResponse:
    if result.error:
        raise _fail(result.error.stage, result.error.message)
    audio_b64 = None
    if result.audio_path:
        try:
            audio_b64 = base64.b64encode(Path(result.audio_path).read_bytes()).decode("ascii")
        finally:
            pipeline.cleanup(result)
    t = result.transcript
    return TurnResponse(
        input_mode=result.input_mode,
        user_text=result.user_text,
        transcript=TranscriptOut(text=t.text, confidence=t.confidence, low_confidence=t.low_confidence, provider=t.provider)
        if t
        else None,
        reply_text=result.reply_text,
        tts_engine=result.tts_engine,
        audio_wav_base64=audio_b64,
        tts_error=result.tts_error.message if result.tts_error else None,
    )


def _save_upload(upload: UploadFile, settings: Settings) -> Path:
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise _fail("audio", "Unsupported audio format.", 415)
    dest = settings.tmp_dir / f"upload-{uuid.uuid4().hex}{suffix}"  # server-chosen name, never the client's
    size = 0
    try:
        with open(dest, "wb") as fh:
            while chunk := upload.file.read(1024 * 1024):
                size += len(chunk)
                if size > settings.max_audio_bytes:
                    raise _fail("audio", "The audio file is too large.", 413)
                fh.write(chunk)
    except BaseException:
        dest.unlink(missing_ok=True)
        raise
    return dest



class DentalPatientSearchRequest(BaseModel):
    name: str = Field(min_length=1, max_length=100)


class DentalLatestReportRequest(BaseModel):
    name: str = Field(default="", max_length=100)
    patient_id: Optional[str] = Field(default=None, max_length=50)
    date_of_birth: Optional[str] = Field(default=None, max_length=10)
    phone_contact: Optional[str] = Field(default=None, max_length=50)
    report_type: Optional[str] = Field(default=None, max_length=50)


# Shown whenever a name matches several patients. It never names, numbers or describes any candidate.
AMBIGUOUS_PATIENT_MESSAGE = (
    "Multiple patients match that name. Please provide the intended patient's ID "
    "or use the authorized patient lookup workflow."
)


class DentalReportHistoryRequest(BaseModel):
    patient_id: str = Field(min_length=1, max_length=50)


class ClinicalDictationRequest(BaseModel):
    transcript: str = Field(min_length=1, max_length=4000)


class TTSRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)


class DentalReportPdfRequest(BaseModel):
    name: str = Field(default="", max_length=100)
    patient_id: Optional[str] = Field(default=None, max_length=50)
    date_of_birth: Optional[str] = Field(default=None, max_length=10)
    phone_contact: Optional[str] = Field(default=None, max_length=50)
    report_type: Optional[str] = Field(default=None, max_length=50)


def _build_clinical_draft(transcript: str) -> dict:
    """Extract only explicit dictated text; never generate new clinical claims."""
    import re

    original = transcript.strip()
    if not original:
        raise HTTPException(status_code=422, detail="Transcript cannot be empty.")

    # Conservative pattern: identify a tooth/site before "is" or "shows".
    match = re.match(
        r"^(?P<site>.+?)\s+(?:is|shows|demonstrates)\s+(?P<finding>.+?)\.?$",
        original,
        flags=re.IGNORECASE,
    )

    site = None
    finding = None
    uncertainty_terms = (
        "possible", "possibly", "suspected", "suspect", "may be",
        "might be", "cannot exclude", "uncertain", "unclear",
    )
    uncertainty_detected = any(
        term in original.casefold() for term in uncertainty_terms
    )

    if match:
        candidate_site = match.group("site").strip(" ,.")
        candidate_finding = match.group("finding").strip(" ,.")
        # Only split into site/finding when the site looks like an anatomical
        # dental reference. Otherwise preserve the transcript without guessing.
        dental_terms = (
            "molar", "incisor", "canine", "premolar", "tooth",
            "teeth", "gingiva", "gum", "mandible", "maxilla",
            "jaw", "palate", "tongue",
        )
        if any(term in candidate_site.casefold() for term in dental_terms):
            site = candidate_site
            finding = candidate_finding

    findings = []
    if site and finding:
        findings.append({
            "anatomical_site": site,
            "finding": finding,
            "source_text": original,
            "certainty": (
                "uncertain_as_dictated"
                if uncertainty_detected
                else "dictated_not_independently_verified"
            ),
        })

    # Integrate voiceassistant.dictation draft builder
    import json
    from voiceassistant.dictation import build_draft
    synth_llm_json = json.dumps({
        "chief_complaint": None,
        "patient_reported_symptoms": [],
        "observed_findings": [finding] if finding else [],
        "anatomical_sites": [site] if site else [],
        "assessment": None,
        "recommendations": [],
    })
    validated_draft = build_draft(original, synth_llm_json)

    return {
        "original_transcript": original,
        "findings": findings,
        "anatomical_site": site,
        "readable_draft": (
            f"Draft report based on clinician dictation: {original}"
        ),
        "uncertainty_detected": uncertainty_detected or not findings,
        "uncertainty_note": (
            "Review the uncertain wording against the original clinical evidence."
            if uncertainty_detected
            else (
                "The transcript could not be safely separated into a site and finding."
                if not findings
                else None
            )
        ),
        "requires_clinician_review": True,
        "synthetic_data": True,
        # Validated structured dictation draft
        "dictation_draft": validated_draft,
    }


def _env_lookup(dotenv_path: str = ".env"):
    """os.environ first, then the project's .env file, so every variable documented in .env.example really works."""
    from .config import parse_dotenv

    file_values: dict[str, str] = {}
    path = Path(dotenv_path)
    if path.is_file():
        file_values = parse_dotenv(path.read_text(encoding="utf-8-sig"))

    def get(name: str, default: str = "") -> str:
        return os.environ.get(name, file_values.get(name, default))

    return get


def _bearer(authorization: Optional[str]) -> Optional[str]:
    if not authorization:
        return None
    scheme, _, token = authorization.partition(" ")
    return token.strip() if scheme.lower() == "bearer" and token.strip() else None


def create_app(
    pipeline: Optional[VoicePipeline] = None,
    *,
    patient_assistant: Optional[PatientAssistant] = None,
    session_store: Optional[SessionStore] = None,
    login_limiter: Optional[LoginLimiter] = None,
    clinician_api_key: Optional[str] = None,
) -> FastAPI:
    if pipeline is None:
        pipeline = build_pipeline(Settings.from_env(dotenv_path=".env"))
    settings = pipeline.settings
    app = FastAPI(title="Voice Assistant API", version="0.3.0")
    env = _env_lookup()

    origins = [o.strip() for o in env("CORS_ORIGINS", "http://localhost:8501,http://127.0.0.1:8501").split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=False,  # auth is a bearer header, never a cookie
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Optional shared secret for the CLINICIAN-side endpoints (reports by name, free-form turns, dictation).
    # Unset = open, as in the original demo. Set DENTVOICE_CLINICIAN_API_KEY to require `X-Clinician-Key`.
    clinician_key = clinician_api_key if clinician_api_key is not None else env("DENTVOICE_CLINICIAN_API_KEY", "")

    def require_clinician(x_clinician_key: Optional[str] = Header(default=None)) -> None:
        if clinician_key and not hmac.compare_digest(x_clinician_key or "", clinician_key):
            raise HTTPException(status_code=401, detail={"stage": "auth", "message": "A valid clinician key is required."})

    sessions = session_store if session_store is not None else SessionStore(
        ttl_s=float(env("PATIENT_SESSION_TTL_S", "1800")), idle_s=float(env("PATIENT_SESSION_IDLE_S", "900"))
    )
    limiter = login_limiter if login_limiter is not None else LoginLimiter(max_failures=int(env("PATIENT_LOGIN_MAX_FAILURES", "10")))
    if patient_assistant is None:
        use_llm = pipeline.llm.name != "fake_llm" and env("PATIENT_USE_LLM", "1") != "0"
        patient_assistant = PatientAssistant(
            llm=pipeline.llm if use_llm else None,
            interpreter_mode=env("PATIENT_INTERPRETER", "rules_first"),
            llm_explanations=use_llm,
        )
    assistant = patient_assistant

    def current_session(authorization: Optional[str] = Header(default=None)) -> PatientSession:
        try:
            return sessions.get(_bearer(authorization))
        except PatientAuthError as exc:
            raise HTTPException(status_code=exc.status, detail={"stage": "auth", "message": exc.user_message}) from None

    @app.get("/health")
    def health():
        return {"status": "ok", "stt": pipeline.stt.name, "llm": pipeline.llm.name, "tts": pipeline.tts.name}

    @app.post("/v1/turn", response_model=TurnResponse, dependencies=[Depends(require_clinician)])
    def turn(req: TurnRequest):
        """Text in -> reply (+ spoken audio). input_mode='typed' means no speech recognition was used."""
        history = [h.model_dump() for h in req.history] or None
        return _to_response(pipeline, pipeline.respond(req.text, req.input_mode, history=history))

    @app.post("/v1/stt", response_model=TranscriptOut)
    def stt(file: UploadFile = File(...)):
        """Audio in -> transcript only, so the client can show/edit it before calling /v1/turn."""
        path = _save_upload(file, settings)
        try:
            t = pipeline.transcribe(path)
        except VoiceAssistantError as exc:
            raise _fail(exc.stage, exc.user_message) from None
        finally:
            path.unlink(missing_ok=True)
        return TranscriptOut(text=t.text, confidence=t.confidence, low_confidence=t.low_confidence, provider=t.provider)

    @app.post("/v1/turn/audio", response_model=TurnResponse, dependencies=[Depends(require_clinician)])
    def turn_audio(file: UploadFile = File(...)):
        """Audio in -> STT -> LLM -> TTS in one call."""
        path = _save_upload(file, settings)
        try:
            result = pipeline.run_audio(path)
        finally:
            path.unlink(missing_ok=True)
        return _to_response(pipeline, result)


    
    @app.post("/v1/dental/patients/search", dependencies=[Depends(require_clinician)])
    def dental_patient_search(req: DentalPatientSearchRequest):
        try:
            candidates = list_patient_candidates(req.name)
        except PatientNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from None

        if not candidates:
            raise HTTPException(
                status_code=404,
                detail="No matching patient was found.",
            )

        if len(candidates) > 1:
            unique_names = {
                c["name"].strip().casefold() for c in candidates
            }

            if len(unique_names) > 1:
                message = (
                    "Multiple patients match. Please specify the patient's full name."
                )
                clarification_type = "full_name"
            else:
                message = (
                    "Multiple patients share this full name. "
                    "Please confirm the date of birth or registered contact details."
                )
                clarification_type = "date_of_birth_or_contact"

            return {
                "status": "ambiguous",
                "message": message,
                "clarification_type": clarification_type,
                "synthetic_data": True,
            }

        return {
            "status": "matched",
            "patient": {"name": candidates[0]["name"]},
            "synthetic_data": True,
        }


    @app.post("/v1/dental/reports/latest", dependencies=[Depends(require_clinician)])
    def dental_latest_report(req: DentalLatestReportRequest):
        try:
            return get_latest_report(
                name=req.name,
                patient_id=req.patient_id,
                date_of_birth=req.date_of_birth,
                phone_contact=req.phone_contact,
                report_type=req.report_type,
            )
        except AmbiguousPatientError as exc:
            raise HTTPException(
                status_code=409,
                detail={
                    "status": "ambiguous",
                    "message": AMBIGUOUS_PATIENT_MESSAGE,
                },
            ) from None
        except PatientNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from None

    @app.post("/v1/dental/reports/history", dependencies=[Depends(require_clinician)])
    def dental_report_history(req: DentalReportHistoryRequest):
        """All reports for one canonical patient ID, newest first (used to resolve 'previous', 'earlier', ...)."""
        try:
            return get_report_history(req.patient_id)
        except (AmbiguousPatientError, PatientNotFoundError) as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from None

    @app.post("/v1/clinical/dictation", dependencies=[Depends(require_clinician)])
    def clinical_dictation(req: ClinicalDictationRequest):
        """Transcript in -> conservative, editable clinical draft JSON."""
        return _build_clinical_draft(req.transcript)

    @app.post("/v1/tts")
    def synthesize_speech(req: TTSRequest):
        """Synthesize text into WAV audio using the configured TTS pipeline."""
        clean_speech = clean_text_for_speech(req.text)
        dest = settings.tmp_dir / f"tts-{uuid.uuid4().hex}.wav"
        try:
            pipeline.tts.synthesize(clean_speech, dest)
            audio_b64 = base64.b64encode(dest.read_bytes()).decode("ascii")
            return {
                "text": req.text,
                "clean_text": clean_speech,
                "audio_wav_base64": audio_b64,
                "tts_engine": pipeline.tts.name,
            }
        except VoiceAssistantError as exc:
            raise _fail(exc.stage, exc.user_message) from None
        except Exception as exc:
            log.exception("TTS synthesis failed")
            raise _fail("tts", f"Text-to-speech synthesis failed: {exc}") from None
        finally:
            dest.unlink(missing_ok=True)

    @app.post("/v1/dental/reports/pdf", dependencies=[Depends(require_clinician)])
    def dental_report_pdf(req: DentalReportPdfRequest):
        """Generate a verified PDF report for an unambiguously identified patient."""
        try:
            data = get_latest_report(
                name=req.name,
                patient_id=req.patient_id,
                date_of_birth=req.date_of_birth,
                phone_contact=req.phone_contact,
                report_type=req.report_type,
            )
        except AmbiguousPatientError as exc:
            raise HTTPException(
                status_code=409,
                detail={"status": "ambiguous", "message": AMBIGUOUS_PATIENT_MESSAGE},
            ) from None
        except PatientNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from None

        patient_dict = {
            "patient_id": data["patient_id"],
            "name": data["patient_name"],
            "date_of_birth": req.date_of_birth or "",
        }
        report_dict = dict(data["report"])
        report_dict["patient_id"] = data["patient_id"]

        try:
            from voiceassistant.report_pdf import build_report_pdf
            pdf_bytes = build_report_pdf(
                patient=patient_dict,
                reports=[report_dict],
                kind="report",
                synthetic=data.get("synthetic_data", True),
            )
        except Exception:
            pdf_bytes = generate_patient_report_pdf(
                patient_name=data["patient_name"],
                patient_id=data["patient_id"],
                report=data["report"],
                date_of_birth=req.date_of_birth or "",
                phone_contact=req.phone_contact or "",
                synthetic_data=data.get("synthetic_data", True),
                requires_clinician_review=data.get("requires_clinician_review", True),
            )

        safe_pid = "".join(c for c in data["patient_id"] if c.isalnum() or c in "-_")
        safe_rid = "".join(
            c for c in str(data["report"].get("report_id", "")) if c.isalnum() or c in "-_"
        )
        filename = f"DentVoice_Report_{safe_pid}_{safe_rid}.pdf"

        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    # ───────────────────────── Patient Voice Assistant (patient-facing) ─────────────────────────
    # Authorization model: POST /v1/patient/session exchanges a Patient ID for an opaque bearer token.
    # Every other /v1/patient/* call derives the patient ONLY from that token. No request body, query or
    # path parameter can name a different patient, and report IDs are resolved inside the caller's record.
    def _auth_http(exc: PatientAuthError) -> HTTPException:
        return HTTPException(status_code=exc.status, detail={"stage": "auth", "message": exc.user_message})

    @app.post("/v1/patient/session")
    def patient_login(req: PatientLoginRequest, request: Request):
        client_key = short_hash(request.client.host if request.client else "unknown")
        try:
            if limiter.blocked(client_key):
                raise TooManyAttempts()
            pid = normalize_patient_id(req.patient_id)
            record = next((p for p in load_patients() if str(p.get("patient_id")) == pid), None)
            if record is None:
                limiter.record_failure(client_key)
                raise PatientIdNotFound()
        except PatientAuthError as exc:
            if not isinstance(exc, TooManyAttempts) and not isinstance(exc, PatientIdNotFound):
                limiter.record_failure(client_key)
            log.info("patient_login failed reason=%s client=%s", type(exc).__name__, client_key)
            raise _auth_http(exc) from None
        limiter.reset(client_key)
        session = sessions.create(pid)
        tools = PatientTools(pid)
        log.info("patient_login ok sid=%s", session.tag)
        return {
            "session_token": session.token,
            "expires_in_s": int(sessions.idle_s),
            "patient": {"first_name": tools.patient_first_name()},
            "reports": tools.list_my_reports(),
            "notices": [
                "Demonstration only: your Patient ID is the only credential here. A real service must verify who you are more strongly.",
                "Reports are synthetic demonstration data.",
            ],
            "synthetic_data": True,
        }

    @app.get("/v1/patient/session")
    def patient_whoami(session: PatientSession = Depends(current_session)):
        tools = PatientTools(session.patient_id)
        return {"patient": {"first_name": tools.patient_first_name()}, "reports": tools.list_my_reports(), "synthetic_data": True}

    @app.delete("/v1/patient/session")
    def patient_logout(authorization: Optional[str] = Header(default=None)):
        sessions.end(_bearer(authorization))
        return {"status": "signed_out"}

    @app.get("/v1/patient/reports")
    def patient_reports(session: PatientSession = Depends(current_session)):
        return {"reports": PatientTools(session.patient_id).list_my_reports(), "synthetic_data": True}

    @app.get("/v1/patient/reports/{report_id}")
    def patient_report(report_id: str, session: PatientSession = Depends(current_session)):
        try:
            report = PatientTools(session.patient_id).get_my_report(report_id=report_id)
        except ToolError:
            # Same answer for "does not exist" and "belongs to someone else": existence is not disclosed.
            log.info("patient_report_denied sid=%s", session.tag)
            raise HTTPException(status_code=404, detail={"stage": "report", "message": "Report not found."}) from None
        return {"report": report, "synthetic_data": True, "requires_clinician_review": True}

    @app.post("/v1/patient/chat")
    def patient_chat(req: PatientChatRequest, session: PatientSession = Depends(current_session)):
        try:
            result = assistant.answer(session, req.message)
        except PatientInputError as exc:
            raise HTTPException(status_code=422, detail={"stage": "input", "message": exc.user_message}) from None
        except Exception:  # noqa: BLE001 - never leak internals or patient data in an error
            log.exception("patient_chat failed sid=%s", session.tag)
            raise HTTPException(status_code=500, detail={"stage": "app", "message": "Something went wrong answering that. Please try again."}) from None
        body = {
            "answer": result.answer,
            "sections": result.sections,
            "intent": result.intent,
            "grounding": result.grounding,
            "evidence": result.evidence,
            "general_info": result.general_info,
            "report_used": result.report_used,
            "refusal": result.refusal,
            "interpretation": result.interpretation,
            "guardrail": result.guardrail,
            "timings_ms": dict(result.timings_ms),
            "notices": result.notices,
            "synthetic_data": result.synthetic_data,
            "input_mode": req.input_mode,
            "audio_wav_base64": None,
            "tts_engine": None,
            "tts_error": None,
        }
        if req.speak:
            import time as _time

            t = _time.perf_counter()
            spoken = pipeline.speak_text(result.answer, req.input_mode)
            if spoken.audio_path:
                try:
                    body["audio_wav_base64"] = base64.b64encode(Path(spoken.audio_path).read_bytes()).decode("ascii")
                finally:
                    pipeline.cleanup(spoken)
                body["tts_engine"] = spoken.tts_engine
            if spoken.tts_error:
                body["tts_error"] = spoken.tts_error.message
            body["timings_ms"]["tts"] = round((_time.perf_counter() - t) * 1000.0, 2)
        return body

    return app
