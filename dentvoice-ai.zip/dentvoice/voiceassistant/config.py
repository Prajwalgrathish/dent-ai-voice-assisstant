"""Configuration from environment variables (and an optional .env file).

Standard library only. Real environment variables override values in .env.
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

from .errors import ConfigError

STT_PROVIDERS = {"faster_whisper", "fake"}
LLM_PROVIDERS = {"openai_compat", "fake"}
TTS_PROVIDERS = {"piper", "pyttsx3", "fake"}
SUPPORTED_LANGUAGES = {"en"}  # Hindi etc. are a later phase.
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}

SILENCE_TIMEOUT_SECONDS = 15
CLARIFICATION_TIMEOUT_SECONDS = 30

DEFAULT_SYSTEM_PROMPT = (
    "You are a helpful voice assistant. Your replies are read aloud, so answer in short, "
    "natural spoken English: plain sentences, no markdown, no bullet lists, no emojis. "
    "If a request is unclear, ask one short clarifying question. "
    "Do not invent facts, and say so when you are unsure. "
    "You cannot perform actions in the outside world, so never claim that you did."
)


def parse_dotenv(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export "):].strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        elif " #" in value:
            value = value.split(" #", 1)[0].rstrip()
        if key:
            values[key] = value
    return values


def _str(env: dict[str, str], key: str, default: str) -> str:
    value = env.get(key)
    return default if value is None or value.strip() == "" else value.strip()


def _num(env, key, default, cast, minimum=None, maximum=None):
    raw = env.get(key, "").strip()
    if raw == "":
        return default
    try:
        value = cast(raw)
    except ValueError:
        raise ConfigError(f"{key} must be a valid {cast.__name__}.") from None
    if minimum is not None and value < minimum:
        raise ConfigError(f"{key} must be >= {minimum}.")
    if maximum is not None and value > maximum:
        raise ConfigError(f"{key} must be <= {maximum}.")
    return value


@dataclass(frozen=True)
class Settings:
    language: str = "en"

    stt_provider: str = "faster_whisper"
    stt_model: str = "base.en"
    stt_device: str = "cpu"
    stt_compute_type: str = "int8"
    stt_min_confidence: float = 0.45

    llm_provider: str = "openai_compat"
    llm_base_url: str = "http://localhost:11434/v1"
    llm_api_key: str = field(default="", repr=False)  # never printed
    llm_model: str = "qwen2.5:3b"
    llm_timeout_s: float = 60.0
    llm_max_retries: int = 2
    llm_temperature: float = 0.4
    llm_max_tokens: int = 300
    system_prompt: str = DEFAULT_SYSTEM_PROMPT

    tts_providers: tuple[str, ...] = ("piper", "pyttsx3")
    piper_model_path: str = ""
    piper_length_scale: float = 1.0  # >1 slower, <1 faster
    tts_rate_wpm: int = 170  # pyttsx3 only
    tts_max_chars: int = 400  # longer replies are spoken in chunks

    max_audio_bytes: int = 10_000_000
    max_audio_seconds: float = 60.0
    max_input_chars: int = 2000
    silence_timeout_seconds: int = SILENCE_TIMEOUT_SECONDS
    clarification_timeout_seconds: int = CLARIFICATION_TIMEOUT_SECONDS
    tmp_dir: Path = Path(tempfile.gettempdir()) / "voiceassistant"

    @classmethod
    def from_env(cls, environ: dict[str, str] | None = None, dotenv_path: str | Path | None = None) -> "Settings":
        env: dict[str, str] = {}
        if dotenv_path:
            path = Path(dotenv_path)
            if path.is_file():
                env.update(parse_dotenv(path.read_text(encoding="utf-8-sig")))
        env.update(os.environ if environ is None else environ)

        tts_names = tuple(
            n.strip().lower() for n in _str(env, "TTS_PROVIDER", "piper,pyttsx3").split(",") if n.strip()
        )
        settings = cls(
            language=_str(env, "LANGUAGE", "en").lower(),
            stt_provider=_str(env, "STT_PROVIDER", "faster_whisper").lower(),
            stt_model=_str(env, "STT_MODEL", "base.en"),
            stt_device=_str(env, "STT_DEVICE", "cpu"),
            stt_compute_type=_str(env, "STT_COMPUTE_TYPE", "int8"),
            stt_min_confidence=_num(env, "STT_MIN_CONFIDENCE", 0.45, float, 0.0, 1.0),
            llm_provider=_str(env, "LLM_PROVIDER", "openai_compat").lower(),
            llm_base_url=_str(env, "LLM_BASE_URL", "http://localhost:11434/v1").rstrip("/"),
            llm_api_key=env.get("LLM_API_KEY", "").strip(),
            llm_model=_str(env, "LLM_MODEL", "qwen2.5:3b"),
            llm_timeout_s=_num(env, "LLM_TIMEOUT_S", 60.0, float, 1.0, 600.0),
            llm_max_retries=_num(env, "LLM_MAX_RETRIES", 2, int, 0, 5),
            llm_temperature=_num(env, "LLM_TEMPERATURE", 0.4, float, 0.0, 2.0),
            llm_max_tokens=_num(env, "LLM_MAX_TOKENS", 300, int, 16, 8192),
            system_prompt=_str(env, "SYSTEM_PROMPT", DEFAULT_SYSTEM_PROMPT),
            tts_providers=tts_names,
            piper_model_path=_str(env, "PIPER_MODEL_PATH", ""),
            piper_length_scale=_num(env, "PIPER_LENGTH_SCALE", 1.0, float, 0.3, 3.0),
            tts_rate_wpm=_num(env, "TTS_RATE_WPM", 170, int, 80, 300),
            tts_max_chars=_num(env, "TTS_MAX_CHARS", 400, int, 20, 5000),
            max_audio_bytes=_num(env, "MAX_AUDIO_BYTES", 10_000_000, int, 1_000, 200_000_000),
            max_audio_seconds=_num(env, "MAX_AUDIO_SECONDS", 60.0, float, 1.0, 600.0),
            max_input_chars=_num(env, "MAX_INPUT_CHARS", 2000, int, 1, 20_000),
            silence_timeout_seconds=_num(env, "SILENCE_TIMEOUT_SECONDS", SILENCE_TIMEOUT_SECONDS, int, 1, 3600),
            clarification_timeout_seconds=_num(env, "CLARIFICATION_TIMEOUT_SECONDS", CLARIFICATION_TIMEOUT_SECONDS, int, 1, 3600),
            tmp_dir=Path(_str(env, "TMP_DIR", str(Path(tempfile.gettempdir()) / "voiceassistant"))),
        )
        settings.validate()
        return settings

    def validate(self) -> None:
        if self.language not in SUPPORTED_LANGUAGES:
            raise ConfigError(f"LANGUAGE={self.language!r} is not supported yet. Only 'en' is implemented.")
        if self.stt_provider not in STT_PROVIDERS:
            raise ConfigError(f"Unknown STT_PROVIDER {self.stt_provider!r}. Choose from {sorted(STT_PROVIDERS)}.")
        if self.llm_provider not in LLM_PROVIDERS:
            raise ConfigError(f"Unknown LLM_PROVIDER {self.llm_provider!r}. Choose from {sorted(LLM_PROVIDERS)}.")
        if not self.tts_providers:
            raise ConfigError("TTS_PROVIDER must name at least one provider.")
        for name in self.tts_providers:
            if name not in TTS_PROVIDERS:
                raise ConfigError(f"Unknown TTS_PROVIDER entry {name!r}. Choose from {sorted(TTS_PROVIDERS)}.")
        if self.llm_provider == "openai_compat":
            parsed = urlparse(self.llm_base_url)
            if parsed.scheme not in ("http", "https") or not parsed.hostname:
                raise ConfigError("LLM_BASE_URL must be an http(s) URL, e.g. http://localhost:11434/v1")
            if parsed.hostname not in _LOCAL_HOSTS and not self.llm_api_key:
                raise ConfigError(
                    "LLM_API_KEY is required when LLM_BASE_URL is not a local address.",
                )
