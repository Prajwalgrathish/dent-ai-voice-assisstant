"""Curated plain-English dental glossary.

This is *general information*, never a statement about a particular patient. Each entry has a
`simple` one-sentence definition (used for "explain in simple English") and a fuller `general`
explanation. Answers built from this glossary are always labelled as general information.
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Term:
    key: str
    simple: str
    general: str
    aliases: tuple[str, ...] = ()


_TERMS = [
    Term(
        "molar",
        "Molars are the big, flat teeth at the back of your mouth that grind food.",
        "Molars are the large teeth at the back of the mouth. Adults usually have twelve, including the wisdom teeth. "
        "Their wide, ridged surfaces are built for grinding food.",
        ("molars", "molar teeth", "molar tooth"),
    ),
    Term(
        "third molar",
        "A third molar is a wisdom tooth, the last tooth at the very back of each side of the jaw.",
        "Third molars are also called wisdom teeth. They are the last teeth to come through, usually between the late "
        "teens and the mid twenties, and sometimes there is not enough room for them to come through properly.",
        ("third molars", "wisdom tooth", "wisdom teeth"),
    ),
    Term(
        "impacted",
        "Impacted means a tooth is stuck under the gum or against another tooth and cannot come through normally.",
        "An impacted tooth is one that cannot fully come through the gum into its normal position, often because it is "
        "blocked by another tooth or by bone. The word describes the tooth's position; it does not by itself say whether "
        "treatment is needed. That decision is made by your dentist.",
        ("impaction", "impacted tooth"),
    ),
    Term(
        "horizontally impacted",
        "Horizontally impacted means the tooth is lying on its side under the gum.",
        "A horizontally impacted tooth is lying sideways in the jaw, usually pointing toward the tooth in front of it, "
        "instead of pointing upward or downward.",
        (),
    ),
    Term(
        "gingival inflammation",
        "Gingival inflammation means the gums are red or swollen.",
        "Gingival inflammation is irritation and swelling of the gums. It is commonly linked to plaque building up along "
        "the gum line, and it is often mild and reversible with good cleaning and a dental review.",
        ("gingivitis", "gum inflammation", "inflamed gums", "gingival"),
    ),
    Term(
        "gingiva",
        "The gingiva is the gum, the pink tissue around the base of your teeth.",
        "The gingiva is the medical word for the gums, the soft pink tissue that surrounds the necks of the teeth.",
        ("gums", "gum"),
    ),
    Term(
        "opg",
        "An OPG is a single wide X-ray picture that shows all your teeth and both jaws together.",
        "OPG stands for orthopantomogram, also called a panoramic X-ray. One image shows all the upper and lower teeth, "
        "the jaw bones and the jaw joints. It is useful for an overview, such as checking wisdom teeth, but it does not "
        "show fine detail the way a close-up X-ray does.",
        ("orthopantomogram", "panoramic x-ray", "panoramic xray", "panoramic radiograph"),
    ),
    Term(
        "dental examination",
        "A dental examination is a check-up where the dentist looks at your teeth, gums and mouth.",
        "A dental examination is a routine check in which the dentist looks at the teeth, gums, tongue and surrounding "
        "tissues and records anything of note.",
        ("dental exam", "check-up", "checkup", "oral examination"),
    ),
    Term(
        "radiograph",
        "A radiograph is an X-ray picture.",
        "A dental radiograph is an X-ray image used to see things that cannot be seen by looking in the mouth, such as "
        "the roots of the teeth and the bone around them.",
        ("radiographic", "x-ray", "xray", "x ray"),
    ),
    Term(
        "caries",
        "Caries is the medical word for tooth decay, also called a cavity.",
        "Caries, or tooth decay, happens when acids made by bacteria slowly dissolve the hard outer layer of a tooth. "
        "Early decay can sometimes be managed with fluoride and good cleaning; deeper decay usually needs a filling.",
        ("cavity", "cavities", "tooth decay", "decay", "carious"),
    ),
    Term(
        "plaque",
        "Plaque is the soft, sticky film of bacteria that builds up on teeth.",
        "Plaque is a soft film of bacteria that forms on teeth every day. Brushing and cleaning between the teeth removes "
        "it; if it is left, it can harden and irritate the gums.",
        (),
    ),
    Term(
        "calculus",
        "Calculus, also called tartar, is hardened plaque stuck to the teeth.",
        "Calculus, or tartar, is plaque that has hardened. It cannot be brushed off and is removed during a professional "
        "dental cleaning.",
        ("tartar",),
    ),
    Term(
        "enamel",
        "Enamel is the hard white outer layer of a tooth.",
        "Enamel is the hard, protective outer coating of the crown of a tooth. It is the hardest tissue in the body but "
        "can still be worn down or dissolved by acid.",
        (),
    ),
    Term(
        "crown",
        "The crown is the part of the tooth you can see above the gum. A dental crown is also a cap placed over a tooth.",
        "In anatomy the crown is the visible part of a tooth above the gum line. A dental crown is also a tooth-shaped "
        "cap a dentist can place over a damaged tooth.",
        ("crowns",),
    ),
    Term(
        "root",
        "The root is the part of the tooth under the gum that holds it in the jaw.",
        "The root is the part of a tooth that sits in the jawbone, anchoring the tooth. Front teeth usually have one root; "
        "molars often have two or three.",
        ("roots",),
    ),
    Term(
        "incisor",
        "Incisors are the flat front teeth used for cutting food.",
        "Incisors are the eight front teeth, four on top and four on the bottom, used for biting and cutting food.",
        ("incisors",),
    ),
    Term(
        "canine",
        "Canines are the pointed teeth next to the front teeth, used for tearing food.",
        "Canines, sometimes called eye teeth, are the pointed teeth beside the incisors. They help tear food.",
        ("canines", "cuspid", "eye tooth"),
    ),
    Term(
        "premolar",
        "Premolars are the teeth between the canines and molars, used for crushing and grinding.",
        "Premolars sit between the canines and the molars. Adults usually have eight. They crush and grind food.",
        ("premolars", "bicuspid", "bicuspids"),
    ),
    Term(
        "periodontal",
        "Periodontal means to do with the gums and the bone that hold your teeth in place.",
        "Periodontal refers to the tissues that support the teeth: the gums, the ligament around the root and the jawbone.",
        ("periodontium", "periodontitis", "gum disease"),
    ),
    Term(
        "abscess",
        "A dental abscess is a pocket of infection, usually with pain and swelling.",
        "A dental abscess is a collection of pus caused by infection, around a tooth root or in the gum. It normally "
        "needs prompt assessment by a dentist.",
        ("abscesses",),
    ),
    Term(
        "extraction",
        "An extraction is when a tooth is taken out.",
        "A dental extraction is the removal of a tooth. Whether it is needed is a clinical decision made by your dentist.",
        ("extractions", "tooth extraction"),
    ),
    Term(
        "root canal",
        "A root canal is a treatment that cleans out the inside of an infected or damaged tooth.",
        "Root canal treatment removes the damaged or infected nerve tissue from inside a tooth, cleans the space, and seals it.",
        ("endodontic",),
    ),
    Term(
        "filling",
        "A filling is a material the dentist uses to repair a tooth with a cavity.",
        "A dental filling restores a tooth after decay has been removed, using a tooth-coloured or metal material.",
        ("fillings", "restoration"),
    ),
    Term(
        "mandible",
        "The mandible is your lower jaw bone.",
        "The mandible is the lower jaw, the only movable bone of the skull.",
        ("lower jaw",),
    ),
    Term(
        "maxilla",
        "The maxilla is your upper jaw bone.",
        "The maxilla is the upper jaw bone, which holds the upper teeth and forms part of the roof of the mouth.",
        ("upper jaw",),
    ),
    Term(
        "bone loss",
        "Bone loss means the jaw bone around the teeth has become thinner or lower.",
        "Bone loss around the teeth usually relates to gum disease, and it is judged from X-rays and measurements by the dentist.",
        (),
    ),
    Term(
        "clinician review",
        "Clinician review means a qualified dentist must check the report before anyone relies on it.",
        "Clinician review means a qualified clinician has to read and confirm the report. Automated tools and demo data "
        "are never a substitute for that.",
        ("clinician review required",),
    ),
]

TERMS = {t.key: t for t in _TERMS}

_NORMALIZE = re.compile(r"[^a-z0-9\s-]")


def _norm(text: str) -> str:
    return " ".join(_NORMALIZE.sub(" ", (text or "").lower()).split())


# surface form -> term key; longest forms are matched first so "third molar" wins over "molar".
_SURFACE: dict[str, str] = {}
for _t in _TERMS:
    _SURFACE[_norm(_t.key)] = _t.key
    for _alias in _t.aliases:
        _SURFACE[_norm(_alias)] = _t.key
_SURFACE_ORDER = sorted(_SURFACE, key=len, reverse=True)


def find_terms(text: str, limit: int = 4) -> list[Term]:
    """Glossary terms mentioned in `text`, longest match first, in order of appearance, without overlaps."""
    haystack = f" {_norm(text)} "
    taken: list[tuple[int, int, str]] = []
    for surface in _SURFACE_ORDER:
        for m in re.finditer(rf"(?<![a-z]){re.escape(surface)}(?![a-z])", haystack):
            span = (m.start(), m.end())
            if any(not (span[1] <= a or span[0] >= b) for a, b, _ in taken):
                continue
            taken.append((span[0], span[1], _SURFACE[surface]))
    taken.sort()
    seen: list[str] = []
    for _, _, key in taken:
        if key not in seen:
            seen.append(key)
    return [TERMS[k] for k in seen[:limit]]


def lookup(text: str) -> Term | None:
    """Best single glossary match for a question such as 'What are molar teeth?'."""
    found = find_terms(text, limit=1)
    return found[0] if found else None
