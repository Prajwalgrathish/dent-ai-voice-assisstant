"""Turn a patient's free-text question into a *proposed* interpretation.

Two interchangeable interpreters, both untrusted until `policy.validate_interpretation` accepts them:

  * `rule_interpret`  - deterministic keyword/regex parsing. Fast, free, works offline.
  * `llm_interpret`   - asks the configured LLM for a strict JSON object (intent, report_ref, term...).

Default strategy ("rules_first"): rules handle the common questions; the LLM is only consulted when the
rules cannot tell what the patient wants. The LLM never sees other patients' data: its prompt contains the
patient's question, a few allowed labels and the *types/dates* of the patient's own reports.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Optional, Sequence

from ..dictation import parse_llm_json
from .glossary import find_terms
from .policy import INTENTS, REPORT_REFS

log = logging.getLogger(__name__)

_SIMPLE = re.compile(
    r"\bsimpl(?:e|er|y|ify|ified)\b|\bplain(?:er)? (?:english|words|language|terms)\b|\beasy(?:\s|-)?(?:english|words|to understand)\b|"
    r"\blayman\b|\blay terms\b|\bexplain (?:it |this |that )?like\b|\beli5\b|\bnon[- ]?technical\b|\bdon'?t understand\b|\bdo not understand\b|"
    r"\bconfus\w+\b|\bdumb(?:ed)? it down\b|\bsimple english\b|\bsimpl\w+ (?:terms|way|words)\b",
    re.IGNORECASE,
)
_DETAIL = re.compile(r"\belaborat\w*|\bin (?:more )?detail\b|\bdetailed\b|\bexpand on\b|\bgo deeper\b|\bfull explanation\b", re.IGNORECASE)
_EXPLAIN = re.compile(
    r"\bexplain\b|\bsummari[sz]\w*\b|\bwalk me through\b|\bgo (?:over|through)\b|\btell me about\b|\bwhat(?:'s| is| does)\b[^?]*\bmy (?:report|results?|x-?ray|opg|examination|check-?up)\b|"
    r"\bwhat(?:'s| is) in my\b|\bread (?:out |me )?my\b|\bwhat did (?:it|the report|they|the dentist) (?:say|find|show)\b|\bmy (?:report|results?)\b|\boverview\b|\bsummary\b",
    re.IGNORECASE,
)
_DESCRIBE = re.compile(r"\bdescribe\b|\bwhat (?:are|were) my findings\b|\bmy findings\b|\blist (?:my )?findings\b|\bwhat (?:did|do) (?:they|you|the dentist|the report) (?:find|found)\b|\bfindings\b", re.IGNORECASE)
_THIS_FINDING = re.compile(r"\b(?:this|that|these|those|each|every|which|the) (?:finding|findings|result|results|observation|observations|note|notes|line|one)\b|\bwhat does (?:this|that|it) mean\b|\bwhat do (?:these|those) mean\b|\bmeaning of (?:this|that|it)\b|\bwhat(?:'s| is) (?:this|that)\b", re.IGNORECASE)
_WHAT_IS = re.compile(r"\bwhat(?:'s|\s+is|\s+are|\s+does|\s+do)\b\s*(?:an?\s+|the\s+)?(.{2,60}?)(?:\s+(?:mean|means|stand for|refer to))?\s*[?.!]*$|\bdefine\s+(.{2,60}?)\s*[?.!]*$|\bmeaning of\s+(.{2,60}?)\s*[?.!]*$|\btell me (?:about|what)\s+(.{2,60}?)\s*[?.!]*$", re.IGNORECASE)
_LIST = re.compile(r"\b(?:which|what|list|show)\b[^?.!]*\b(?:reports?|records?|x-?rays?)\b[^?.!]*\b(?:do i have|i have|on file|available|are there|exist)\b|\b(?:list|show) (?:me )?(?:all )?my (?:reports?|records?)\b|\bhow many reports\b", re.IGNORECASE)
_FOLLOW = re.compile(r"^\s*(?:and\s+)?(?:why|how come|what else|tell me more|more|go on|continue|anything else|and then|so what|what about (?:that|it|this)|elaborate)\s*[?.!]*\s*$|\bmore (?:about|on) (?:that|this|it)\b|\btell me more\b", re.IGNORECASE)
_SMALLTALK = re.compile(r"^\s*(?:hi|hello|hey|good (?:morning|afternoon|evening)|thanks?|thank you|ok(?:ay)?|bye|goodbye|great|cool|got it|alright)\b[\s,!.]*(?:there|assistant)?[\s!.]*$", re.IGNORECASE)
_OPG = re.compile(r"\bopg\b|\bpanoramic\b|\bx-?ray\b|\borthopantomogram\b", re.IGNORECASE)
_EXAM = re.compile(r"\bdental (?:exam|examination)\b|\bexam(?:ination)?\b|\bcheck-?up\b", re.IGNORECASE)
_RELATIVE_REF = [
    ("previous", re.compile(r"\b(?:previous|earlier|older|prior|first|other|last)\s+(?:one|report)\b|\bthe other (?:one|report)\b|\bprevious\b|\bolder\b", re.IGNORECASE)),
    ("latest", re.compile(r"\b(?:latest|newest|most recent|recent|current|new)\b", re.IGNORECASE)),
]
_REPORT_ID = re.compile(r"\bR\d{1,8}\b", re.IGNORECASE)


def _ref(message: str) -> Optional[str]:
    rid = _REPORT_ID.search(message)
    if rid:
        return rid.group(0).upper()
    if _OPG.search(message):
        return "opg"
    if re.search(r"\bdental (?:exam|examination)\b|\bexamination report\b|\bcheck-?up\b", message, re.IGNORECASE):
        return "dental_examination"
    for ref, rx in _RELATIVE_REF:
        if rx.search(message):
            return ref
    return None


def rule_interpret(message: str, *, has_context: bool) -> dict:
    """Deterministic interpretation. Returns an untrusted proposal dict."""
    text = " ".join((message or "").split())
    base = {"source": "rules", "confidence": 0.9}
    simplify = bool(_SIMPLE.search(text))
    detail = bool(_DETAIL.search(text))
    ref = _ref(text)
    terms = find_terms(text, limit=1)

    if _SMALLTALK.match(text):
        return {**base, "intent": "smalltalk"}
    if _LIST.search(text):
        return {**base, "intent": "list_reports"}
    # Explicit request to simplify something (usually the previous answer).
    if simplify:
        if _THIS_FINDING.search(text) and re.search(r"\bfinding|\bresult|\bobservation", text, re.I):
            return {**base, "intent": "explain_finding", "report_ref": ref, "simplify": True}
        return {**base, "intent": "simplify", "report_ref": ref, "simplify": True, "detail": False}
    if _FOLLOW.search(text):
        return {**base, "intent": "follow_up", "detail": True}
    if _DESCRIBE.search(text) and not _THIS_FINDING.search(text):
        return {**base, "intent": "describe_findings", "report_ref": ref, "detail": detail}
    # "What does this finding mean?" - about the patient's own findings, not a glossary lookup.
    if _THIS_FINDING.search(text):
        return {**base, "intent": "explain_finding", "report_ref": ref}
    m = _WHAT_IS.search(text)
    if m:
        candidate = next((g for g in m.groups() if g), "").strip(" ?.!")
        # "what is my report" / "what are my findings" belong to the report intents, not the glossary.
        if not re.search(r"\b(?:my|our)\b|\breports?\b|\bfindings?\b|\bresults?\b", candidate, re.IGNORECASE):
            cleaned = re.sub(r"^(?:an?|the)\s+", "", candidate, flags=re.IGNORECASE)
            if terms:
                return {**base, "intent": "define_term", "term": terms[0].key}
            if cleaned and len(cleaned.split()) <= 5:
                return {**base, "intent": "define_term", "term": cleaned, "confidence": 0.6}
    if _DESCRIBE.search(text) and (re.search(r"\bfindings?\b", text, re.I) or re.search(r"\bdescribe\b", text, re.I)):
        return {**base, "intent": "describe_findings", "report_ref": ref, "detail": detail}
    about_me = re.search(r"\bmy\b|\breports?\b|\bresults?\b|\bfindings?\b|\bx-?rays?\b", text, re.I)
    if terms and _EXPLAIN.search(text) and not about_me:
        return {**base, "intent": "define_term", "term": terms[0].key}
    if _EXPLAIN.search(text) or detail or (ref and about_me):
        return {**base, "intent": "explain_report", "report_ref": ref, "detail": detail}
    if terms:
        return {**base, "intent": "define_term", "term": terms[0].key, "confidence": 0.7}
    return {"source": "rules", "confidence": 0.0, "intent": "unknown"}


# ───────────────────────────── LLM interpretation ─────────────────────────────
INTERPRET_SYSTEM_PROMPT = (
    "You classify a dental patient's question for a software router. You do NOT answer it. "
    "Reply with ONE JSON object and nothing else, using exactly these keys:\n"
    '{"intent": one of ' + json.dumps(list(INTENTS)) + ', "report_ref": one of ' + json.dumps(list(REPORT_REFS)) +
    ' or null, "term": a dental term the patient asks about or null, "simplify": true|false}\n'
    "Meanings: explain_report = explain/summarise my report; describe_findings = list what the report found; "
    "explain_finding = what does this finding mean; define_term = general meaning of a dental word; "
    "simplify = say the previous answer in simpler English; follow_up = tell me more; list_reports = which reports do I have; "
    "smalltalk = greeting/thanks; out_of_scope = unrelated to dental reports or terms. "
    "Never include patient names, IDs or any other keys. If unsure, use \"unknown\"."
)


def build_interpret_messages(message: str, own_report_types: Sequence[str], last_intent: Optional[str]) -> list[dict]:
    context = {"my_report_types": sorted(set(own_report_types)), "previous_intent": last_intent}
    return [
        {"role": "system", "content": INTERPRET_SYSTEM_PROMPT},
        {"role": "user", "content": f"Context: {json.dumps(context)}\nQuestion: {message[:600]}"},
    ]


def llm_interpret(llm, message: str, own_report_types: Sequence[str], last_intent: Optional[str]) -> Optional[dict]:
    """Ask the LLM; returns an untrusted proposal or None on any failure (caller falls back safely)."""
    try:
        raw = llm.complete(build_interpret_messages(message, own_report_types, last_intent))
    except Exception as exc:  # noqa: BLE001 - provider errors must never break the patient's turn
        log.warning("patient interpreter LLM failed: %s", type(exc).__name__)
        return None
    obj, err = parse_llm_json(raw)
    if err or not isinstance(obj, dict):
        return None
    obj = dict(obj)
    obj["source"] = "llm"
    return obj
