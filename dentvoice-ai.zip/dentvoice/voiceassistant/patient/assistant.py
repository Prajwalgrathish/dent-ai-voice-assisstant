"""Patient Voice Assistant orchestration.

Pipeline for every question (each arrow is a separate, individually testable step):

  message -> [input validation] -> [policy.check_safety: deterministic refusals]
          -> [interpreter: rules, or LLM when rules cannot tell] -> [policy.validate_interpretation]
          -> [tools: patient-scoped report/glossary lookups] -> [compose: documented text from the report
          verbatim + general explanation from glossary or LLM] -> [guardrails on any LLM text] -> answer

The LLM only ever (a) proposes an interpretation and (b) paraphrases facts that code already retrieved.
It cannot choose the patient, cannot read data except what the tools hand it, and its text is discarded
if it fails the guardrails.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Optional

from ..dental.service import load_patients
from ..explain import Explanation, explain_findings
from .glossary import Term, find_terms, lookup
from .guardrails import check_llm_text
from .interpreter import llm_interpret, rule_interpret
from .policy import ValidatedIntent, check_safety, validate_interpretation
from .sessions import PatientSession
from .tools import PatientTools, ToolError, plain_finding

log = logging.getLogger("dentvoice.patient")

MAX_QUESTION_CHARS = 1000
NOTICE = "Demonstration data only. A dentist must review any clinical report; this assistant gives general information, not medical advice."
CLOSING = "This is general information to help you understand your report, not a diagnosis. Your dentist can tell you what it means for you."

PATIENT_SYSTEM_PROMPT = (
    "You help a dental patient understand their OWN report in plain English. Your reply is read aloud, so write 3 to 5 short, "
    "natural sentences with no markdown, lists or emojis. Rules you must follow: "
    "(1) Use ONLY the report text and glossary notes you are given. Never add findings, tooth numbers, dates, causes or diagnoses. "
    "(2) The report text is shown to the patient separately, so do NOT repeat, quote or paraphrase what the report says and never write "
    "'your report says'. Write only the general background meaning of the terms, beginning with 'In general,'. "
    "(3) Never say the patient 'has' a condition, never recommend treatment or medicine, never predict outcomes, and never reassure "
    "or alarm. (4) If the report does not give enough detail, say so plainly. (5) End by saying the dentist can explain what it "
    "means for them. (6) Never mention any other patient."
)
TERM_SYSTEM_PROMPT = (
    "You give a short, general, plain-English definition of a dental or oral-health term for a patient. Your reply is read aloud: "
    "1 to 3 short sentences, no markdown. This is general information, not about any particular person: never say 'you have', never "
    "diagnose, recommend treatment, or predict outcomes. If the term is not a dental or oral-health term, reply with exactly: NOT_DENTAL"
)


class PatientInputError(Exception):
    status = 422

    def __init__(self, user_message: str):
        super().__init__(user_message)
        self.user_message = user_message


@dataclass
class PatientAnswer:
    answer: str
    intent: str
    grounding: str  # report | general | mixed | refusal | none
    sections: list = field(default_factory=list)
    evidence: list = field(default_factory=list)
    general_info: list = field(default_factory=list)
    report_used: Optional[dict] = None
    refusal: Optional[dict] = None
    interpretation: dict = field(default_factory=dict)
    guardrail: dict = field(default_factory=dict)
    timings_ms: dict = field(default_factory=dict)
    notices: list = field(default_factory=lambda: [NOTICE])
    synthetic_data: bool = True


def spoken_date(iso: str) -> str:
    try:
        d = datetime.strptime(iso, "%Y-%m-%d")
        return f"{d.day} {d:%B %Y}"
    except (ValueError, TypeError):
        return iso or "an unknown date"


def first_sentences(text: str, n: int = 1) -> str:
    parts = [p.strip() for p in text.replace("! ", ". ").replace("? ", ". ").split(". ") if p.strip()]
    out = ". ".join(parts[:n]).rstrip(".")
    return out + "."


def _join_findings(items: list[str]) -> str:
    items = [i.rstrip(". ") for i in items if i]
    if not items:
        return ""
    return "; ".join(items) + "."


class PatientAssistant:
    def __init__(
        self,
        llm=None,
        loader: Callable[[], list[dict]] = load_patients,
        interpreter_mode: str = "rules_first",  # rules_first | llm_first | rules_only
        llm_explanations: bool = True,
        clock: Callable[[], float] = time.perf_counter,
    ):
        if interpreter_mode not in ("rules_first", "llm_first", "rules_only"):
            raise ValueError("interpreter_mode must be rules_first, llm_first or rules_only")
        self.llm, self.loader, self.mode = llm, loader, interpreter_mode
        self.llm_explanations, self._clock = llm_explanations, clock

    # ───────────────────────────── public entry point ─────────────────────────────
    def answer(self, session: PatientSession, message: str) -> PatientAnswer:
        t0 = self._clock()
        text = self._validate_input(message)
        ctx = session.context
        tools = PatientTools(session.patient_id, self.loader)
        all_patients = self.loader()
        own_name = next((str(p.get("name", "")) for p in all_patients if str(p.get("patient_id")) == session.patient_id), "")
        timings: dict[str, float] = {}

        # 1. deterministic safety policy (never delegated to the LLM)
        verdict = check_safety(text, own_patient_id=session.patient_id, own_name=own_name, all_patients=all_patients)
        timings["safety"] = self._ms(t0)
        if verdict is not None:
            result = self._refusal(verdict, text, tools, ctx)
            return self._finish(session, text, result, timings, t0, interp={"intent": "refused", "source": "policy"})

        # 2. interpretation (rules, or LLM) -> 3. validation against THIS patient's data
        t1 = self._clock()
        own_reports = tools.list_my_reports()
        proposal = self._propose(text, own_reports, ctx)
        validated = validate_interpretation(proposal, own_report_ids=[r["report_id"] for r in own_reports])
        timings["interpret"] = self._ms(t1)
        interp = {"intent": validated.intent, "source": validated.source, "report_ref": validated.report_ref, "dropped": validated.dropped}

        # 4. tools + compose
        t2 = self._clock()
        try:
            result, gen_ms = self._dispatch(validated, text, session, tools, own_reports, all_patients, own_name)
        except ToolError as exc:
            result = PatientAnswer(
                answer=exc.user_message, intent=validated.intent, grounding="none",
                sections=[{"kind": "note", "text": exc.user_message}],
            )
            gen_ms = 0.0
        timings["tools_and_compose"] = self._ms(t2)
        timings["llm_generate"] = gen_ms
        return self._finish(session, text, result, timings, t0, interp=interp)

    # ───────────────────────────── steps ─────────────────────────────
    def _validate_input(self, message: object) -> str:
        if not isinstance(message, str):
            raise PatientInputError("Please type or say a question.")
        text = " ".join(message.split())
        if not text:
            raise PatientInputError("Please type or say a question.")
        if len(text) > MAX_QUESTION_CHARS:
            raise PatientInputError(f"That question is too long (limit {MAX_QUESTION_CHARS} characters). Please shorten it.")
        return text

    def _propose(self, text: str, own_reports: list[dict], ctx) -> dict:
        last = (ctx.last_request or {}).get("intent")
        types = [r["type"] for r in own_reports]
        if self.mode == "llm_first" and self.llm is not None:
            proposal = llm_interpret(self.llm, text, types, last)
            if proposal is not None:
                return proposal
            return rule_interpret(text, has_context=ctx.last_request is not None)
        proposal = rule_interpret(text, has_context=ctx.last_request is not None)
        if proposal.get("intent") == "unknown" and self.mode == "rules_first" and self.llm is not None:
            from_llm = llm_interpret(self.llm, text, types, last)
            if from_llm is not None:
                return from_llm
        return proposal

    def _resolve_report(self, tools: PatientTools, ref: Optional[str], ctx) -> tuple[dict, bool]:
        """-> (report, defaulted). `defaulted` means the patient did not name it, so we say which one we used."""
        reports = tools.list_my_reports()
        if ref and ref.upper().startswith("R") and ref.upper() not in ("RECENT",):
            return tools.get_my_report(report_id=ref), False
        if ref == "opg":
            return tools.get_my_report(report_type="OPG"), False
        if ref == "dental_examination":
            return tools.get_my_report(report_type="Dental Examination"), False
        if ref == "latest":
            return tools.get_my_report(), False
        if ref == "previous":
            active = ctx.active_report_id
            ids = [r["report_id"] for r in reports]  # newest first
            if active in ids and ids.index(active) + 1 < len(ids):
                return tools.get_my_report(report_id=ids[ids.index(active) + 1]), False
            if active is None and len(ids) > 1:
                return tools.get_my_report(report_id=ids[1]), False
            raise ToolError("I don't see an earlier report than that one on your record.", "no_previous")
        if ctx.active_report_id:
            try:
                return tools.get_my_report(report_id=ctx.active_report_id), False
            except ToolError:
                pass
        return tools.get_my_report(), True

    # ───────────────────────────── composition ─────────────────────────────
    def _dispatch(self, v: ValidatedIntent, text, session, tools, own_reports, all_patients, own_name):
        ctx = session.context
        intent, simplify, detail, term, ref, focus = v.intent, v.simplify, v.detail, v.term, v.report_ref, None

        if intent == "smalltalk":
            first = tools.patient_first_name()
            msg = (f"Hello {first}. I can explain your dental reports in plain English, describe your findings, "
                   "and explain dental words such as molar or impacted. What would you like to know?")
            lowered = text.lower()
            if any(w in lowered for w in ("thank", "bye", "great", "cool", "got it")):
                msg = "You're welcome. Ask me anything else about your reports or dental terms whenever you like."
            return PatientAnswer(msg, intent, "none", [{"kind": "note", "text": msg}]), 0.0

        if intent == "list_reports":
            if not own_reports:
                return PatientAnswer("You do not have any reports on file yet.", intent, "none",
                                     [{"kind": "note", "text": "You do not have any reports on file yet."}]), 0.0
            listing = "; ".join(f"{r['type']} from {spoken_date(r['date'])}" for r in own_reports)
            msg = f"You have {len(own_reports)} report{'s' if len(own_reports) != 1 else ''} on file: {listing}."
            return PatientAnswer(msg, intent, "report", [{"kind": "documented", "text": msg}],
                                 evidence=[{"report_id": r["report_id"], "type": r["type"], "date": r["date"], "quotes": []} for r in own_reports]), 0.0

        reuse = False
        if intent in ("simplify", "follow_up"):
            reuse = True
            last = ctx.last_request
            if last is None:
                if intent == "follow_up":
                    msg = "What would you like to know? I can explain your report, describe your findings, or explain a dental word."
                    return PatientAnswer(msg, intent, "none", [{"kind": "note", "text": msg}]), 0.0
                intent, simplify = "explain_report", True
            else:
                simplify = simplify or v.simplify
                detail = detail or (v.intent == "follow_up")
                intent, term, focus = last["intent"], last.get("term"), last.get("focus")
                ref = ref or last.get("report_id")

        if intent == "define_term":
            return self._define(term or text, text, session, tools, simplify, all_patients, own_name, own_reports)

        if intent in ("explain_report", "describe_findings", "explain_finding", "unknown", "out_of_scope"):
            if intent in ("unknown", "out_of_scope"):
                msg = ("I can help with your own dental reports and with dental words. For example, ask me to explain your report, "
                       "describe your findings, or tell you what a molar is.")
                return PatientAnswer(msg, "out_of_scope", "none", [{"kind": "note", "text": msg}]), 0.0
            return self._report_answer(intent, simplify, detail, ref, focus, text, session, tools, own_reports, all_patients, own_name, reuse)

        msg = "Sorry, I couldn't work out what you meant. You can ask me to explain your report or a dental term."
        return PatientAnswer(msg, "unknown", "none", [{"kind": "note", "text": msg}]), 0.0

    def _evidence(self, report: dict, quotes: Optional[list[str]] = None) -> dict:
        all_quotes = list(report["findings"]) + ([f"Impression: {report['impression']}"] if report.get("impression") else [])
        return {"report_id": report["report_id"], "type": report["type"], "date": report["date"],
                "quotes": quotes if quotes is not None else all_quotes}

    def _report_answer(self, intent, simplify, detail, ref, focus, text, session, tools, own_reports, all_patients, own_name, reuse=False):
        ctx = session.context
        report, defaulted = self._resolve_report(tools, ref, ctx)
        findings = report["findings"]
        plain = [plain_finding(f) for f in findings]

        if intent == "explain_finding":
            mentioned = [i for i, f in enumerate(plain) if any(t.key in {x.key for x in find_terms(f)} for t in find_terms(text))]
            focus = mentioned or focus
        chosen_idx = [i for i in (focus or range(len(plain))) if 0 <= i < len(plain)]
        chosen_plain = [plain[i] for i in chosen_idx]

        sections: list[dict] = []
        intro = f"I'm using your {report['type']} report from {spoken_date(report['date'])}."
        others = [r for r in own_reports if r["report_id"] != report["report_id"]]
        if defaulted and others:
            alt = others[0]
            intro += (f" It's your most recent report. You also have {'an' if alt['type'][0] in 'AEIOU' else 'a'} {alt['type']} from "
                      f"{spoken_date(alt['date'])}; just ask about it by name to switch.")
        if not reuse:  # a follow-up on the same report does not repeat the introduction
            sections.append({"kind": "context", "text": intro})

        if chosen_plain:
            doc = "From your report: " + _join_findings(chosen_plain)
        else:
            doc = "From your report: it does not list any specific findings."
        sections.append({"kind": "documented", "text": doc})
        if report.get("impression") and intent != "explain_finding" and not reuse:
            sections.append({"kind": "documented", "text": "The report's impression reads: " + _join_findings([report["impression"]])})

        terms: list[Term] = []
        for f in chosen_plain:  # terms come from the findings only, never from boilerplate in the impression
            for t in find_terms(f):
                if t.key not in {x.key for x in terms}:
                    terms.append(t)
        terms = terms[:5]

        # What the report says, in everyday words (rewritten from the finding itself; nothing added).
        exp = explain_findings([report["findings"][i] for i in chosen_idx], impression=report.get("impression"))
        sections.append({"kind": "plain", "text": "In plain English: " + exp.plain})

        gen_ms = 0.0
        guard = {"llm_used": False, "llm_text_accepted": None, "reasons": []}
        general_text = None
        if self.llm is not None and self.llm_explanations and chosen_plain and terms:
            general_text, guard, gen_ms = self._llm_explain(
                text, report, chosen_plain, terms, simplify, detail, session, all_patients, own_name, own_reports
            )
        if general_text is None:
            general_text = self._deterministic_explanation(chosen_plain, terms, simplify, detail, exp)
        sections.append({"kind": "general", "text": general_text})
        sections.append({"kind": "uncertain", "text": exp.uncertain})   # what the report does NOT establish
        sections.append({"kind": "note", "text": CLOSING})

        ctx.active_report_id = report["report_id"]
        ctx.last_request = {"intent": intent, "report_id": report["report_id"], "term": None, "focus": chosen_idx if intent == "explain_finding" else None}
        result = PatientAnswer(
            answer="\n\n".join(s["text"] for s in sections),
            intent=intent,
            grounding="mixed",
            sections=sections,
            evidence=[self._evidence(report, [report["findings"][i] for i in chosen_idx] + ([f"Impression: {report['impression']}"] if report.get("impression") and intent != "explain_finding" else []))],
            general_info=[{"term": t.key, "definition": t.simple if simplify else t.general} for t in terms],
            report_used={"report_id": report["report_id"], "type": report["type"], "date": report["date"]},
            guardrail=guard,
        )
        return result, gen_ms

    def _deterministic_explanation(self, plain: list[str], terms: list[Term], simplify: bool, detail: bool,
                                   exp: Optional[Explanation] = None) -> str:
        """General (not patient-specific) background: what the wording means and why it MAY matter, hedged."""
        recognised = bool(exp and exp.recognised)
        if not terms and not recognised:
            return ("In general: the report describes this in everyday words and doesn't give extra detail. "
                    "If you'd like to know more about it, your dentist is the best person to ask.")
        if simplify:
            defs = [t.simple for t in terms]
        elif detail:
            defs = [t.general for t in terms]
        else:
            defs = [first_sentences(t.general, 1) for t in terms]
        extra: list[str] = []
        if recognised:
            if not simplify:
                extra.append(exp.means)
            extra.append(first_sentences(exp.matters, 1) if simplify else exp.matters)
        return "In general: " + " ".join(defs + extra)

    def _llm_explain(self, question, report, plain, terms, simplify, detail, session, all_patients, own_name, own_reports):
        ctx = session.context
        glossary = "\n".join(f"- {t.key}: {t.simple if simplify else t.general}" for t in terms)
        report_block = (
            f"Report type: {report['type']}\nReport date: {spoken_date(report['date'])}\nFindings (verbatim):\n"
            + "\n".join(f"- {f}" for f in plain)
            + (f"\nImpression (verbatim): {report['impression']}" if report.get("impression") else "")
        )
        mode = ("Use very simple words and very short sentences, as if for a 12 year old." if simplify
                else ("Give a little more detail." if detail else "Keep it short."))
        history = list(ctx.history)[-4:]
        messages = [{"role": "system", "content": PATIENT_SYSTEM_PROMPT}]
        for role, content in history:
            messages.append({"role": role, "content": content})
        messages.append({"role": "user", "content": f"{report_block}\n\nGlossary notes (general information):\n{glossary}\n\n{mode}\nPatient question: {question}"})
        t = self._clock()
        guard = {"llm_used": True, "llm_text_accepted": False, "reasons": []}
        try:
            raw = self.llm.complete(messages)
        except Exception as exc:  # noqa: BLE001 - never surface provider detail to the patient
            log.warning("patient explain LLM failed: %s", type(exc).__name__)
            guard["reasons"] = ["llm_unavailable"]
            return None, guard, self._ms(t)
        gen_ms = self._ms(t)
        verdict = check_llm_text(
            raw, evidence_text=" ".join(plain) + " " + (report.get("impression") or ""), question=question,
            own_patient_id=session.patient_id, own_name=own_name, own_report_ids=[r["report_id"] for r in own_reports],
            all_patients=all_patients, extra_allowed_text=glossary,
        )
        if not verdict.ok:
            guard["reasons"] = verdict.reasons
            return None, guard, gen_ms
        guard["llm_text_accepted"] = True
        body = re.sub(r"^\s*in general\s*[:,]\s*", "", verdict.text, flags=re.IGNORECASE)
        return "In general: " + (body[:1].upper() + body[1:] if body else body), guard, gen_ms

    def _define(self, term_text, question, session, tools, simplify, all_patients, own_name, own_reports):
        ctx = session.context
        entry = tools.define_dental_term(term_text) or lookup(question)
        sections: list[dict] = []
        gen_ms, guard, evidence, report_used = 0.0, {}, [], None
        general_info = []
        if entry is not None:
            definition = entry.simple if simplify else entry.general
            sections.append({"kind": "general", "text": f"In general (not from your report): {definition}"})
            general_info.append({"term": entry.key, "definition": definition})
            # If one of the patient's OWN reports mentions this term, say so (documented) without adding meaning to it.
            # The active report is preferred; otherwise the newest report that mentions it.
            try:
                candidates = []
                if ctx.active_report_id:
                    candidates.append(ctx.active_report_id)
                candidates += [r["report_id"] for r in own_reports if r["report_id"] not in candidates]
                for rid in candidates:
                    report = tools.get_my_report(report_id=rid)
                    hits = [f for f in report["findings"] if entry.key in {t.key for t in find_terms(plain_finding(f))}]
                    if hits:
                        sections.append({"kind": "documented", "text": f"Your {report['type']} report from {spoken_date(report['date'])} mentions this: " + _join_findings([plain_finding(h) for h in hits])})
                        evidence = [self._evidence(report, hits)]
                        report_used = {"report_id": report["report_id"], "type": report["type"], "date": report["date"]}
                        ctx.active_report_id = report["report_id"]
                        break
            except ToolError:
                pass
            ctx.last_request = {"intent": "define_term", "report_id": None, "term": entry.key, "focus": None}
            grounding = "mixed" if evidence else "general"
        else:
            text_out, guard, gen_ms = self._llm_define(term_text, question, session, all_patients, own_name, own_reports)
            if text_out:
                sections.append({"kind": "general", "text": f"In general (not from your report): {text_out}"})
                ctx.last_request = {"intent": "define_term", "report_id": None, "term": term_text, "focus": None}
                grounding = "general"
            else:
                msg = ("I don't have a reliable definition for that word, so I'd rather not guess. "
                       "Your dentist can explain it, or you can ask me about your report or another dental term.")
                sections.append({"kind": "note", "text": msg})
                grounding = "none"
        sections.append({"kind": "note", "text": "This is general information, not medical advice."})
        return PatientAnswer(
            answer="\n\n".join(s["text"] for s in sections), intent="define_term", grounding=grounding,
            sections=sections, evidence=evidence, general_info=general_info, report_used=report_used, guardrail=guard,
        ), gen_ms

    def _llm_define(self, term_text, question, session, all_patients, own_name, own_reports):
        guard = {"llm_used": False, "llm_text_accepted": None, "reasons": []}
        if self.llm is None or not self.llm_explanations:
            return None, guard, 0.0
        guard["llm_used"] = True
        t = self._clock()
        try:
            raw = self.llm.complete([
                {"role": "system", "content": TERM_SYSTEM_PROMPT},
                {"role": "user", "content": f"Term: {term_text[:60]}"},
            ])
        except Exception as exc:  # noqa: BLE001
            log.warning("patient define LLM failed: %s", type(exc).__name__)
            guard["reasons"] = ["llm_unavailable"]
            return None, guard, self._ms(t)
        ms = self._ms(t)
        if "NOT_DENTAL" in (raw or ""):
            guard["reasons"] = ["not_dental"]
            return None, guard, ms
        verdict = check_llm_text(
            raw, evidence_text="", question=question, own_patient_id=session.patient_id, own_name=own_name,
            own_report_ids=[r["report_id"] for r in own_reports], all_patients=all_patients,
        )
        if not verdict.ok:
            guard["reasons"] = verdict.reasons
            return None, guard, ms
        guard["llm_text_accepted"] = True
        return verdict.text, guard, ms

    def _refusal(self, verdict, text, tools, ctx) -> PatientAnswer:
        sections = [{"kind": "refusal", "text": verdict.message}]
        evidence, report_used = [], None
        if verdict.uses_report:
            try:
                report, _ = self._resolve_report(tools, None, ctx)
                plain = [plain_finding(f) for f in report["findings"]]
                if plain:
                    sections.append({"kind": "documented", "text": f"For reference, your {report['type']} report from {spoken_date(report['date'])} says: " + _join_findings(plain)})
                    evidence = [self._evidence(report)]
                    report_used = {"report_id": report["report_id"], "type": report["type"], "date": report["date"]}
            except ToolError:
                pass
        general_info = []
        terms = find_terms(text, limit=2)
        if verdict.uses_report and terms:
            for t in terms:
                general_info.append({"term": t.key, "definition": t.simple})
            sections.append({"kind": "general", "text": "In general: " + " ".join(t.simple for t in terms)})
        return PatientAnswer(
            answer="\n\n".join(s["text"] for s in sections), intent="refused", grounding="refusal", sections=sections,
            evidence=evidence, general_info=general_info, report_used=report_used,
            refusal={"category": verdict.category},
        )

    # ───────────────────────────── bookkeeping ─────────────────────────────
    def _finish(self, session, text, result: PatientAnswer, timings, t0, interp) -> PatientAnswer:
        ctx = session.context
        ctx.remember("user", text)
        ctx.remember("assistant", result.answer)
        ctx.last_answer = result.answer
        timings["total"] = self._ms(t0)
        result.timings_ms = {k: round(v, 2) for k, v in timings.items()}
        result.interpretation = interp
        log.info(
            "patient_turn sid=%s intent=%s grounding=%s refusal=%s llm_used=%s accepted=%s total_ms=%.1f",
            session.tag, result.intent, result.grounding, (result.refusal or {}).get("category"),
            result.guardrail.get("llm_used"), result.guardrail.get("llm_text_accepted"), timings["total"],
        )
        return result

    def _ms(self, since: float) -> float:
        return (self._clock() - since) * 1000.0
