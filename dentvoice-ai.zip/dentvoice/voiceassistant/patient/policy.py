"""Deterministic business rules for the patient flow.

Everything here is plain code. The LLM can *propose* an interpretation, but this module decides:
  * whether the question is allowed at all (safety refusals are NOT delegated to the model),
  * whether a proposed intent / report reference / term is acceptable for THIS signed-in patient.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional, Sequence

from ..patient_resolver import extract_patient_id
from .glossary import _norm as _gnorm

INTENTS = (
    "explain_report",     # "Explain my report", "Elaborate on my report"
    "describe_findings",  # "Describe my findings"
    "explain_finding",    # "What does this finding mean?"
    "define_term",        # "What are molar teeth?"
    "simplify",           # "Can you explain this in simple English?"
    "follow_up",          # "Tell me more", "Why?"
    "list_reports",       # "Which reports do I have?"
    "smalltalk",          # greetings, thanks
    "out_of_scope",
    "unknown",
)
REPORT_REFS = ("latest", "previous", "opg", "dental_examination")
_TERM_RE = re.compile(r"^[A-Za-z][A-Za-z '\-]{1,59}$")


# ───────────────────────────── safety refusals ─────────────────────────────
@dataclass(frozen=True)
class SafetyVerdict:
    category: str  # other_patient | urgent_symptoms | diagnosis | treatment | prognosis
    message: str   # what the assistant says (safe to speak)
    uses_report: bool = True  # whether it is helpful to restate what the patient's own report documents


_MESSAGES = {
    "other_patient": (
        "I can only talk about your own reports, so I can't share anything about another person. "
        "If someone else would like to see their information, they need to sign in with their own Patient ID."
    ),
    "urgent_symptoms": (
        "If you have severe pain, swelling of the face or jaw, trouble breathing or swallowing, or bleeding that will "
        "not stop, please contact your dentist or local emergency services right away. I can't assess symptoms."
    ),
    "diagnosis": (
        "I can't diagnose conditions or tell you whether you have a particular problem. I can tell you what your "
        "report documents, and your dentist can explain what it means for you."
    ),
    "treatment": (
        "I can't recommend treatments, medicines or doses, or tell you whether you need a procedure. "
        "That is a decision for your dentist, who can examine you in person."
    ),
    "prognosis": (
        "I can't tell how serious something is or how it will develop, and your report does not say. "
        "Please ask your dentist, who can look at your situation in person."
    ),
}

_RELATIVE = r"(?:wife|husband|partner|mother|mom|mum|father|dad|son|daughter|brother|sister|friend|neighbou?r|colleague|cousin|aunt|uncle|child|kid|boyfriend|girlfriend)"
_OTHER_PHRASES = re.compile(
    rf"\b(?:my|his|her|their)\s+{_RELATIVE}\b|\banother (?:patient|person)\b|\bother (?:patients|people)\b|\bsomeone else\b|\banyone else\b|\bsomebody else\b",
    re.IGNORECASE,
)
_URGENT = re.compile(
    r"\b(?:severe|terrible|unbearable|worst|excruciating|intense) (?:tooth |jaw |dental )?pain\b|\bswollen (?:face|jaw|cheek)\b|"
    r"\b(?:face|jaw|cheek|gum)s? (?:is |are )?swell\w*|\bcan'?t (?:breathe|swallow|open my mouth)\b|\bcannot (?:breathe|swallow)\b|"
    r"\bbleeding (?:won'?t|will not|does not|doesn'?t) stop\b|\bhigh fever\b|\bpus\b",
    re.IGNORECASE,
)
_DIAGNOSIS = re.compile(
    r"\bdo i have\b(?!\s+(?:any |other |more |a |an |some )?(?:reports?|records?|x-?rays?|opgs?|appointments?|files?|results?|scans?|documents?|dental (?:reports?|exam\w*)))|\bam i (?:suffering|sick|ill|infected|diseased|dying)\b|\bwhat(?:'s| is) wrong with me\b|\bdiagnos\w*\b|"
    r"\bis (?:it|this|that|there) (?:an? )?(?:cancer\w*|tumou?r|malignan\w*|infection|infected|abscess|disease|decay|cavity)\b|"
    r"\b(?:cancer\w*|tumou?rs?|malignan\w*|carcinoma|lesion|cyst)\b|\bwhat (?:disease|condition|problem) (?:do|have) i\b|\bwhat do i have\b",
    re.IGNORECASE,
)
_TREATMENT = re.compile(
    r"\b(?:do|should|must|can|could|would|shall) i\b[^?.!]*\b(?:need|get|have|take|remove|extract|treat|undergo|use|avoid|operate|book|schedule|see)\b|"
    r"\bwhat (?:treatment|medicine|medication|drug|antibiotic|painkiller|therapy)\b|"
    r"\b(?:medicine|medication|antibiotics?|painkillers?|ibuprofen|paracetamol|acetaminophen|aspirin|dosage|dose|prescri\w+)\b|\b\d+\s?(?:mg|ml)\b|"
    r"\bhow (?:do|can|should) i (?:treat|cure|fix|get rid)\b|\bwill (?:it|this|they) (?:need|require)\b|\b(?:cure|treat) (?:it|this|my)\b",
    re.IGNORECASE,
)
_PROGNOSIS = re.compile(
    r"\bhow (?:serious|bad|severe|urgent|dangerous|worried)\b|\bhow long (?:will|until|before|for it to|does it take to (?:heal|recover|get better))\b|\bis (?:it|this|that) (?:serious|urgent|dangerous|bad|harmful|an emergency|something to worry)\b|"
    r"\bwill (?:it|this|my [a-z ]{1,25}) (?:get worse|heal|go away|hurt|spread|come back|cause|be ok|be fine)\b|"
    r"\b(?:worry|worried|worrying|scared|afraid|nervous|should i be concerned)\b|\blife[- ]threatening\b|\bgoing to (?:die|lose)\b|\bwill i lose\b",
    re.IGNORECASE,
)


def check_safety(
    message: str,
    *,
    own_patient_id: str,
    own_name: str,
    all_patients: Sequence[dict],
) -> Optional[SafetyVerdict]:
    """Return a refusal verdict, or None when the question may proceed. Order matters: privacy first."""
    text = message or ""

    # 1. Another patient (ID, name, or "my wife's report"...). Checked before anything else.
    pid = extract_patient_id(text)
    if pid and pid != own_patient_id:
        return SafetyVerdict("other_patient", _MESSAGES["other_patient"], uses_report=False)
    for m in re.finditer(r"\bP[-\s_.]?(\d{3,})\b", text, re.IGNORECASE):
        if f"P{m.group(1)}" != own_patient_id:
            return SafetyVerdict("other_patient", _MESSAGES["other_patient"], uses_report=False)
    if re.search(r"\bR\d{2,}\b", text) and False:  # report IDs are validated by the tools, not by wording
        pass
    own_tokens = set(_gnorm(own_name).split())
    normalized = f" {_gnorm(text)} "
    for p in all_patients:
        if str(p.get("patient_id")) == own_patient_id:
            continue
        for token in _gnorm(str(p.get("name", ""))).split():
            if token in own_tokens or len(token) < 3:
                continue
            if f" {token} " in normalized:
                return SafetyVerdict("other_patient", _MESSAGES["other_patient"], uses_report=False)
    if _OTHER_PHRASES.search(text):
        return SafetyVerdict("other_patient", _MESSAGES["other_patient"], uses_report=False)

    # 2. Clinical questions the assistant must not answer from a report.
    #    "Which reports do I have?" is an inventory question, not "do I have <disease>?".
    if re.search(r"\b(?:reports?|records?|x-?rays?|opgs?|appointments?|files?|scans?|documents?)\b", text, re.IGNORECASE):
        text = re.sub(r"\b(?:do|have) i (?:have|got)\b", " ", text, flags=re.IGNORECASE)
    if _URGENT.search(text):
        return SafetyVerdict("urgent_symptoms", _MESSAGES["urgent_symptoms"], uses_report=False)
    if _DIAGNOSIS.search(text):
        return SafetyVerdict("diagnosis", _MESSAGES["diagnosis"])
    if _TREATMENT.search(text):
        return SafetyVerdict("treatment", _MESSAGES["treatment"])
    if _PROGNOSIS.search(text):
        return SafetyVerdict("prognosis", _MESSAGES["prognosis"])
    return None


# ──────────────────────── validating an (LLM-proposed) interpretation ────────────────────────
@dataclass
class ValidatedIntent:
    intent: str = "unknown"
    report_ref: Optional[str] = None   # one of REPORT_REFS or an own report id like "R003"
    term: Optional[str] = None
    simplify: bool = False
    detail: bool = False
    source: str = "rules"
    dropped: list = field(default_factory=list)  # human-readable reasons, safe to log (no patient data)


def validate_interpretation(proposed: dict, *, own_report_ids: Sequence[str]) -> ValidatedIntent:
    """Accept only what business rules allow. Anything else is dropped, never trusted.

    `proposed` may come from the rule parser or from an LLM, so it is treated as untrusted input:
    unknown intents become 'unknown'; a report reference must be a known keyword or one of the
    signed-in patient's OWN report IDs; extra keys (for example a model-invented "patient_id") are ignored.
    """
    out = ValidatedIntent(source=str(proposed.get("source", "rules")))
    intent = proposed.get("intent")
    if intent in INTENTS:
        out.intent = intent
    else:
        out.dropped.append("unknown_intent")

    ref = proposed.get("report_ref")
    if isinstance(ref, str) and ref.strip():
        r = ref.strip()
        if r.lower() in REPORT_REFS:
            out.report_ref = r.lower()
        elif re.fullmatch(r"R\d{1,8}", r.upper()):
            if r.upper() in {x.upper() for x in own_report_ids}:
                out.report_ref = r.upper()
            else:
                out.dropped.append("report_ref_not_owned")  # foreign or non-existent: silently treated as 'not given'
        else:
            out.dropped.append("bad_report_ref")

    term = proposed.get("term")
    if isinstance(term, str) and term.strip():
        t = " ".join(term.split())
        if _TERM_RE.match(t):
            out.term = t
        else:
            out.dropped.append("bad_term")

    out.simplify = proposed.get("simplify") is True
    out.detail = proposed.get("detail") is True
    ignored = set(proposed) - {"intent", "report_ref", "term", "simplify", "detail", "source", "confidence"}
    if ignored:
        out.dropped.append("ignored_fields:" + ",".join(sorted(str(k) for k in ignored)[:5]))
    return out
