"""Deterministic, patient-scoped data-access tools.

These are the ONLY functions in the patient flow that read report data. Two rules make the LLM unable to
bypass authorization:

  1. `PatientTools` is constructed from the *authenticated session's* patient ID. No tool accepts a
     patient ID, name, or any other patient selector from the caller (or from the model).
  2. Every lookup filters inside that one patient's own record. A report ID belonging to anyone else is
     indistinguishable from a report that does not exist.

`TOOL_SCHEMAS` is the OpenAI-style function-calling description of the same tools (for providers/models
with native tool calling and for documentation). Note that it deliberately has no patient parameter.
"""

from __future__ import annotations

import re
from typing import Any, Callable, Optional

from ..dental.service import load_patients
from .glossary import Term, lookup

REPORT_ID_RE = re.compile(r"^R\d{1,8}$")
REPORT_TYPES = ("OPG", "Dental Examination")
_SYNTHETIC_PREFIX = re.compile(r"^\s*synthetic (?:example|demonstration report)\s*[:.]?\s*", re.IGNORECASE)

TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "list_my_reports",
            "description": "List the signed-in patient's own reports (id, type, date). Takes no arguments.",
            "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_report",
            "description": "Get one of the signed-in patient's own reports. Omit both arguments for the latest report.",
            "parameters": {
                "type": "object",
                "properties": {
                    "report_id": {"type": "string", "pattern": "^R\\d{1,8}$"},
                    "report_type": {"type": "string", "enum": list(REPORT_TYPES)},
                },
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "define_dental_term",
            "description": "General (non-patient-specific) plain-English definition of a dental term.",
            "parameters": {
                "type": "object",
                "properties": {"term": {"type": "string", "maxLength": 60}},
                "required": ["term"],
                "additionalProperties": False,
            },
        },
    },
]


class ToolError(Exception):
    """A tool refused its arguments or found nothing. `user_message` is safe to show."""

    def __init__(self, user_message: str, code: str = "tool_error"):
        super().__init__(user_message)
        self.user_message, self.code = user_message, code


def plain_finding(text: str) -> str:
    """Remove the dataset's 'Synthetic example:' label for natural reading; the verbatim text stays in evidence."""
    cleaned = _SYNTHETIC_PREFIX.sub("", text or "").strip()
    return cleaned[:1].upper() + cleaned[1:] if cleaned else (text or "")


def _public_report(report: dict) -> dict:
    """Whitelist of report fields that may leave the data layer."""
    findings = report.get("findings")
    findings = [str(f) for f in findings] if isinstance(findings, list) else []
    return {
        "report_id": str(report.get("report_id", "")),
        "type": str(report.get("type", "Dental report")),
        "date": str(report.get("date", "")),
        "findings": findings,
        "impression": str(report["impression"]) if report.get("impression") else None,
    }


class PatientTools:
    def __init__(self, patient_id: str, loader: Callable[[], list[dict]] = load_patients):
        self._patient_id = patient_id
        self._loader = loader

    # -- helpers ---------------------------------------------------------------------------------
    def _record(self) -> dict:
        for p in self._loader():
            if str(p.get("patient_id")) == self._patient_id:
                return p
        raise ToolError("Your patient record could not be found. Please sign in again.", "patient_missing")

    def _reports(self) -> list[dict]:
        return [_public_report(r) for r in self._record().get("reports", []) if isinstance(r, dict)]

    # -- tools -----------------------------------------------------------------------------------
    def patient_first_name(self) -> str:
        name = str(self._record().get("name", "")).strip()
        return name.split()[0] if name else "there"

    def list_my_reports(self) -> list[dict]:
        reports = self._reports()
        reports.sort(key=lambda r: r["date"], reverse=True)
        return [{"report_id": r["report_id"], "type": r["type"], "date": r["date"]} for r in reports]

    def get_my_report(self, report_id: Optional[str] = None, report_type: Optional[str] = None) -> dict:
        reports = self._reports()
        if report_id is not None:
            if not isinstance(report_id, str) or not REPORT_ID_RE.match(report_id.strip().upper()):
                raise ToolError("That is not a valid report ID.", "bad_report_id")
            wanted = report_id.strip().upper()
            for r in reports:
                if r["report_id"].upper() == wanted:
                    return r
            raise ToolError("I could not find that report among your reports.", "report_not_found")
        if report_type is not None:
            wanted_type = report_type.strip().casefold()
            reports = [r for r in reports if r["type"].casefold() == wanted_type]
            if not reports:
                raise ToolError(f"I could not find a {report_type} report among your reports.", "report_not_found")
        dated = [r for r in reports if r["date"]]
        if not dated:
            raise ToolError("You do not have any reports on file yet.", "no_reports")
        return max(dated, key=lambda r: r["date"])

    @staticmethod
    def define_dental_term(term: str) -> Optional[Term]:
        if not isinstance(term, str) or not term.strip() or len(term) > 60:
            raise ToolError("Please tell me which dental term you mean.", "bad_term")
        return lookup(term)

    # -- generic dispatcher (what a native tool-calling model would hit) --------------------------
    def dispatch(self, name: str, arguments: dict[str, Any] | None) -> Any:
        args = dict(arguments or {})
        allowed = {
            "list_my_reports": set(),
            "get_my_report": {"report_id", "report_type"},
            "define_dental_term": {"term"},
        }
        if name not in allowed:
            raise ToolError("Unknown tool.", "unknown_tool")
        extra = set(args) - allowed[name]
        if extra:  # e.g. a model that tries to pass patient_id / name
            raise ToolError("Unexpected tool argument.", "bad_arguments")
        if name == "list_my_reports":
            return self.list_my_reports()
        if name == "get_my_report":
            return self.get_my_report(args.get("report_id"), args.get("report_type"))
        return self.define_dental_term(args.get("term", ""))
