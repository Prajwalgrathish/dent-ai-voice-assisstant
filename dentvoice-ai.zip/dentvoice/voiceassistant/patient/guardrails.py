"""Checks applied to any LLM-written text before it can reach a patient.

The model is never trusted to stay inside the rules. Text it writes is accepted only if ALL of these hold:
  * it does not assert a diagnosis, recommend treatment/medication, promise outcomes or reassure/alarm;
  * it does not name a serious condition that appears neither in the patient's report nor in their question;
  * it does not invent dates, tooth numbers, or report IDs that are not in the evidence;
  * it does not mention any other patient (name, ID, or someone else's report ID);
  * it is not empty and not absurdly long.
If any check fails the caller discards the text and uses the deterministic, glossary-based answer instead.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable, Sequence

from .glossary import _norm as _gnorm

MAX_LLM_CHARS = 1100

_ASSERT_DIAGNOSIS = re.compile(
    r"\byou (?:have|had|are suffering|suffer|are diagnosed|were diagnosed|likely have|probably have|may have|might have|seem to have|appear to have)\b|"
    r"\byour (?:tooth|teeth|gums?|jaw|mouth) (?:is|are) (?:infected|diseased|decayed|damaged|rotten|dying)\b|\bthis (?:means|indicates|shows|confirms|suggests) (?:you|that you)\b|"
    r"\bdiagnos(?:is|ed|e)\b|\bsuffering from\b",
    re.IGNORECASE,
)
_TREATMENT_ADVICE = re.compile(
    r"\byou (?:should|must|need to|will need|ought to|have to|had better)\b|\bi (?:recommend|advise|suggest|prescribe)\b|\bit is (?:recommended|advisable|necessary) (?:that you|to)\b|"
    r"\b(?:take|use|apply) (?:an? )?(?:antibiotics?|painkillers?|ibuprofen|paracetamol|aspirin|mouthwash)\b|\b\d+\s?(?:mg|ml|tablets?|pills?)\b|"
    r"\bantibiotics?\b|\bpainkillers?\b|\bibuprofen\b|\bparacetamol\b|\bprescri\w+\b|\bneeds? (?:an? )?(?:surgery|extraction|root canal|filling|crown|treatment|operation)\b|\b(?:surgery|surgical removal|extraction|root canal|filling|crown)\b (?:is|will be|would be|may be|might be|could be) (?:needed|necessary|required|recommended|best|the best)",
    re.IGNORECASE,
)
_CLAIMS_REPORT_CONTENT = re.compile(
    r"\byour (?:report|x-?ray|opg|examination|dentist(?:'s)? notes?|results?) (?:says|said|states|stated|shows?|showed|notes?|noted|records?|recorded|found|finds|indicates?|mentions?|describes?|documents?)\b|"
    r"\baccording to your (?:report|opg|results?)\b",
    re.IGNORECASE,
)
_OVERCONFIDENT = re.compile(
    r"\b(?:definitely|certainly|guarantee\w*|for sure|without a doubt|absolutely)\b|\bnothing to worry\b|\bno need to worry\b|\bdon'?t worry\b|\bdo not worry\b|"
    r"\bnot serious\b|\bnothing serious\b|\bperfectly (?:healthy|fine|normal)\b|\bis (?:serious|dangerous|urgent|life[- ]threatening)\b|\bemergency\b|\bwill (?:definitely )?(?:get worse|heal|go away|cause|spread)\b",
    re.IGNORECASE,
)
_SERIOUS_TERMS = re.compile(
    r"\b(?:cancer\w*|tumou?rs?|malignan\w*|carcinoma|necrosis|osteomyelitis|sepsis|oral lesion|leukop\w+|metasta\w+|cyst|abscess|periodontitis|infection|infected)\b",
    re.IGNORECASE,
)
_ISO_DATE = re.compile(r"\b\d{4}-\d{2}-\d{2}\b")
_YEAR = re.compile(r"\b(?:19|20)\d{2}\b")
_TOOTH_NUMBER = re.compile(r"\btooth (?:number |no\.? |#)?\d{1,2}\b|#\d{1,2}\b", re.IGNORECASE)
_REPORT_ID = re.compile(r"\bR\d{2,8}\b")
_PATIENT_ID = re.compile(r"\bP\d{3,8}\b")


@dataclass
class GuardResult:
    ok: bool
    text: str = ""
    reasons: list = field(default_factory=list)  # short codes only; never patient text


def _contains_any(haystack_norm: str, needles: Iterable[str]) -> bool:
    return any(n and f" {n} " in haystack_norm for n in needles)


def check_llm_text(
    text: str,
    *,
    evidence_text: str,
    question: str,
    own_patient_id: str,
    own_name: str,
    own_report_ids: Sequence[str],
    all_patients: Sequence[dict],
    extra_allowed_text: str = "",
    require_general_only: bool = True,
) -> GuardResult:
    """Validate `text`; on success return it cleaned (markdown stripped, whitespace normalised)."""
    cleaned = re.sub(r"[*_`#>]+", "", text or "")
    cleaned = " ".join(cleaned.split()).strip()
    reasons: list[str] = []
    if not cleaned:
        return GuardResult(False, "", ["empty"])
    if len(cleaned) > MAX_LLM_CHARS:
        reasons.append("too_long")

    if _ASSERT_DIAGNOSIS.search(cleaned):
        reasons.append("asserts_diagnosis")
    if _TREATMENT_ADVICE.search(cleaned):
        reasons.append("treatment_advice")
    if _OVERCONFIDENT.search(cleaned):
        reasons.append("overconfident_or_reassuring")
    if require_general_only and _CLAIMS_REPORT_CONTENT.search(cleaned):
        # The report text is displayed separately and verbatim; model text must stay "general information" so
        # the two can never be confused.
        reasons.append("claims_report_content")

    allowed = f"{evidence_text} {question} {extra_allowed_text}"
    allowed_norm = f" {_gnorm(allowed)} "
    for m in _SERIOUS_TERMS.finditer(cleaned):
        if f" {_gnorm(m.group(0))} " not in allowed_norm:
            reasons.append("unsupported_serious_condition")
            break

    for rx, code in ((_ISO_DATE, "invented_date"), (_YEAR, "invented_date"), (_TOOTH_NUMBER, "invented_tooth_number")):
        for m in rx.finditer(cleaned):
            if m.group(0).lower() not in allowed.lower():
                reasons.append(code)
                break

    own_ids = {r.upper() for r in own_report_ids}
    if any(m.group(0).upper() not in own_ids for m in _REPORT_ID.finditer(cleaned)):
        reasons.append("foreign_report_id")
    if any(m.group(0).upper() != own_patient_id.upper() for m in _PATIENT_ID.finditer(cleaned)):
        reasons.append("other_patient_id")

    norm = f" {_gnorm(cleaned)} "
    own_tokens = set(_gnorm(own_name).split())
    for p in all_patients:
        if str(p.get("patient_id")) == own_patient_id:
            continue
        name_norm = _gnorm(str(p.get("name", "")))
        distinct = [t for t in name_norm.split() if t not in own_tokens and len(t) >= 3]
        if f" {name_norm} " in norm or _contains_any(norm, distinct):
            reasons.append("other_patient_name")
            break

    reasons = list(dict.fromkeys(reasons))
    return GuardResult(not reasons, cleaned if not reasons else "", reasons)
