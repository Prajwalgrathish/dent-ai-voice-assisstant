"""Patient-ID login, bearer-token sessions and per-session conversation context.

SECURITY NOTE (documented limitation): the Patient ID is the *only* credential in this demo, as the
assignment specifies. A real deployment needs real patient authentication (e.g. OTP to a registered
phone/e-mail, or an identity-provider login with MFA), not a guessable identifier. The controls here
(opaque random tokens, expiry, rate limiting of failed IDs, generic errors) limit the damage of the
demo credential but do not replace real authentication.
"""

from __future__ import annotations

import hashlib
import secrets
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Optional

from ..patient_resolver import extract_patient_id


class PatientAuthError(Exception):
    """Base for all login/session failures. `user_message` is safe to show; `status` is the HTTP status."""

    status = 401
    user_message = "Authentication failed."

    def __init__(self, user_message: Optional[str] = None):
        super().__init__(user_message or self.user_message)
        if user_message:
            self.user_message = user_message


class InvalidPatientIdFormat(PatientAuthError):
    status = 422
    user_message = "Please enter your Patient ID in the format shown on your card, for example P001."


class PatientIdNotFound(PatientAuthError):
    status = 404
    user_message = "We could not find that Patient ID. Please check it and try again."


class TooManyAttempts(PatientAuthError):
    status = 429
    user_message = "Too many unsuccessful attempts. Please wait a few minutes and try again."


class InvalidSession(PatientAuthError):
    status = 401
    user_message = "Your session is missing or has expired. Please enter your Patient ID again."


def normalize_patient_id(raw: object) -> str:
    """'p001', 'P-001', 'P 0 0 1' and 'P zero zero one' -> 'P001'. Raises InvalidPatientIdFormat otherwise."""
    if not isinstance(raw, str):
        raise InvalidPatientIdFormat()
    text = raw.strip()
    if not text or len(text) > 40:
        raise InvalidPatientIdFormat()
    pid = extract_patient_id(text)
    if not pid:
        raise InvalidPatientIdFormat()
    return pid


def short_hash(value: str) -> str:
    """Stable, non-reversible tag for logs (never log patient IDs, names or tokens)."""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:8]


@dataclass
class ConversationContext:
    """What follow-up questions may rely on. Lives only inside a session, never shared across sessions."""

    active_report_id: Optional[str] = None
    last_request: Optional[dict] = None  # {"intent", "report_id", "term", "focus"} of the last answered request
    last_answer: str = ""
    history: deque = field(default_factory=lambda: deque(maxlen=8))  # (role, text) pairs, bounded

    def remember(self, role: str, text: str) -> None:
        self.history.append((role, text[:1500]))


@dataclass
class PatientSession:
    token: str
    patient_id: str
    created_at: float
    last_seen: float
    context: ConversationContext = field(default_factory=ConversationContext)

    @property
    def tag(self) -> str:
        return short_hash(self.patient_id)


class LoginLimiter:
    """Blocks a client key after repeated failures, so IDs cannot be enumerated quickly."""

    def __init__(self, max_failures: int = 5, window_s: float = 300.0, clock: Callable[[], float] = time.monotonic):
        self.max_failures, self.window_s, self._clock = max_failures, window_s, clock
        self._failures: dict[str, deque] = {}
        self._lock = threading.Lock()

    def _prune(self, key: str) -> deque:
        q = self._failures.setdefault(key, deque())
        cutoff = self._clock() - self.window_s
        while q and q[0] < cutoff:
            q.popleft()
        return q

    def blocked(self, key: str) -> bool:
        with self._lock:
            return len(self._prune(key)) >= self.max_failures

    def record_failure(self, key: str) -> None:
        with self._lock:
            self._prune(key).append(self._clock())

    def reset(self, key: str) -> None:
        with self._lock:
            self._failures.pop(key, None)


class SessionStore:
    """In-memory sessions (single process). A production system would use a shared store such as Redis."""

    def __init__(
        self,
        ttl_s: float = 1800.0,
        idle_s: float = 900.0,
        max_sessions: int = 500,
        clock: Callable[[], float] = time.monotonic,
    ):
        self.ttl_s, self.idle_s, self.max_sessions, self._clock = ttl_s, idle_s, max_sessions, clock
        self._sessions: dict[str, PatientSession] = {}
        self._lock = threading.Lock()

    def create(self, patient_id: str) -> PatientSession:
        now = self._clock()
        with self._lock:
            self._evict(now)
            token = secrets.token_urlsafe(32)
            session = PatientSession(token=token, patient_id=patient_id, created_at=now, last_seen=now)
            self._sessions[token] = session
            return session

    def get(self, token: Optional[str]) -> PatientSession:
        if not token or not isinstance(token, str) or len(token) > 200:
            raise InvalidSession()
        now = self._clock()
        with self._lock:
            session = self._sessions.get(token)
            if session is None:
                raise InvalidSession()
            if now - session.created_at > self.ttl_s or now - session.last_seen > self.idle_s:
                del self._sessions[token]
                raise InvalidSession()
            session.last_seen = now
            return session

    def end(self, token: Optional[str]) -> None:
        with self._lock:
            self._sessions.pop(token or "", None)

    def __len__(self) -> int:
        with self._lock:
            return len(self._sessions)

    def _evict(self, now: float) -> None:
        expired = [t for t, s in self._sessions.items() if now - s.created_at > self.ttl_s or now - s.last_seen > self.idle_s]
        for t in expired:
            del self._sessions[t]
        while len(self._sessions) >= self.max_sessions:
            oldest = min(self._sessions.values(), key=lambda s: s.last_seen)
            del self._sessions[oldest.token]
