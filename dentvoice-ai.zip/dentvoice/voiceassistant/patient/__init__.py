"""Patient Voice Assistant: patient-facing, ID-scoped, report-grounded Q&A.

Layering (see docs/ARCHITECTURE.md):
  interpreter.py  - turns a free-text question into a *proposed* intent (rules first, optional LLM)
  policy.py       - deterministic business rules: validates the proposal, owns safety refusals
  tools.py        - deterministic, patient-scoped data access (the only code that reads reports)
  guardrails.py   - checks any LLM-written text before it can reach the patient
  assistant.py    - orchestration: interpret -> validate -> tools -> compose -> guard -> answer
  sessions.py     - Patient-ID login, bearer tokens, per-session conversation context
  glossary.py     - curated plain-English dental term definitions (general information)
"""
