"""Plain-English explanation of report findings, shared by the Patient Voice Assistant and the AI Assistant.

Why deterministic: the explanation of a *patient's* finding must never add findings, diagnoses or treatments that
the report does not contain. Every sentence below is therefore one of exactly four kinds, kept apart so a reader
(and the tests) can tell them apart:

  plain      - the finding's own words rewritten in everyday language (nothing added, nothing removed).
  means      - what this kind of statement means in a report, e.g. "impacted" describes a position, not a diagnosis.
  matters    - why such a finding MAY matter in general. Hedged ("can", "may"), never about the person.
  uncertain  - what the report does NOT say. Built by checking the report text itself.

The wording is reviewed text, not model output. A hosted/local LLM may only paraphrase the "means/matters" part, and
its text is checked by guardrails (voiceassistant.patient.guardrails) before it is ever used.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_SYNTHETIC_PREFIX = re.compile(r"^\s*synthetic (?:example|demonstration|training)[^:.]*[:.]\s*", re.IGNORECASE)
_SITE = re.compile(r"\b(upper|lower)\s+(left|right)\b", re.IGNORECASE)
_TOOTH = (
    (re.compile(r"\bthird\s+molars?\b|\bwisdom\s+(?:tooth|teeth)\b", re.IGNORECASE), "wisdom tooth (third molar)"),
    (re.compile(r"\bsecond\s+molars?\b", re.IGNORECASE), "second molar (a large back tooth)"),
    (re.compile(r"\bfirst\s+molars?\b", re.IGNORECASE), "first molar (a large back tooth)"),
    (re.compile(r"\bmolars?\b", re.IGNORECASE), "molar (a large back tooth)"),
    (re.compile(r"\bpre-?molars?\b", re.IGNORECASE), "premolar (a tooth between the front teeth and the molars)"),
    (re.compile(r"\bcanines?\b", re.IGNORECASE), "canine (the pointed tooth)"),
    (re.compile(r"\bincisors?\b", re.IGNORECASE), "incisor (a front tooth)"),
)


@dataclass(frozen=True)
class Condition:
    key: str
    pattern: re.Pattern
    plain: str          # the clause used after "Your report notes that ..."
    means: str
    matters: str


_CONDITIONS = (
    Condition(
        "horizontally_impacted",
        re.compile(r"\bhorizontal(?:ly)?\s+impact", re.IGNORECASE),
        "is lying on its side under the gum and has not been able to come through",
        "'Impacted' describes where the tooth is sitting. On its own it is a description of position; it is not a "
        "statement that anything is wrong or that treatment is needed.",
        "In general, a tooth that is stuck can be harder to keep clean and can sometimes press on the tooth beside it, "
        "which is why dentists like to keep an eye on it. Many impacted teeth cause no trouble at all.",
    ),
    Condition(
        "impacted",
        re.compile(r"\bimpact", re.IGNORECASE),
        "is stuck under the gum or against a neighbouring tooth, so it has not come through normally",
        "'Impacted' describes where the tooth is sitting. On its own it is a description of position; it is not a "
        "statement that anything is wrong or that treatment is needed.",
        "In general, a tooth that is stuck can be harder to keep clean and can sometimes press on the tooth beside it, "
        "which is why dentists like to keep an eye on it. Many impacted teeth cause no trouble at all.",
    ),
    Condition(
        "gingival_inflammation",
        re.compile(r"\bgingival\s+inflammation\b|\bgingivitis\b|\binflamed\s+gums?\b|\bgum\s+inflammation\b", re.IGNORECASE),
        "the gums are red or swollen (inflamed)",
        "This describes how the gums looked at the check. A word like 'mild' describes how it looked, not how it feels.",
        "In general, inflamed gums are often linked to plaque building up along the gum line. They are common and "
        "can often improve with careful brushing, cleaning between the teeth and a dental check, but a dentist is "
        "the one who can say what applies to the person.",
    ),
    Condition(
        "caries",
        re.compile(r"\bcaries\b|\bcavit(?:y|ies)\b|\btooth\s+decay\b|\bdecay\b", re.IGNORECASE),
        "a tooth is affected by decay (a cavity)",
        "This describes a tooth where the hard outer layer has started to break down.",
        "In general, decay tends to get bigger over time if it is not looked after, which is why dentists note it. "
        "How serious it is depends on how deep it goes, and only a dentist can judge that.",
    ),
    Condition(
        "no_abnormality",
        re.compile(r"\bno\s+(?:acute\s+)?(?:abnormalit(?:y|ies)|significant\s+findings?)\b", re.IGNORECASE),
        "nothing unusual or urgent was described",
        "This means the report did not describe anything that stood out. It is a statement about what was written "
        "down, not a promise that nothing could ever develop.",
        "In general, regular check-ups are how dentists catch small changes early, even when a report looks clear.",
    ),
    Condition(
        "routine_review",
        re.compile(r"\broutine\s+(?:dental\s+)?(?:review|examination|exam|check-?up)\b", re.IGNORECASE),
        "a routine check-up was recorded, and no specific problem is listed",
        "A routine check-up is a regular look at the teeth and gums. The report only records that it took place.",
        "In general, routine check-ups are mainly about spotting small things early and keeping teeth and gums healthy.",
    ),
    Condition(
        "radiographic_observations",
        re.compile(r"\bradiographic\s+observations?\b", re.IGNORECASE),
        "some observations from the X-ray were written down, but this report does not spell out what they were",
        "The report says observations were recorded; it does not list them here.",
        "In general, a panoramic X-ray gives an overview of the teeth and jaws, and the dentist writes down anything "
        "of note from it.",
    ),
    Condition(
        "generic_assessment",
        re.compile(r"\bassessment\s+documented\b|\bdemonstration report\b|^\W*clinician review required\W*$", re.IGNORECASE),
        "an assessment was recorded, but this report does not describe a specific problem",
        "The report records that an assessment took place without naming a particular finding.",
        "In general, a report without a named finding gives little to explain; your dentist can tell you more.",
    ),
)

_DEGREE = re.compile(r"\b(mild(?:ly)?|moderate(?:ly)?|severe(?:ly)?|slight(?:ly)?)\b", re.IGNORECASE)
_SEVERITY_WORDS = re.compile(r"\b(mild|moderate|severe|slight|marked|extensive|minor|significant)\b", re.IGNORECASE)
_TREATMENT_WORDS = re.compile(r"\b(treat\w*|extract\w*|remov\w+|fill\w*|refer\w*|recommend\w*|plan\w*|surgery)\b", re.IGNORECASE)
_CAUSE_WORDS = re.compile(r"\b(due to|caused by|because|secondary to|associated with)\b", re.IGNORECASE)


@dataclass(frozen=True)
class Explanation:
    plain: str
    means: str
    matters: str
    uncertain: str
    recognised: bool
    keys: tuple[str, ...] = field(default_factory=tuple)

    def sections(self, *, doctor: bool = False) -> list[dict]:
        """The four parts as labelled sections. `doctor=True` words them for a clinician."""
        out = [{"kind": "plain", "text": "In plain English: " + self.plain}]
        if self.recognised:
            out.append({"kind": "general", "text": "What this kind of wording means: " + self.means + " " + self.matters})
        out.append({"kind": "uncertain", "text": self.uncertain})
        return out


def clean_finding(text: str) -> str:
    """Drop the dataset's 'Synthetic example:' label for natural reading."""
    cleaned = _SYNTHETIC_PREFIX.sub("", text or "").strip()
    return cleaned


def _sentence(text: str) -> str:
    text = text.strip()
    if not text:
        return text
    text = text[0].upper() + text[1:]
    return text if text.endswith((".", "!", "?")) else text + "."


_VOICE = {
    "patient": {"report": "Your report", "mouth": "your mouth", "gums": "your gums",
                "symptoms": "you any symptoms", "dentist": "Only your dentist, who can examine you, can tell you what it means for you.",
                "report_lc": "your report"},
    "clinician": {"report": "The report", "mouth": "the mouth", "gums": "the gums",
                  "symptoms": "the patient any symptoms",
                  "dentist": "Only a clinician who examines the patient can say what it means for them.",
                  "report_lc": "the report"},
}


def _explain_one(finding: str, v: dict) -> tuple[str, Condition | None]:
    raw = clean_finding(finding)
    cond = next((c for c in _CONDITIONS if c.pattern.search(raw)), None)
    if cond is None:
        return "", None
    site = _SITE.search(raw)
    tooth = next((label for rx, label in _TOOTH if rx.search(raw)), None)
    degree_m = _DEGREE.search(raw)

    if cond.key in ("impacted", "horizontally_impacted"):
        subject = "a tooth"
        if tooth:
            subject = f"the {tooth}"
        where = f" in the {site.group(1).lower()} {site.group(2).lower()} of {v['mouth']}" if site else ""
        return f"{v['report']} notes that {subject}{where} {cond.plain}.", cond
    if cond.key == "gingival_inflammation":
        return _gum_sentence(degree_m.group(1).lower() if degree_m else None, v), cond
    return f"{v['report']} notes that {cond.plain}.", cond


def _gum_sentence(degree: str | None, v: dict) -> str:
    adj = {"mild": "mildly", "moderate": "moderately", "severe": "severely", "slight": "slightly"}.get(degree or "", "")
    word = f"{adj} " if adj else ""
    return f"{v['report']} notes that {v['gums']} are {word}red or swollen (inflamed)."


def explain_findings(findings: list[str], *, impression: str | None = None, audience: str = "patient") -> Explanation:
    """Explain findings in everyday English using only what the findings themselves say.

    audience="patient" speaks to the patient ("Your report..."); "clinician" is third person ("The report...")."""
    v = _VOICE["clinician" if audience == "clinician" else "patient"]
    plain_parts: list[str] = []
    seen: list[Condition] = []
    for f in findings:
        sentence, cond = _explain_one(f, v)
        if cond is not None:
            sentence = sentence if sentence.endswith(".") else sentence + "."
            plain_parts.append(sentence)
            if cond.key not in {c.key for c in seen}:
                seen.append(cond)
        else:
            raw = clean_finding(f)
            plain_parts.append(f"{v['report']} says: {_sentence(raw)} It does not explain this any further.")
    if not findings:
        plain_parts.append(f"{v['report']} does not list any specific findings.")

    report_text = " ".join(clean_finding(f) for f in findings) + " " + (impression or "")
    problem_keys = {"impacted", "horizontally_impacted", "gingival_inflammation", "caries"}
    if any(c.key in problem_keys for c in seen):
        missing = []
        if not _SEVERITY_WORDS.search(report_text):
            missing.append("how serious it is")
        if not _CAUSE_WORDS.search(report_text):
            missing.append("what caused it")
        if not _TREATMENT_WORDS.search(report_text):
            missing.append("whether any treatment is needed")
        missing.append(f"whether it is causing {v['symptoms']}")
        listed = (", ".join(missing[:-1]) + ", or " + missing[-1]) if len(missing) > 1 else missing[0]
        uncertain = (
            f"What isn't known from {v['report_lc']}: it doesn't say {listed}. " + v["dentist"]
        )
    else:
        uncertain = (
            f"What isn't known from {v['report_lc']}: it gives no further detail than this, so I can't say more about it. " + v["dentist"]
        )
    means = " ".join(dict.fromkeys(c.means for c in seen))
    matters = " ".join(dict.fromkeys(c.matters for c in seen))
    return Explanation(
        plain=" ".join(plain_parts),
        means=means,
        matters=matters,
        uncertain=uncertain,
        recognised=bool(seen),
        keys=tuple(c.key for c in seen),
    )
