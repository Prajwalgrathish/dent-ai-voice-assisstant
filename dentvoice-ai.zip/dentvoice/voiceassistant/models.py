"""Plain data containers passed between pipeline stages."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Transcript:
    text: str
    language: str = "en"
    # Heuristic 0..1 value derived from the STT engine, or None if the engine gives none.
    confidence: float | None = None
    low_confidence: bool = False
    provider: str = ""


@dataclass(frozen=True)
class StageError:
    stage: str  # "input" | "audio" | "stt" | "llm" | "tts" | ...
    message: str  # safe to show to the user


@dataclass
class TurnResult:
    # "typed": speech recognition was NOT used.  "speech": text came from STT.
    input_mode: str
    user_text: str = ""
    transcript: Transcript | None = None
    reply_text: str = ""
    audio_path: Path | None = None
    tts_engine: str | None = None
    error: StageError | None = None  # fatal: no reply could be produced
    tts_error: StageError | None = None  # non-fatal: reply_text is still valid

    @property
    def ok(self) -> bool:
        return self.error is None
