"""
Clinical dictation -> editable, validated JSON DRAFT.

Flow:  transcript --(your existing LLM + EXTRACTION_PROMPT)--> llm_text --build_draft()--> draft
       clinician edits draft in the UI --validate_draft()--> clinician confirms --finalize()--> finalized copy

Safety rules enforced in code (not left to the LLM):
  * the original transcript is always preserved verbatim
  * a tooth number is kept ONLY if that number literally occurs in the transcript (digits or spoken words)
  * unknown stays null / [] and is flagged; nothing is filled in
  * a draft can only become 'finalized' through finalize(), which needs a named reviewer + explicit confirmation
Map field names to your existing report schema in one place (`CLINICAL_FIELDS`) if they differ.
"""
from __future__ import annotations

import copy
import json
import re
from datetime import datetime, timezone
from typing import Optional

SCHEMA_VERSION = "1"
LIST_FIELDS = ("patient_reported_symptoms", "observed_findings", "anatomical_sites", "recommendations")
STR_FIELDS = ("chief_complaint", "assessment")
CLINICAL_FIELDS = STR_FIELDS + LIST_FIELDS

EXTRACTION_PROMPT = """You convert a dentist's dictation into JSON. Output ONLY one JSON object, no prose, with exactly these keys:
{"chief_complaint": string|null, "patient_reported_symptoms": [string], "observed_findings": [string],
 "anatomical_sites": [string], "assessment": string|null, "recommendations": [string]}
Rules: use only what the dictation says. If something is not stated, use null or []. Do NOT infer tooth numbers, diagnoses,
examination results or treatments. Symptoms the PATIENT reports go in patient_reported_symptoms; what the CLINICIAN observed
goes in observed_findings. Copy anatomical wording as dictated (e.g. "lower right molar"); add a tooth number only if spoken."""

# ───────────── number extraction (digits + spoken) ─────────────
_ONES = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
         "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17,
         "eighteen": 18, "nineteen": 19}
_TENS = {"twenty": 20, "thirty": 30, "forty": 40}


def numbers_in(text: str) -> set:
    t = (text or "").lower()
    found = {int(x) for x in re.findall(r"(?<!\d)\d{1,2}(?!\d)", t)}
    words = re.findall(r"[a-z]+", t)
    i = 0
    while i < len(words):
        w = words[i]
        if w in _TENS:
            if i + 1 < len(words) and words[i + 1] in _ONES and _ONES[words[i + 1]] < 10:
                found.add(_TENS[w] + _ONES[words[i + 1]])
                i += 2
                continue
            found.add(_TENS[w])
        elif w in _ONES:
            found.add(_ONES[w])
        i += 1
    return found


# ───────────── draft construction ─────────────
def new_draft(transcript: str, patient_id: Optional[str] = None, report_id: Optional[str] = None) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "status": "draft",
        "patient_id": patient_id,
        "report_id": report_id,
        "source_transcript": transcript,
        "clinical_draft": {"chief_complaint": None, "assessment": None,
                           **{k: [] for k in LIST_FIELDS}},
        "uncertainty_flags": [],
        "requires_clinician_review": True,
        "review": None,
    }


def parse_llm_json(text: str):
    """-> (dict|None, error|None). Tolerates ``` fences and chatter around the object."""
    if not isinstance(text, str) or not text.strip():
        return None, "empty_llm_output"
    s = re.sub(r"```(?:json)?", "", text).strip()
    a, b = s.find("{"), s.rfind("}")
    if a < 0 or b <= a:
        return None, "no_json_object"
    try:
        obj = json.loads(s[a:b + 1])
    except json.JSONDecodeError as e:
        return None, f"invalid_json: {e.msg}"
    return (obj, None) if isinstance(obj, dict) else (None, "json_not_object")


def _flag(draft, field, reason):
    f = {"field": field, "reason": reason}
    if f not in draft["uncertainty_flags"]:
        draft["uncertainty_flags"].append(f)


def build_draft(transcript: str, llm_text: str, patient_id: Optional[str] = None, report_id: Optional[str] = None) -> dict:
    d = new_draft(transcript, patient_id, report_id)
    if not (transcript or "").strip():
        _flag(d, "source_transcript", "empty_transcript")
        return d
    obj, err = parse_llm_json(llm_text)
    if err:
        _flag(d, "*", f"llm_output_unusable ({err}); fill in manually")
        return d
    cd = d["clinical_draft"]
    for k in STR_FIELDS:
        v = obj.get(k)
        cd[k] = v.strip() if isinstance(v, str) and v.strip() else None
    for k in LIST_FIELDS:
        v = obj.get(k)
        cd[k] = [x.strip() for x in v if isinstance(x, str) and x.strip()] if isinstance(v, list) else []

    spoken = numbers_in(transcript)
    kept = []
    for site in cd["anatomical_sites"]:                 # anti-invention: numbers must come from the dictation
        bad = [n for n in numbers_in(site) if n not in spoken]
        if bad:
            _flag(d, "anatomical_sites", f"removed '{site}': tooth number {sorted(bad)} not found in the dictation")
        else:
            kept.append(site)
    cd["anatomical_sites"] = kept
    if not kept:
        _flag(d, "anatomical_sites", "anatomical site not specified or could not be verified")
    elif not any(numbers_in(s) for s in kept):
        _flag(d, "anatomical_sites", "region given but no specific tooth identified")
    if cd["assessment"]:
        _flag(d, "assessment", "assessment text came from the model; clinician must confirm it")
    if not cd["chief_complaint"] and not cd["patient_reported_symptoms"] and not cd["observed_findings"]:
        _flag(d, "clinical_draft", "nothing extractable from the dictation")
    if not patient_id:
        _flag(d, "patient_id", "patient not yet linked to this draft")
    return d


# ───────────── validation + review workflow ─────────────
def validate_draft(d) -> list:
    """Returns a list of error strings ([] = valid). Safe on malformed input."""
    e = []
    if not isinstance(d, dict):
        return ["draft is not an object"]
    for k in ("schema_version", "status", "patient_id", "report_id", "source_transcript", "clinical_draft",
              "uncertainty_flags", "requires_clinician_review", "review"):
        if k not in d:
            e.append(f"missing key: {k}")
    if e:
        return e
    if not isinstance(d["source_transcript"], str) or not d["source_transcript"].strip():
        e.append("source_transcript must be non-empty text")
    cd = d["clinical_draft"]
    if not isinstance(cd, dict):
        return e + ["clinical_draft must be an object"]
    for k in STR_FIELDS:
        if cd.get(k) is not None and not isinstance(cd.get(k), str):
            e.append(f"{k} must be text or null")
    for k in LIST_FIELDS:
        v = cd.get(k)
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            e.append(f"{k} must be a list of text")
    if not isinstance(d["uncertainty_flags"], list):
        e.append("uncertainty_flags must be a list")
    if d["status"] not in ("draft", "finalized"):
        e.append("status must be 'draft' or 'finalized'")
    if d["requires_clinician_review"] is not True and d["status"] == "draft":
        e.append("a draft must keep requires_clinician_review = true")
    if d["status"] == "finalized":
        r = d["review"]
        if not (isinstance(r, dict) and r.get("confirmed") is True and str(r.get("reviewed_by", "")).strip()):
            e.append("finalized draft needs review.confirmed = true and reviewed_by")
    elif d["review"] is not None:
        e.append("an unreviewed draft must have review = null")
    return e


def finalize(draft: dict, *, reviewer_id: str, confirmed: bool, acknowledge_flags: bool = False) -> dict:
    """Explicit clinician step. Raises ValueError unless everything is in order; returns a NEW dict."""
    errs = validate_draft(draft)
    if errs:
        raise ValueError("draft is invalid: " + "; ".join(errs))
    if draft["status"] != "draft":
        raise ValueError("already finalized")
    if confirmed is not True:
        raise ValueError("clinician confirmation required")
    if not (reviewer_id or "").strip():
        raise ValueError("reviewer_id required")
    if not draft.get("patient_id"):
        raise ValueError("link the draft to a patient before finalizing")
    if draft["uncertainty_flags"] and not acknowledge_flags:
        raise ValueError("unresolved uncertainty flags: acknowledge them explicitly or edit the draft")
    out = copy.deepcopy(draft)
    out["status"] = "finalized"
    out["requires_clinician_review"] = False
    out["review"] = {"reviewed_by": reviewer_id.strip(), "confirmed": True,
                     "reviewed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                     "flags_acknowledged": bool(draft["uncertainty_flags"])}
    return out
