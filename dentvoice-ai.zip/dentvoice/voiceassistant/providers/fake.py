"""Fake providers: used by the automated tests, and selectable with *_PROVIDER=fake
to try the wiring without downloading any models. They do NOT do real speech or language work."""

from __future__ import annotations

import math
import struct
import wave
from pathlib import Path

from ..models import Transcript
from .base import LLMProvider, STTProvider, TTSProvider


def write_tone_wav(path: str | Path, seconds: float = 0.3, rate: int = 16000, freq: float = 440.0, amplitude: int = 6000) -> None:
    """Write a mono 16-bit sine tone (stand-in for real audio in tests)."""
    n = int(seconds * rate)
    frames = b"".join(
        struct.pack("<h", int(amplitude * math.sin(2 * math.pi * freq * i / rate))) for i in range(n)
    )
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(frames)


class FakeSTT(STTProvider):
    name = "fake_stt"

    def __init__(self, text="this is a fake transcript", confidence=0.9, low_confidence=False, error=None):
        self.text, self.confidence, self.low_confidence, self.error = text, confidence, low_confidence, error
        self.calls: list[Path] = []

    def transcribe(self, audio_path, language="en"):
        self.calls.append(Path(audio_path))
        if self.error:
            raise self.error
        return Transcript(
            text=self.text,
            language=language,
            confidence=self.confidence,
            low_confidence=self.low_confidence,
            provider=self.name,
        )


class FakeLLM(LLMProvider):
    name = "fake_llm"

    def __init__(self, reply=None, replies=None, error=None):
        self.reply, self.replies, self.error = reply, list(replies) if replies else None, error
        self.calls: list[list[dict[str, str]]] = []

    def complete(self, messages):
        self.calls.append([dict(m) for m in messages])
        if self.error:
            raise self.error
        if self.replies:
            return self.replies.pop(0)
        if self.reply is not None:
            return self.reply
        last_user = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
        return f"(fake LLM) You said: {last_user}"


class FakeTTS(TTSProvider):
    def __init__(self, name="fake_tts", error=None, seconds=0.2):
        self.name, self.error, self.seconds = name, error, seconds
        self.calls: list[str] = []

    def synthesize(self, text, out_path, language="en"):
        self.calls.append(text)
        if self.error:
            raise self.error
        write_tone_wav(out_path, seconds=self.seconds)
