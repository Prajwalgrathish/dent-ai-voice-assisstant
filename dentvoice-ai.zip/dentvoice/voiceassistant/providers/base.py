"""Abstract provider interfaces. The rest of the app depends only on these."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path

from ..errors import TTSError, VoiceAssistantError
from ..models import Transcript

log = logging.getLogger(__name__)


class STTProvider(ABC):
    name = "stt"

    @abstractmethod
    def transcribe(self, audio_path: Path, language: str = "en") -> Transcript:
        """Transcribe an audio file. Raise STTError on failure."""


class LLMProvider(ABC):
    name = "llm"

    @abstractmethod
    def complete(self, messages: list[dict[str, str]]) -> str:
        """Return the assistant's reply text for a chat-style message list.

        Messages use OpenAI-style dicts: {"role": "system"|"user"|"assistant", "content": str}.
        Raise an LLMError subclass on failure.
        """


class TTSProvider(ABC):
    name = "tts"

    @abstractmethod
    def synthesize(self, text: str, out_path: Path, language: str = "en") -> None:
        """Write speech for `text` to `out_path` as a WAV file. Raise TTSError on failure."""


class FallbackTTS(TTSProvider):
    """Try several TTS providers in order (e.g. Piper, then pyttsx3)."""

    name = "fallback"

    def __init__(self, providers: list[TTSProvider]):
        if not providers:
            raise ValueError("FallbackTTS needs at least one provider")
        self.providers = providers
        self.last_used: str | None = None

    def synthesize(self, text: str, out_path: Path, language: str = "en") -> None:
        failures: list[str] = []
        for provider in self.providers:
            try:
                provider.synthesize(text, out_path, language)
            except VoiceAssistantError as exc:
                log.warning("TTS provider %s failed: %s", provider.name, exc)
                failures.append(f"{provider.name}: {exc.user_message}")
                continue
            except Exception as exc:  # noqa: BLE001 - provider bugs must not crash the turn
                log.warning("TTS provider %s crashed: %s", provider.name, type(exc).__name__)
                failures.append(f"{provider.name}: unexpected error")
                continue
            self.last_used = provider.name
            return
        raise TTSError(
            "all TTS providers failed: " + "; ".join(failures),
            user_message="Speech synthesis failed. The text answer is still available.",
        )
