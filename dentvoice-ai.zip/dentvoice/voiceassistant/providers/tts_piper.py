"""Piper TTS via its command-line interface (local, CPU).

Install (separately from the core requirements, because Windows compatibility is the least
certain part of this stack):  pip install piper-tts
You also need a voice model: a .onnx file plus its .onnx.json next to it (see README).

Why the CLI instead of Piper's Python API: the Python API has changed between releases, while
`python -m piper --model M --output_file out.wav` (text on stdin) is the long-standing interface.
Flag spelling (`--output_file` vs `--output-file`) differs between releases, so it is detected
from `--help` once. This has NOT been verified against a real Piper install by the author.
"""

from __future__ import annotations

import logging
import subprocess
import sys
from pathlib import Path

from ..errors import TTSError
from .base import TTSProvider

log = logging.getLogger(__name__)


class PiperTTS(TTSProvider):
    name = "piper"

    def __init__(self, model_path: str, length_scale: float = 1.0, command_prefix: list[str] | None = None, timeout_s: float = 60.0):
        self.model_path = model_path
        self.length_scale = length_scale
        self._cmd = list(command_prefix) if command_prefix else [sys.executable, "-m", "piper"]
        self.timeout_s = timeout_s
        self._help_text: str | None = None

    def _flag(self, name: str) -> str:
        if self._help_text is None:
            try:
                proc = subprocess.run(self._cmd + ["--help"], capture_output=True, timeout=30)
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise TTSError(
                    f"cannot run piper: {type(exc).__name__}",
                    user_message="Piper could not be started. Install it with: pip install piper-tts",
                ) from exc
            if proc.returncode != 0:
                raise TTSError(
                    "piper --help failed",
                    user_message="Piper is not installed or failed to start. Install it with: pip install piper-tts",
                )
            self._help_text = (proc.stdout + proc.stderr).decode("utf-8", errors="replace")
        hyphen = "--" + name.replace("_", "-")
        return hyphen if hyphen in self._help_text else "--" + name

    def synthesize(self, text: str, out_path: Path, language: str = "en") -> None:
        if not text.strip():
            raise TTSError("empty text", user_message="Nothing to speak.")
        if not self.model_path:
            raise TTSError(
                "PIPER_MODEL_PATH not set", user_message="No Piper voice model is configured (PIPER_MODEL_PATH)."
            )
        model = Path(self.model_path)
        if not model.is_file() or not Path(str(model) + ".json").is_file():
            raise TTSError(
                "piper model or its .json config missing",
                user_message="The Piper voice model or its .onnx.json file was not found. Check PIPER_MODEL_PATH.",
            )
        cmd = self._cmd + [self._flag("model"), str(model), self._flag("output_file"), str(out_path)]
        if self.length_scale != 1.0:
            cmd += [self._flag("length_scale"), str(self.length_scale)]
        try:
            proc = subprocess.run(cmd, input=text.encode("utf-8"), capture_output=True, timeout=self.timeout_s)
        except subprocess.TimeoutExpired:
            raise TTSError("piper timed out", user_message="Speech synthesis timed out.") from None
        except OSError as exc:
            raise TTSError(f"cannot run piper: {type(exc).__name__}", user_message="Piper could not be started.") from exc
        if proc.returncode != 0:
            log.warning("piper exited %s: %s", proc.returncode, proc.stderr.decode("utf-8", "replace")[-300:])
            raise TTSError(f"piper exited with code {proc.returncode}", user_message="Speech synthesis failed.")
        if not Path(out_path).is_file() or Path(out_path).stat().st_size <= 44:
            raise TTSError("piper produced no audio", user_message="Speech synthesis produced no audio.")
