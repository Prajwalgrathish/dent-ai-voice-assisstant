"""pyttsx3 TTS fallback (Windows SAPI5, offline, robotic voice). Requires: pip install pyttsx3

A fresh engine is created per call, which avoids known hangs when reusing an engine.
Behaviour on a real Windows machine has NOT been verified by the author.
"""

from __future__ import annotations

import logging
from pathlib import Path

from ..errors import TTSError
from .base import TTSProvider

log = logging.getLogger(__name__)


class Pyttsx3TTS(TTSProvider):
    name = "pyttsx3"

    def __init__(self, rate_wpm: int = 170):
        self.rate_wpm = rate_wpm

    def synthesize(self, text: str, out_path: Path, language: str = "en") -> None:
        if not text.strip():
            raise TTSError("empty text", user_message="Nothing to speak.")
        try:
            import pyttsx3
        except ImportError as exc:
            raise TTSError(
                "pyttsx3 is not installed", user_message="Fallback speech is not installed. Run: pip install pyttsx3"
            ) from exc
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", self.rate_wpm)
            engine.save_to_file(text, str(out_path))
            engine.runAndWait()
            engine.stop()
        except Exception as exc:  # noqa: BLE001
            log.exception("pyttsx3 failed")
            raise TTSError(f"pyttsx3 failed: {type(exc).__name__}", user_message="Speech synthesis failed.") from exc
        if not Path(out_path).is_file() or Path(out_path).stat().st_size <= 44:
            raise TTSError("pyttsx3 produced no audio", user_message="Speech synthesis produced no audio.")
