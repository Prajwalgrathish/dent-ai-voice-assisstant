"""Provider interfaces and implementations. Heavy third-party imports happen lazily inside each provider."""
