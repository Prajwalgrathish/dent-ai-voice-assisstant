"""LLM provider for any OpenAI-compatible /chat/completions endpoint.

Works with local Ollama (default http://localhost:11434/v1) and hosted APIs, selected only by
LLM_BASE_URL / LLM_API_KEY / LLM_MODEL. Standard library only (urllib).

Retries: rate limits (429), server errors (5xx) and timeouts are retried up to `max_retries`
times with a bounded delay. Connection refused, 4xx and malformed bodies are not retried.
"""

from __future__ import annotations

import http.client
import json
import logging
import socket
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse

from ..errors import (
    LLMConnectionError,
    LLMError,
    LLMRateLimitError,
    LLMResponseError,
    LLMServerError,
    LLMTimeoutError,
)
from .base import LLMProvider

log = logging.getLogger(__name__)
_MAX_BODY = 2_000_000
_MAX_BACKOFF_S = 10.0
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}


class OpenAICompatLLM(LLMProvider):
    name = "openai_compat"

    def __init__(
        self,
        base_url: str,
        model: str,
        api_key: str = "",
        timeout_s: float = 60.0,
        max_retries: int = 2,
        temperature: float = 0.4,
        max_tokens: int = 300,
        sleep=time.sleep,
    ):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._api_key = api_key
        self.timeout_s = timeout_s
        self.max_retries = max_retries
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._sleep = sleep
        host = urlparse(self.base_url).hostname or ""
        self._local = host in _LOCAL_HOSTS

    def complete(self, messages: list[dict[str, str]]) -> str:
        if not messages:
            raise LLMError("no messages", user_message="Nothing to send to the language model.")
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "stream": False,
        }
        for attempt in range(self.max_retries + 1):
            try:
                return self._request_once(payload)
            except LLMError as exc:
                if not exc.retryable or attempt >= self.max_retries:
                    raise
                delay = getattr(exc, "retry_after", None)
                delay = min(delay if delay else 0.5 * (2**attempt), _MAX_BACKOFF_S)
                log.warning("LLM request failed (%s); retry %d/%d in %.1fs", type(exc).__name__, attempt + 1, self.max_retries, delay)
                self._sleep(delay)
        raise AssertionError("unreachable")  # pragma: no cover

    # ------------------------------------------------------------------
    def _open(self, request):
        if self._local:
            # Never send local traffic through a system HTTP proxy.
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            return opener.open(request, timeout=self.timeout_s)
        return urllib.request.urlopen(request, timeout=self.timeout_s)

    def _request_once(self, payload: dict) -> str:
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with self._open(request) as response:
                body = response.read(_MAX_BODY)
        except urllib.error.HTTPError as exc:
            error = self._http_error(exc)
            exc.close()  # release the response socket held by the HTTPError
            raise error from None
        except urllib.error.URLError as exc:
            if isinstance(exc.reason, (TimeoutError, socket.timeout)):
                raise LLMTimeoutError(
                    "LLM request timed out", user_message="The language model took too long to respond."
                ) from None
            raise LLMConnectionError(
                f"cannot connect to LLM: {type(exc.reason).__name__}",
                user_message=(
                    "Could not reach the language model. If you use Ollama, make sure it is running "
                    "and that LLM_BASE_URL is correct."
                ),
            ) from None
        except TimeoutError:
            raise LLMTimeoutError(
                "LLM request timed out", user_message="The language model took too long to respond."
            ) from None
        except (OSError, http.client.HTTPException):
            raise LLMConnectionError(
                "connection to LLM failed", user_message="The connection to the language model was interrupted."
            ) from None
        return self._parse(body)

    @staticmethod
    def _http_error(exc: urllib.error.HTTPError) -> LLMError:
        status = exc.code
        if status == 429:
            retry_after = None
            try:
                retry_after = float(exc.headers.get("Retry-After", ""))
            except (TypeError, ValueError):
                pass
            return LLMRateLimitError(
                "LLM rate limited (HTTP 429)",
                user_message="The language model is rate limited right now. Please try again shortly.",
                retry_after=retry_after,
            )
        if 500 <= status < 600:
            return LLMServerError(
                f"LLM server error (HTTP {status})", user_message="The language model server had an error."
            )
        if status in (401, 403):
            return LLMError(
                f"LLM rejected credentials (HTTP {status})",
                user_message="The language model rejected the credentials. Check LLM_API_KEY.",
            )
        if status == 404:
            return LLMError(
                "LLM endpoint or model not found (HTTP 404)",
                user_message=(
                    "Language model or endpoint not found. Check LLM_BASE_URL and LLM_MODEL "
                    "(for Ollama, run: ollama pull <model>)."
                ),
            )
        return LLMError(f"LLM request rejected (HTTP {status})", user_message="The language model rejected the request.")

    @staticmethod
    def _parse(body: bytes) -> str:
        bad = LLMResponseError(
            "malformed LLM response", user_message="The language model returned an unusable response."
        )
        try:
            data = json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise bad from None
        if not isinstance(data, dict) or data.get("error"):
            raise bad
        choices = data.get("choices")
        if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
            raise bad
        message = choices[0].get("message")
        content = message.get("content") if isinstance(message, dict) else None
        if not isinstance(content, str) or not content.strip():
            raise LLMResponseError(
                "empty LLM reply", user_message="The language model returned an empty response."
            )
        return content.strip()
