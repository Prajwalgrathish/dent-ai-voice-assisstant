"""faster-whisper STT (local, CPU-friendly). Requires: pip install faster-whisper

The model is downloaded on first use (internet needed once), then works offline.
Confidence is a heuristic: mean of exp(avg_logprob) over segments. It is NOT a calibrated
probability; tune STT_MIN_CONFIDENCE against real recordings.
"""

from __future__ import annotations

import logging
import math
from pathlib import Path

from ..errors import STTError
from ..models import Transcript
from .base import STTProvider

log = logging.getLogger(__name__)


class FasterWhisperSTT(STTProvider):
    name = "faster_whisper"

    def __init__(self, model="base.en", device="cpu", compute_type="int8", min_confidence=0.45):
        self.model_name, self.device, self.compute_type = model, device, compute_type
        self.min_confidence = min_confidence
        self._model = None

    def _load(self):
        if self._model is not None:
            return self._model
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise STTError(
                "faster-whisper is not installed",
                user_message="Speech recognition is not installed. Run: pip install faster-whisper",
            ) from exc
        try:
            self._model = WhisperModel(self.model_name, device=self.device, compute_type=self.compute_type)
        except Exception as exc:  # noqa: BLE001
            log.exception("Failed to load Whisper model %s", self.model_name)
            raise STTError(
                f"failed to load Whisper model: {type(exc).__name__}",
                user_message="Could not load the speech model. The first run needs an internet connection to download it.",
            ) from exc
        return self._model

    def transcribe(self, audio_path: Path, language: str = "en") -> Transcript:
        model = self._load()
        prompt = "Dental clinic conversation. Patient names, reports, PDF."
        try:
            segments, info = model.transcribe(
                str(audio_path),
                language=language,
                vad_filter=True,
                vad_parameters=dict(threshold=0.35, min_speech_duration_ms=100),
                beam_size=5,
                initial_prompt=prompt,
                condition_on_previous_text=False,
                no_speech_threshold=0.6,
                log_prob_threshold=-1.0,
            )
            # Filter low confidence / hallucinated segments
            segs = [
                s for s in segments
                if not (getattr(s, "no_speech_prob", 0.0) > 0.6 and getattr(s, "avg_logprob", 0.0) < -1.0)
            ]
            # Fallback if VAD filter was overly aggressive on soft microphone audio
            if not segs:
                segments_fallback, _ = model.transcribe(
                    str(audio_path),
                    language=language,
                    vad_filter=False,
                    beam_size=5,
                    initial_prompt=prompt,
                    condition_on_previous_text=False,
                    no_speech_threshold=0.8,
                )
                segs = [
                    s for s in segments_fallback
                    if not (getattr(s, "no_speech_prob", 0.0) > 0.75 and getattr(s, "avg_logprob", 0.0) < -1.2)
                ]
        except Exception as exc:  # noqa: BLE001
            log.exception("Whisper transcription failed")
            raise STTError(
                f"transcription failed: {type(exc).__name__}",
                user_message="Speech recognition failed on this audio. Try again or use typed input.",
            ) from exc

        text = " ".join(s.text.strip() for s in segs).strip()
        probs = [math.exp(min(0.0, s.avg_logprob)) for s in segs if getattr(s, "avg_logprob", None) is not None]
        confidence = sum(probs) / len(probs) if probs else None
        low = confidence is not None and confidence < self.min_confidence
        log.info("[FasterWhisperSTT] Transcribed text='%s', confidence=%s, low=%s", text, confidence, low)
        return Transcript(text=text, language=language, confidence=confidence, low_confidence=low, provider=self.name)
