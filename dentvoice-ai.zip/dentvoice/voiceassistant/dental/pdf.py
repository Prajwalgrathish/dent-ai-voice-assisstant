"""PDF generation utility for synthetic dental patient reports.

Generates standards-compliant PDF (PDF-1.4) documents in pure Python
without external binary dependencies.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any


def _escape_pdf_text(text: str) -> str:
    """Escape parentheses and backslashes for PDF string literals."""
    if not text:
        return ""
    # Standard ASCII for Type 1 fonts
    safe = text.encode("ascii", "replace").decode("ascii")
    return safe.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def generate_patient_report_pdf(
    patient_name: str,
    patient_id: str,
    report: dict[str, Any],
    date_of_birth: str = "",
    phone_contact: str = "",
    synthetic_data: bool = True,
    requires_clinician_review: bool = True,
) -> bytes:
    """Generate a clean, professional, standards-compliant PDF report."""
    report_id = str(report.get("report_id", "Not specified"))
    report_type = str(report.get("type", "Dental Examination"))
    report_date = str(report.get("date", "Not specified"))
    findings = report.get("findings") or []
    if isinstance(findings, str):
        findings = [findings]
    impression = str(report.get("impression") or "Clinician review required.")

    commands: list[str] = []

    # Header bar (dark navy banner)
    commands.append("0.08 0.18 0.36 rg")  # Dark navy
    commands.append("40 760 515 50 re f")

    # Header text
    commands.append("BT")
    commands.append("1 1 1 rg")  # White
    commands.append("/F1 18 Tf")
    commands.append("55 780 Td")
    commands.append(f"({_escape_pdf_text('DentVoice AI - Clinical Dental Report')}) Tj")
    commands.append("ET")

    # Generation metadata line
    commands.append("BT")
    commands.append("0.4 0.4 0.4 rg")
    commands.append("/F2 9 Tf")
    commands.append("40 742 Td")
    gen_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    commands.append(
        f"({_escape_pdf_text(f'Generated: {gen_time} | Local Clinical Voice Assistant')}) Tj"
    )
    commands.append("ET")

    # Patient Details Box
    y = 715
    commands.append("0.93 0.95 0.98 rg")  # Soft blue/gray background
    commands.append(f"40 {y - 65} 515 80 re f")
    commands.append("0.2 0.3 0.5 RG")
    commands.append("1 w")
    commands.append(f"40 {y - 65} 515 80 re S")

    commands.append("BT")
    commands.append("0.1 0.1 0.1 rg")
    commands.append("/F1 11 Tf")
    commands.append(f"55 {y} Td")
    commands.append(f"({_escape_pdf_text('PATIENT RECORD')}) Tj")

    commands.append("/F2 10 Tf")
    commands.append("0 -18 Td")
    commands.append(
        f"({_escape_pdf_text(f'Patient Name: {patient_name}        Patient ID: {patient_id}')}) Tj"
    )
    commands.append("0 -16 Td")
    dob_str = f"DOB: {date_of_birth}" if date_of_birth else "DOB: Not specified"
    contact_str = f"Contact: {phone_contact}" if phone_contact else "Contact: Verified In Record"
    commands.append(f"({_escape_pdf_text(f'{dob_str}        {contact_str}')}) Tj")
    commands.append("0 -16 Td")
    commands.append(
        f"({_escape_pdf_text(f'Report Type: {report_type}        Report ID: {report_id}        Date: {report_date}')}) Tj"
    )
    commands.append("ET")

    # Clinical Findings Section
    y = 620
    commands.append("BT")
    commands.append("0.08 0.18 0.36 rg")
    commands.append("/F1 12 Tf")
    commands.append(f"40 {y} Td")
    commands.append(f"({_escape_pdf_text('CLINICAL FINDINGS')}) Tj")
    commands.append("ET")

    y -= 10
    commands.append("0.8 0.8 0.8 RG 0.5 w")
    commands.append(f"40 {y} m 555 {y} l S")

    y -= 18
    commands.append("BT")
    commands.append("0.15 0.15 0.15 rg")
    commands.append("/F2 10 Tf")
    commands.append(f"50 {y} Td")

    if findings:
        for f in findings:
            commands.append(f"({_escape_pdf_text(f'-  {f}')}) Tj")
            commands.append("0 -16 Td")
            y -= 16
    else:
        commands.append(f"({_escape_pdf_text('-  No specific abnormalities or findings recorded.')}) Tj")
        commands.append("0 -16 Td")
        y -= 16
    commands.append("ET")

    # Impression Section
    y -= 15
    commands.append("BT")
    commands.append("0.08 0.18 0.36 rg")
    commands.append("/F1 12 Tf")
    commands.append(f"40 {y} Td")
    commands.append(f"({_escape_pdf_text('CLINICAL IMPRESSION')}) Tj")
    commands.append("ET")

    y -= 10
    commands.append("0.8 0.8 0.8 RG 0.5 w")
    commands.append(f"40 {y} m 555 {y} l S")

    y -= 18
    commands.append("BT")
    commands.append("0.15 0.15 0.15 rg")
    commands.append("/F2 10 Tf")
    commands.append(f"50 {y} Td")
    commands.append(f"({_escape_pdf_text(impression)}) Tj")
    commands.append("ET")

    # Disclaimer Box at bottom
    commands.append("1.0 0.96 0.9 rg")  # Warm light amber
    commands.append("40 80 515 65 re f")
    commands.append("0.8 0.5 0.1 RG 1 w")
    commands.append("40 80 515 65 re S")

    commands.append("BT")
    commands.append("0.6 0.3 0.0 rg")
    commands.append("/F1 9 Tf")
    commands.append("50 128 Td")
    commands.append(f"({_escape_pdf_text('IMPORTANT NOTICES & CLINICAL SAFEGUARDS')}) Tj")
    commands.append("/F2 8 Tf")
    commands.append("0 -14 Td")
    if synthetic_data:
        commands.append(
            f"({_escape_pdf_text('SYNTHETIC DATA: This record contains synthetic patient demonstration data for testing only.')}) Tj"
        )
        commands.append("0 -12 Td")
    if requires_clinician_review:
        commands.append(
            f"({_escape_pdf_text('CLINICIAN REVIEW REQUIRED: All findings and impressions must be reviewed by a qualified dental professional.')}) Tj"
        )
        commands.append("0 -12 Td")
    commands.append(
        f"({_escape_pdf_text('CONFIDENTIALITY: Do not use for real clinical diagnosis without official medical record verification.')}) Tj"
    )
    commands.append("ET")

    content_stream = "\n".join(commands).encode("ascii")

    # PDF Object Graph
    objects: list[bytes] = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
        b"/Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>",
        b"<< /Length " + str(len(content_stream)).encode("ascii") + b" >>\nstream\n"
        + content_stream + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]

    output = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets: list[int] = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(output))
        output.extend(f"{i} 0 obj\n".encode("ascii"))
        output.extend(obj)
        output.extend(b"\nendobj\n")

    xref_offset = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    output.extend(b"0000000000 65535 f \n")
    for offset in offsets:
        output.extend(f"{offset:010d} 00000 n \n".encode("ascii"))

    output.extend(
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_offset}\n%%EOF\n".encode("ascii")
    )

    return bytes(output)
