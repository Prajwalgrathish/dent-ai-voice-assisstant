
"""Recognize natural-language requests for dental report retrieval."""

import re

from ..patient_resolver import extract_patient_id

# Words that may precede a possessive patient name in a spoken command ("Open Priya's latest OPG report").
_COMMAND_WORDS = frozenset({
    "open", "show", "get", "fetch", "find", "pull", "up", "bring", "retrieve", "view", "give", "me",
    "display", "load", "read", "please", "can", "you", "could", "would", "the", "a", "an", "to", "and",
    "i", "need", "want", "like", "see", "look", "at", "check", "send", "download", "summarize", "summarise",
})

# Words that can never be part of a patient's name ("show the patient's report").
_NOT_A_NAME = frozenset({"the", "a", "an", "patient", "patients", "his", "her", "their", "my", "this", "that", "latest", "recent", "report", "reports",
                        # pronouns and reference words are never names ("open it for him")
                        "he", "she", "they", "him", "them", "hers", "theirs", "it", "one", "same", "again", "for"})

REPORT_TERMS = (
    "report",
    "reports",
    "opg",
    "x-ray",
    "xray",
    "dental examination",
    "examination report",
)


def parse_report_request(text: str) -> dict[str, str] | None:
    """Extract identifiers from a likely report request.

    This detects broad intent and identifiers; it does not decide which
    patient is correct. Patient identity is validated by the dental service.
    """
    original = " ".join((text or "").strip().split())
    lowered = original.casefold()

    if not any(term in lowered for term in REPORT_TERMS):
        return None

    result: dict[str, str] = {}

    # Explicit synthetic patient identifier. Speech recognition renders "P003" in many ways
    # ("P-003", "P 0 0 3", "P zero zero three"), so use the shared spoken-ID normaliser first.
    spoken_id = extract_patient_id(original)
    if spoken_id:
        result["patient_id"] = spoken_id
    else:
        patient_id = re.search(r"\bP\d{3,}\b", original, re.IGNORECASE)
        if patient_id:
            result["patient_id"] = patient_id.group(0).upper()

    # Explicit ISO date of birth.
    dob = re.search(r"\b\d{4}-\d{2}-\d{2}\b", original)
    if dob:
        result["date_of_birth"] = dob.group(0)

    # Recognize supported report types without requiring one exact sentence.
    if re.search(r"\bOPG\b", original, re.IGNORECASE):
        result["report_type"] = "OPG"
    elif re.search(r"\bdental examination\b|\bexamination report\b",
                   original, re.IGNORECASE):
        result["report_type"] = "Dental Examination"

    # Extract patient name regardless of capitalization.
    # 1. Match against known patient names in the synthetic dataset.
    try:
        from .service import load_patients

        for patient in load_patients():
            p_name = patient.get("name", "")
            if p_name and re.search(r"\b" + re.escape(p_name) + r"\b", original, re.IGNORECASE):
                result["name"] = p_name
                break
    except Exception:
        pass

    # 2. Extract from possessive structures (taking the final two words before 's).
    if not result.get("name"):
        possessive = re.search(r"\b((?:[A-Za-z][A-Za-z'-]*\s+)*[A-Za-z][A-Za-z'-]*)['’]s\b", original, re.IGNORECASE)
        if possessive:
            # Drop leading command words ("Open Priya's ..." must give "Priya", not "Open Priya").
            words = possessive.group(1).split()
            while len(words) > 1 and words[0].casefold() in _COMMAND_WORDS:
                words.pop(0)
            if words and words[0].casefold() not in _COMMAND_WORDS | {"what", "whats", "that", "this", "patient", "patients", "his", "her", "their"} \
                    and not any(w.casefold() in _NOT_A_NAME for w in words):  # "the same patient's report" is a reference
                result["name"] = " ".join(words[-2:])

    # 3. Extract from prepositional or command structures ("for <name>", "of <name>", "show <name>").
    if not result.get("name"):
        patterns = (
            r"\bfor\s+(?:patient\s+)?([A-Za-z][A-Za-z'-]+(?:\s+[A-Za-z][A-Za-z'-]+)+)",
            r"\b(?:reports?|findings?|records?)\s+of\s+(?:patient\s+)?([A-Za-z][A-Za-z'-]+(?:\s+[A-Za-z][A-Za-z'-]+)+)",
            r"\bof\s+([A-Za-z][A-Za-z'-]+(?:\s+[A-Za-z][A-Za-z'-]+)+?)(?=\s+(?:latest|most recent|last|opg|x-?ray|dental|report)|[?.!]*$)",
            r"\b(?:get|show|fetch|retrieve|find|open|give)\s+(?:me\s+)?([A-Za-z][A-Za-z'-]+(?:\s+[A-Za-z][A-Za-z'-]+)+?)(?=\s+(?:latest|most recent|last|opg|x-?ray|dental|report)|[?.!]*$)",
        )
        for pattern in patterns:
            match = re.search(pattern, original, re.IGNORECASE)
            if match:
                candidate = match.group(1).strip(" \"'.,?!")
                tokens = candidate.casefold().replace("'s", "").replace("’s", "").split()
                if any(t in _NOT_A_NAME for t in tokens):
                    continue
                if candidate.casefold() not in {"the latest", "latest report", "dental report", "a report", "the report"}:
                    result["name"] = candidate
                    break

    # 4. No name found by the patterns above, but a first or last name from the dataset appears ("Open Priya report", "report of Priya").
    #     It is passed on as a NAME so the lookup can say it is ambiguous; it must never be ignored and replaced by
    #     whichever patient happens to be active.
    if not result.get("name"):
        try:
            from .service import load_patients

            words = {w.casefold(): w for w in re.findall(r"[A-Za-z][A-Za-z'-]*", original)}
            tokens = {t for p in load_patients() for t in p.get("name", "").split() if len(t) >= 3}
            hits = [words[t.casefold()] for t in sorted(tokens, key=str.casefold)
                    if t.casefold() in words and t.casefold() not in _NOT_A_NAME | _COMMAND_WORDS]
            if len(hits) == 1:
                result["name"] = hits[0]
        except Exception:
            pass

    # No usable patient identifier/name means we must ask, not guess.
    if not result.get("patient_id") and not result.get("name"):
        return {"needs_patient": "true", **result}

    return result


# ───────────── contextual references: "his previous report", "that patient's OPG", "open it again" ─────────────
# Whole-word only, so "other", "there", "whether", "the other day" and "Hershey" never count as pronouns.
_PRONOUN = re.compile(r"\b(?:he|she|they|him|her|them|his|hers|their|theirs)\b", re.IGNORECASE)
_PATIENT_PHRASE = re.compile(r"\b(?:that|this|the\s+same)\s+patient(?:['’]s)?\b", re.IGNORECASE)
_REPORT_NOUN = re.compile(r"\b(?:reports?|opg|x-?rays?|examinations?|exams?)\b", re.IGNORECASE)
_SEL_PREVIOUS = re.compile(r"\b(?:previous|prior|preceding|before\s+(?:that|this)(?:\s+one)?|last\s+but\s+one)\b", re.IGNORECASE)
_SEL_EARLIER = re.compile(r"\b(?:old|older|earlier|past)\b", re.IGNORECASE)
_SEL_LATEST = re.compile(r"\b(?:latest|last|most\s+recent|newest|recent|current)\b", re.IGNORECASE)
_SEL_ACTIVE = re.compile(r"\b(?:(?:that|this|the\s+same)\s+(?:report|one|opg|examination|exam)|the\s+report)\b", re.IGNORECASE)
_ONE = re.compile(r"\bone\b", re.IGNORECASE)
_HAS_NAME_OR_ID = re.compile(r"\bP\d{3,}\b", re.IGNORECASE)


def parse_contextual_report_reference(text: str, has_active_report: bool = False) -> dict[str, str] | None:
    """Decide whether the sentence REFERS TO a dental report through conversation context.

    Returns {"selector": latest|active|previous|earlier, "report_type": "" | OPG | Dental Examination} or None.
    A pronoun alone is never enough: the sentence must also mention a report (or, with a report already open,
    "the previous one"). It never extracts a name, so nothing here can reach the patient resolver."""
    cleaned = " ".join((text or "").split())
    if not cleaned or _HAS_NAME_OR_ID.search(cleaned):
        return None
    prev, earl = bool(_SEL_PREVIOUS.search(cleaned)), bool(_SEL_EARLIER.search(cleaned))
    late, act = bool(_SEL_LATEST.search(cleaned)), bool(_SEL_ACTIVE.search(cleaned))
    has_selector = prev or earl or late or act
    has_noun = bool(_REPORT_NOUN.search(cleaned)) or (has_active_report and has_selector and bool(_ONE.search(cleaned)))
    if not has_noun:
        return None
    if not (_PRONOUN.search(cleaned) or _PATIENT_PHRASE.search(cleaned) or has_selector):
        return None

    if prev:
        selector = "previous"
    elif earl:
        selector = "earlier"
    elif late:
        selector = "latest"
    elif act:
        selector = "active"
    else:
        selector = "latest"

    report_type = ""
    if re.search(r"\bOPG\b|\bx-?rays?\b", cleaned, re.IGNORECASE):
        report_type = "OPG"
    elif re.search(r"\bdental\s+examination\b|\bexamination\s+report\b", cleaned, re.IGNORECASE):
        report_type = "Dental Examination"
    elif selector == "latest" and re.search(r"\bexam(?:ination)?s?\b", cleaned, re.IGNORECASE):
        report_type = "Dental Examination"  # "their last examination"; with "earlier"/"previous" it is just a noun
    return {"selector": selector, "report_type": report_type}


DICTATION_PATTERNS = (
    r"\b(?:open|launch|go\s+to|switch\s+to)\s+(?:the\s+)?clinical\s+dictation\b",
    r"\bdictat(?:e|ing|ion)\b",
    r"\b(?:create|make|write|start|prepare|record)\s+(?:a\s+|some\s+)?(?:new\s+)?(?:clinical\s+)?(?:draft|note|notes)\b",
    r"\b(?:need\s+to\s+|want\s+to\s+)?(?:prepare|create|draft)\s+(?:a\s+)?(?:patient|clinical)\s+report\b",
)


def is_dictation_intent(text: str) -> bool:
    """Identify natural-language requests that intend to dictate or prepare a clinical draft."""
    cleaned = " ".join((text or "").strip().split()).casefold()
    if not cleaned:
        return False
    # Exclude ordinary requests to retrieve, view, summarize, or download existing reports
    if re.search(
        r"\b(?:show|find|get|fetch|view|download|open|pull|summariz(?:e|ing))\s+(?:me\s+)?(?:the\s+|that\s+|her\s+|his\s+)?(?:latest\s+|recent\s+)?(?:opg|x-?ray|examination)?\s*report\b",
        cleaned,
    ):
        if not re.search(r"\bdictat(?:e|ing|ion)\b", cleaned):
            return False
    for pat in DICTATION_PATTERNS:
        if re.search(pat, cleaned):
            return True
    return False


def is_pdf_intent(text: str) -> bool:
    """Identify requests to download or export a patient report as a PDF."""
    cleaned = " ".join((text or "").strip().split()).casefold()
    if not cleaned:
        return False
    if re.search(r"\bpdf\b", cleaned):
        return True
    if re.search(r"\bdownload\b", cleaned) and any(
        term in cleaned for term in ("report", "reports", "opg", "x-ray", "xray", "examination", "it", "that", "her", "his")
    ):
        return True
    return False


def is_summary_intent(text: str) -> bool:
    """Identify requests to summarize a patient's report."""
    cleaned = " ".join((text or "").strip().split()).casefold()
    return bool(
        re.search(
            r"\bsummariz(?:e|ing|ation)\b|\bgive\s+me\s+a\s+summary\b|\bbrief\s+(?:me\s+on\s+)?(?:the|her|his)\s+report\b",
            cleaned,
        )
    )



# ───────────── inline clinical dictation (AI Assistant) ─────────────
_SITE_TERMS = (
    "molar", "premolar", "incisor", "canine", "tooth", "teeth", "gingiva", "gum", "gums", "mandible", "maxilla",
    "jaw", "palate", "tongue", "cusp", "crown", "root", "pulp", "enamel", "bicuspid", "cuspid", "wisdom",
)
_FINDING_TERMS = (
    "impacted", "impaction", "carious", "caries", "decay", "fractur", "mobile", "mobility", "missing", "erupt", "restor",
    "filling", "inflam", "swollen", "swelling", "bleeding", "recession", "calculus", "plaque", "pocket", "abscess",
    "lesion", "ulcer", "discolou", "cavity", "periapical", "radiolucen", "radiopaque", "sensitive", "tender",
    "crowding", "malposed", "rotated", "tilted", "worn", "attrition", "abrasion", "cracked", "chipped", "stain",
)
_NOT_A_STATEMENT = re.compile(
    r"^\s*(?:please\s+)?(?:show|get|open|find|fetch|pull|download|retrieve|view|read|summari[sz]e|explain|tell|what|what's|whats|how|why|"
    r"can|could|would|should|do|does|did|is|are|will|who|which|where|when|define|describe)\b",
    re.IGNORECASE,
)
_DICTATION_PREFIX = re.compile(r"^\s*(?:clinical\s+)?(?:dictat(?:e|ion|ing)|note)\s*[:\-]\s*(.+)$", re.IGNORECASE | re.DOTALL)


def strip_dictation_prefix(text: str) -> str | None:
    """'Dictate: lower right third molar is impacted' -> 'lower right third molar is impacted' (else None)."""
    m = _DICTATION_PREFIX.match(text or "")
    if m:
        body = " ".join(m.group(1).split())
        if len(body.split()) >= 2:
            return body
    return None


def is_clinical_statement(text: str) -> bool:
    """True for a dictated clinical observation ("Lower right third molar is horizontally impacted").

    Deliberately conservative: it must mention a dental site AND a finding word, must not be a question or a
    command ("show me...", "what is..."), and is never used to decide anything about a patient record.
    """
    cleaned = " ".join((text or "").split())
    words = cleaned.split()
    if not (3 <= len(words) <= 120) or cleaned.endswith("?") or _NOT_A_STATEMENT.match(cleaned):
        return False
    lowered = cleaned.casefold()
    has_site = any(re.search(rf"\b{re.escape(t)}", lowered) for t in _SITE_TERMS)
    has_finding = any(t in lowered for t in _FINDING_TERMS)
    return has_site and has_finding


_EXPLAIN_VERB = re.compile(
    r"\b(?:explain|describe|elaborate(?:\s+on)?|break\s+(?:it\s+)?down|walk\s+me\s+through|tell\s+me\s+what\s+(?:it|this|that|the\s+\w+)\s+means|"
    r"in\s+(?:plain|simple|everyday)\s+(?:english|words|terms|language))\b",
    re.IGNORECASE,
)
_EXPLAIN_SUBJECT = re.compile(r"\b(?:report|reports|findings?|opg|x-?ray|examination|exam|results?)\b", re.IGNORECASE)
_EXPLAIN_PRONOUN = re.compile(r"\b(?:it|this|that|her|his|their|them)\b", re.IGNORECASE)


def is_explain_intent(text: str, has_active_report: bool = False) -> bool:
    """"Explain her report", "Describe the findings", "Explain this in simple English".

    A bare dental-term question ("What are molar teeth?", "Explain impacted teeth") is NOT a report explanation, so it
    still goes to the general assistant. A pronoun-only request needs a report already in the conversation.
    """
    cleaned = " ".join((text or "").strip().split())
    if not cleaned or not _EXPLAIN_VERB.search(cleaned):
        return False
    if _EXPLAIN_SUBJECT.search(cleaned):
        return True
    return bool(has_active_report and _EXPLAIN_PRONOUN.search(cleaned))
