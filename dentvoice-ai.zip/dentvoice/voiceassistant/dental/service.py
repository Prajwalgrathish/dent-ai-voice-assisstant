
"""Dental assistant services using synthetic patient data."""

import json
from pathlib import Path
from typing import Any


DATA_PATH = Path(__file__).with_name("patients.json")


class PatientNotFoundError(Exception):
    """Raised when no patient matches the request."""


class AmbiguousPatientError(Exception):
    """Raised when multiple patients match the request."""

    def __init__(self, message: str, candidates: list[dict[str, Any]]):
        super().__init__(message)
        self.candidates = candidates


def load_patients() -> list[dict[str, Any]]:
    """Load the synthetic patient dataset and validate its structure."""
    try:
        with DATA_PATH.open("r", encoding="utf-8") as file:
            patients = json.load(file)
    except FileNotFoundError as exc:
        raise RuntimeError("patients.json was not found.") from exc
    except json.JSONDecodeError as exc:
        raise RuntimeError("patients.json contains invalid JSON.") from exc

    if not isinstance(patients, list):
        raise ValueError("Patient dataset must be a JSON list.")

    seen_ids = set()

    for patient in patients:
        if not isinstance(patient, dict):
            raise ValueError("Every patient record must be an object.")

        patient_id = patient.get("patient_id")
        name = patient.get("name")

        if not isinstance(patient_id, str) or not patient_id.strip():
            raise ValueError("Every patient must have a patient_id.")

        if patient_id in seen_ids:
            raise ValueError(f"Duplicate patient ID: {patient_id}")

        seen_ids.add(patient_id)

        if not isinstance(name, str) or not name.strip():
            raise ValueError("Every patient must have a name.")

        if not isinstance(patient.get("reports"), list):
            raise ValueError(f"Reports must be a list for {patient_id}.")

        for report in patient.get("reports", []):
            if not isinstance(report, dict):
                raise ValueError(f"Report must be an object for {patient_id}.")
            findings = report.get("findings")
            if findings is not None and not isinstance(findings, list):
                raise ValueError(f"Report findings must be a list for {patient_id}.")

    return patients


def normalize(value: str) -> str:
    """Normalize text for case-insensitive matching."""
    return " ".join(value.casefold().split())


def mask_contact(contact: Any) -> str:
    """Mask a synthetic demo contact identifier."""
    if not isinstance(contact, str) or not contact.strip():
        return "Not provided"

    # Demo identifiers are not real phone numbers.
    if contact.startswith("DEMO-"):
        return "DEMO-••" + contact[-2:]

    # Never expose an unverified contact value.
    return "Contact available only in the authorized patient record"


def candidate_summary(patient: dict[str, Any]) -> dict[str, str]:
    """Return limited details to help distinguish matching demo patients."""
    return {
        "patient_id": str(patient["patient_id"]),
        "name": str(patient["name"]),
        "date_of_birth": str(patient.get("date_of_birth") or "Not provided"),
        "phone_contact": mask_contact(patient.get("phone_contact")),
    }


def list_patient_candidates(name: str) -> list[dict[str, Any]]:
    """Find candidates by full name or first name without choosing silently."""
    query = normalize(name)

    if not query:
        raise PatientNotFoundError("Please provide a patient name.")

    patients = load_patients()

    # Prefer exact full-name matches when they exist.
    exact_matches = [
        patient for patient in patients
        if normalize(patient["name"]) == query
    ]

    if exact_matches:
        matches = exact_matches
    else:
        # A first-name request such as 'Priya' returns every matching Priya.
        matches = [
            patient for patient in patients
            if normalize(patient["name"]).split()[0] == query
        ]

    unique: dict[str, dict[str, Any]] = {}
    for patient in matches:  # one entry per canonical patient ID, never the same patient twice
        unique.setdefault(str(patient["patient_id"]), patient)
    return [candidate_summary(patient) for patient in unique.values()]



def find_patient(
    name: str = "",
    patient_id: str | None = None,
    date_of_birth: str | None = None,
    phone_contact: str | None = None,
) -> dict[str, Any]:
    """Identify one patient only when all supplied identifiers agree."""
    from voiceassistant.patient_resolver import resolve, extract_patient_id

    patients = load_patients()
    query = normalize(name)

    # Normalize spoken patient_id if provided
    pid_extracted = extract_patient_id(patient_id) if patient_id else None
    if patient_id and not pid_extracted:
        pid_extracted = patient_id.strip()

    # If only an ID was supplied, or ID + name was supplied
    if pid_extracted:
        matched_patients = [
            p for p in patients
            if normalize(str(p.get("patient_id", ""))) == normalize(pid_extracted)
        ]
        if not matched_patients:
            raise PatientNotFoundError(
                f"I couldn't find patient ID {pid_extracted}. Would you like to try another name or patient ID?"
            )
        cand = matched_patients[0]
        if query and normalize(cand["name"]) != query and query not in normalize(cand["name"]):
            # Name and ID mismatch
            raise AmbiguousPatientError(
                f"{pid_extracted} belongs to {cand.get('name')}, which doesn't match the name you gave.",
                [candidate_summary(cand)],
            )
        if date_of_birth and cand.get("date_of_birth") != date_of_birth:
            raise PatientNotFoundError("Patient date of birth does not match record.")
        if phone_contact and normalize(str(cand.get("phone_contact", ""))) != normalize(phone_contact):
            raise PatientNotFoundError("Patient contact does not match record.")
        return cand

    # If no ID, resolve by name
    if not query:
        raise PatientNotFoundError("Please provide the patient's full name.")

    if len(query.split()) < 2 and not date_of_birth and not phone_contact:
        raise AmbiguousPatientError("Please provide the patient's full name.", [])

    # Filter candidate pool by secondary identifiers if provided
    pool = patients
    if date_of_birth:
        pool = [p for p in pool if p.get("date_of_birth") == date_of_birth]
        if not pool:
            raise PatientNotFoundError("Patient date of birth does not match any record.")
    if phone_contact:
        pool = [p for p in pool if normalize(str(p.get("phone_contact", ""))) == normalize(phone_contact)]
        if not pool:
            raise PatientNotFoundError("Patient contact does not match any record.")

    # A date of birth / contact that narrows the pool to exactly one patient whose name agrees with what was
    # said ("Priya" + 1988-11-03) identifies that patient; the name alone would not.
    if (date_of_birth or phone_contact) and len(pool) == 1:
        only = pool[0]
        if set(query.split()) <= set(normalize(only["name"]).split()):
            return only

    # Use deterministic patient resolver on the filtered pool
    res = resolve(pool, name=query, allow_unique_partial=False)
    if res.status == "matched":
        return res.patient
    elif res.status == "ambiguous":
        cands = [candidate_summary(p) for p in res.candidates]
        raise AmbiguousPatientError(
            res.message or "Multiple patients match. Please provide the patient ID or date of birth.",
            cands,
        )
    elif res.status in ("needs_confirmation", "not_found", "needs_repeat"):
        if res.candidates:
            cands = [candidate_summary(p) for p in res.candidates]
            raise AmbiguousPatientError(res.message, cands)
        raise PatientNotFoundError(
            res.message or f"I couldn't find a patient named {name.strip()}."
        )

    raise PatientNotFoundError(f"No patient matched the name {name.strip()}.")

def get_latest_report(
    name: str = "",
    report_type: str | None = None,
    patient_id: str | None = None,
    date_of_birth: str | None = None,
    phone_contact: str | None = None,
) -> dict[str, Any]:
    """Retrieve the latest report for an unambiguously identified patient."""
    patient = find_patient(
        name=name,
        patient_id=patient_id,
        date_of_birth=date_of_birth,
        phone_contact=phone_contact,
    )

    reports = patient["reports"]

    if report_type:
        requested_type = normalize(report_type)
        reports = [
            report for report in reports
            if normalize(str(report.get("type", ""))) == requested_type
        ]

    if not reports:
        raise PatientNotFoundError(
            f"No matching report was found for {patient['name']}."
        )

    dated_reports = [
        report for report in reports
        if isinstance(report.get("date"), str) and report["date"].strip()
    ]

    if not dated_reports:
        raise PatientNotFoundError(
            "The patient's reports do not contain valid dates."
        )

    latest = max(dated_reports, key=lambda report: report["date"])

    return {
        "patient_id": patient["patient_id"],
        "patient_name": patient["name"],
        "report": latest,
        "source": {
            "report_id": latest.get("report_id"),
            "date": latest.get("date"),
            "type": latest.get("type"),
        },
        "requires_clinician_review": True,
        "synthetic_data": True,
    }



# ───────────── report history and contextual selection (additive; get_latest_report is unchanged) ─────────────
def get_report_history(patient_id: str) -> dict[str, Any]:
    """Every report on file for ONE patient, newest first. The key is the canonical patient ID only."""
    patient = find_patient(patient_id=patient_id)
    reports = [r for r in patient.get("reports") or [] if isinstance(r, dict)]
    reports.sort(key=lambda r: (str(r.get("date") or ""), str(r.get("report_id") or "")), reverse=True)
    return {
        "patient_id": patient["patient_id"],
        "patient_name": patient["name"],
        "reports": reports,
        "requires_clinician_review": True,
        "synthetic_data": True,
    }


def select_report(
    reports: list[dict[str, Any]],
    selector: str = "latest",
    report_type: str = "",
    active_report_id: str | None = None,
) -> dict[str, Any]:
    """Pick a report from ONE patient's history (newest first). Pure; never substitutes another type.

    selector: latest | active | previous | earlier.  Returns {"status", "report", "options"} where status is
    ok | none (no reports) | no_type (that type is not on file) | no_earlier | ask (several older reports)."""
    if not reports:
        return {"status": "none", "report": None, "options": []}
    pool = reports
    if report_type:
        want = normalize(report_type)
        pool = [r for r in reports if normalize(str(r.get("type", ""))) == want]
        if not pool:
            return {"status": "no_type", "report": None, "options": []}
    active = next((r for r in reports if r.get("report_id") == active_report_id), None) if active_report_id else None
    if selector == "active" and active and (not report_type or active in pool):
        return {"status": "ok", "report": active, "options": []}
    if selector in ("latest", "active"):
        return {"status": "ok", "report": pool[0], "options": []}
    anchor = active or reports[0]
    key = lambda r: (str(r.get("date") or ""), str(r.get("report_id") or ""))  # noqa: E731
    older = [r for r in pool if key(r) < key(anchor)]
    if not older:
        return {"status": "no_earlier", "report": None, "options": [], "anchor": anchor}
    if selector == "previous" or len(older) == 1:
        return {"status": "ok", "report": older[0], "options": []}
    return {"status": "ask", "report": None, "options": older}
