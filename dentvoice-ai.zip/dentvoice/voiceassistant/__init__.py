"""Voice AI assistant core (English-first). Phase 2: minimal STT -> LLM -> TTS pipeline."""

__version__ = "0.2.0"
