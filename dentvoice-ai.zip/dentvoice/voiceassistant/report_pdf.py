"""
Real PDF generation (ReportLab) + deterministic report comparison.
In-memory only: returns bytes. Nothing is written to disk.

patient: {"patient_id","name", optional "date_of_birth"}
report : {"report_id","date", optional "type","clinician"/"dentist","findings"(list|str),
          "anatomical_sites"/"tooth"(list|str),"assessment"/"diagnosis","recommendations"(list|str),"patient_id"}
Map your own keys with `_FIELD_ALIASES` below if they differ.
"""
from __future__ import annotations

import os
from datetime import datetime
from io import BytesIO
from typing import Mapping, Optional, Sequence
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

_FIELD_ALIASES = {
    "findings": ("findings", "clinical_findings"),
    "sites": ("anatomical_sites", "anatomical_site", "tooth", "teeth", "tooth_numbers"),
    "assessment": ("assessment", "diagnosis", "impression"),
    "recommendations": ("recommendations", "treatment_recommendations", "treatment"),
    "clinician": ("clinician", "dentist", "dentist_id", "clinician_id"),
}
NOT_DOC = "Not documented in this report"

_FONT_CANDIDATES = [
    ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
    ("C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/segoeuib.ttf"),
    ("/Library/Fonts/Arial.ttf", "/Library/Fonts/Arial Bold.ttf"),
]
_font_cache: Optional[tuple] = None


def _fonts() -> tuple:
    """(regular, bold, unicode_ok). Falls back to built-in Helvetica (Latin-1 only) if no TTF is found."""
    global _font_cache
    if _font_cache:
        return _font_cache
    for reg, bold in _FONT_CANDIDATES:
        if os.path.exists(reg) and os.path.exists(bold):
            try:
                pdfmetrics.registerFont(TTFont("DV-Regular", reg))
                pdfmetrics.registerFont(TTFont("DV-Bold", bold))
                pdfmetrics.registerFontFamily("DV-Regular", normal="DV-Regular", bold="DV-Bold",
                                              italic="DV-Regular", boldItalic="DV-Bold")   # makes <b>/<i> work
                _font_cache = ("DV-Regular", "DV-Bold", True)
                return _font_cache
            except Exception:
                continue
    _font_cache = ("Helvetica", "Helvetica-Bold", False)
    return _font_cache


def _first(d: Mapping, key: str):
    for k in _FIELD_ALIASES[key]:
        v = d.get(k)
        if v not in (None, "", [], ()):
            return v
    return None


def _as_list(v) -> list:
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x).strip() for x in v if str(x).strip()]
    return [str(v).strip()] if str(v).strip() else []


def compare_reports(old: Mapping, new: Mapping) -> dict:
    """Deterministic, text-based comparison. No inference: only what both reports literally contain."""
    out = {"old_report_id": old.get("report_id"), "new_report_id": new.get("report_id"),
           "old_date": old.get("date"), "new_date": new.get("date")}
    for key in ("findings", "sites", "recommendations"):
        a, b = _as_list(_first(old, key)), _as_list(_first(new, key))
        na, nb = {x.lower(): x for x in a}, {x.lower(): x for x in b}
        out[key] = {"added": [nb[k] for k in nb if k not in na],
                    "removed": [na[k] for k in na if k not in nb],
                    "unchanged": [nb[k] for k in nb if k in na]}
    out["assessment"] = {"old": _first(old, "assessment"), "new": _first(new, "assessment")}
    return out


class _Numbered(canvas.Canvas):
    def __init__(self, *a, footer_left="", font="Helvetica", **k):
        super().__init__(*a, **k)
        self._saved, self._fl, self._font = [], footer_left, font

    def showPage(self):
        self._saved.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        n = len(self._saved)
        for st in self._saved:
            self.__dict__.update(st)
            self.setFont(self._font, 8)
            self.setFillColor(colors.HexColor("#5B6B82"))
            self.drawString(18 * mm, 10 * mm, self._fl)
            self.drawRightString(A4[0] - 18 * mm, 10 * mm, f"Page {self._pageNumber} of {n}")
            super().showPage()
        super().save()


def build_report_pdf(patient: Mapping, reports: Sequence[Mapping], *, kind: str = "report",
                     ai_summary: Optional[str] = None, comparison: Optional[dict] = None,
                     title: Optional[str] = None, synthetic: bool = True,
                     created: Optional[datetime] = None) -> bytes:
    """kind: 'report' (1+ reports, newest first) | 'summary' (needs ai_summary) | 'comparison' (exactly 2 reports)."""
    pid, pname = str(patient.get("patient_id") or "").strip(), str(patient.get("name") or "").strip()
    if not pid or not pname:
        raise ValueError("patient needs patient_id and name")
    if not reports:
        raise ValueError("no reports to export")
    for r in reports:
        if not r.get("report_id"):
            raise ValueError("every report needs a report_id")
        if r.get("patient_id") not in (None, "", pid):      # hard stop: never mix patients
            raise ValueError(f"report {r.get('report_id')} belongs to a different patient")
    if kind == "summary" and not (ai_summary or "").strip():
        raise ValueError("summary PDF needs ai_summary text")
    if kind == "comparison":
        if len(reports) != 2:
            raise ValueError("comparison needs exactly two reports")
        comparison = comparison or compare_reports(*sorted(reports, key=lambda r: str(r.get("date", ""))))

    reg, bold, uni = _fonts()

    def T(x) -> str:
        s = str(x)
        if not uni:
            s = s.encode("latin-1", "replace").decode("latin-1")
        return escape(s).replace("\n", "<br/>")

    ss = getSampleStyleSheet()
    navy, teal = colors.HexColor("#0B1F3A"), colors.HexColor("#0F9D8E")
    st_t = ParagraphStyle("t", parent=ss["Title"], fontName=bold, fontSize=18, textColor=navy, alignment=0, spaceAfter=4)
    st_h = ParagraphStyle("h", parent=ss["Heading2"], fontName=bold, fontSize=12, textColor=teal, spaceBefore=10, spaceAfter=3)
    st_b = ParagraphStyle("b", parent=ss["BodyText"], fontName=reg, fontSize=10, leading=14)
    st_i = ParagraphStyle("i", parent=st_b, textColor=colors.HexColor("#6B7A90"))
    st_s = ParagraphStyle("s", parent=st_b, fontSize=8.5, leading=11, textColor=colors.HexColor("#5B6B82"))

    created = created or datetime.now()
    default_title = {"report": "Dental Report", "summary": "Dental Report Summary", "comparison": "Dental Report Comparison"}[kind]
    story = [Paragraph(T(title or default_title), st_t)]
    meta = [["Patient", T(pname)], ["Patient ID", T(pid)]]
    if patient.get("date_of_birth"):
        meta.append(["Date of birth", T(patient["date_of_birth"])])
    meta.append(["Created", created.strftime("%Y-%m-%d %H:%M")])
    tbl = Table([[Paragraph(f"<b>{a}</b>", st_b), Paragraph(b, st_b)] for a, b in meta], colWidths=[35 * mm, 120 * mm])
    tbl.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#D5DCE6")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [tbl, Spacer(1, 6)]
    if synthetic:
        story.append(Paragraph("SYNTHETIC DEMO DATA: not a real patient record.", st_s))

    def listing(items):
        return [Paragraph("• " + T(x), st_b) for x in items] or [Paragraph(NOT_DOC, st_i)]

    def report_block(r):
        parts = [Paragraph(T(f"Report {r['report_id']}  |  {r.get('date') or 'date not documented'}"), st_h)]
        info = [("Type", r.get("type")), ("Clinician", _first(r, "clinician"))]
        for lab, v in info:
            parts.append(Paragraph(f"<b>{lab}:</b> " + (T(v) if v else f"<i>{NOT_DOC}</i>"), st_b))
        for lab, key in (("Clinical findings", "findings"), ("Anatomical sites / teeth", "sites"), ("Recommendations (as documented)", "recommendations")):
            parts.append(Paragraph(f"<b>{lab}</b>", st_b))
            parts += listing(_as_list(_first(r, key)))
        a = _first(r, "assessment")
        parts.append(Paragraph("<b>Assessment</b>", st_b))
        parts.append(Paragraph(T(a) if a else NOT_DOC, st_b if a else st_i))
        return parts

    if kind in ("summary",):
        ids = ", ".join(f"{r['report_id']} ({r.get('date', 'no date')})" for r in reports)
        box = Table([[Paragraph(f"<b>AI-GENERATED DRAFT: requires clinician review.</b><br/>Source report(s): {T(ids)}", st_b)]], colWidths=[155 * mm])
        box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#E0A800")), ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF7E0")), ("PADDING", (0, 0), (-1, -1), 6)]))
        story += [Spacer(1, 8), box, Paragraph("Summary", st_h), Paragraph(T(ai_summary), st_b)]

    if kind == "comparison":
        c = comparison
        story.append(Paragraph(T(f"Comparing {c['old_report_id']} ({c.get('old_date')}) with {c['new_report_id']} ({c.get('new_date')})"), st_h))
        story.append(Paragraph("Text comparison of the documented entries only; no clinical interpretation is added.", st_s))
        for lab, key in (("Clinical findings", "findings"), ("Anatomical sites / teeth", "sites"), ("Recommendations", "recommendations")):
            story.append(Paragraph(f"<b>{lab}</b>", st_b))
            for tag, k in (("New in later report", "added"), ("No longer listed", "removed"), ("In both", "unchanged")):
                for x in c[key][k]:
                    story.append(Paragraph(f"• <b>{tag}:</b> {T(x)}", st_b))
            if not any(c[key].values()):
                story.append(Paragraph(NOT_DOC, st_i))
        a = c["assessment"]
        story.append(Paragraph("<b>Assessment</b>", st_b))
        story.append(Paragraph(T(f"Earlier: {a['old'] or NOT_DOC}  |  Later: {a['new'] or NOT_DOC}"), st_b))

    if kind in ("report", "comparison"):
        for r in sorted(reports, key=lambda r: str(r.get("date", "")), reverse=True):
            story.extend(report_block(r))
    elif kind == "summary":
        story.append(Paragraph("Source report(s)", st_h))
        for r in sorted(reports, key=lambda r: str(r.get("date", "")), reverse=True):
            story.extend(report_block(r))

    story += [Spacer(1, 14), Paragraph("Prepared from the stored record. This document is not signed, approved or certified by any clinician.", st_s)]
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=18 * mm,
                            title=f"{default_title} - {pid}", author="DentVoice AI")
    foot = f"{pid} | generated {created.strftime('%Y-%m-%d')}"
    doc.build(story, canvasmaker=lambda *a, **k: _Numbered(*a, footer_left=foot, font=reg, **k))
    return buf.getvalue()
