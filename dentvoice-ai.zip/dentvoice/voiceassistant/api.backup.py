"""FastAPI layer. Requires: pip install -r requirements-api.txt

Run:  uvicorn voiceassistant.api:create_app --factory --port 8000

NOTE: this module was written without FastAPI being installable in the authoring environment,
so it has only been syntax-checked there. Run tests/test_api.py on your machine.
"""

import base64
import logging
import uuid
from pathlib import Path
from typing import Literal, Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from pydantic import BaseModel, Field

from .audio import ALLOWED_EXTENSIONS
from .config import Settings
from .errors import VoiceAssistantError
from .factory import build_pipeline
from .models import TurnResult
from .pipeline import VoicePipeline

log = logging.getLogger(__name__)
_STATUS = {"input": 422, "audio": 422, "stt": 500, "llm": 502, "tts": 500, "config": 500}


class TurnRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    input_mode: Literal["typed", "speech"] = "typed"  # "speech" = text already came from /v1/stt


class TranscriptOut(BaseModel):
    text: str
    confidence: Optional[float] = None
    low_confidence: bool = False
    provider: str = ""


class TurnResponse(BaseModel):
    input_mode: str
    user_text: str
    transcript: Optional[TranscriptOut] = None
    reply_text: str
    tts_engine: Optional[str] = None
    audio_wav_base64: Optional[str] = None  # None if TTS failed; reply_text is still valid
    tts_error: Optional[str] = None


def _fail(stage: str, message: str, status: Optional[int] = None):
    return HTTPException(status_code=status or _STATUS.get(stage, 500), detail={"stage": stage, "message": message})


def _to_response(pipeline: VoicePipeline, result: TurnResult) -> TurnResponse:
    if result.error:
        raise _fail(result.error.stage, result.error.message)
    audio_b64 = None
    if result.audio_path:
        try:
            audio_b64 = base64.b64encode(Path(result.audio_path).read_bytes()).decode("ascii")
        finally:
            pipeline.cleanup(result)
    t = result.transcript
    return TurnResponse(
        input_mode=result.input_mode,
        user_text=result.user_text,
        transcript=TranscriptOut(text=t.text, confidence=t.confidence, low_confidence=t.low_confidence, provider=t.provider)
        if t
        else None,
        reply_text=result.reply_text,
        tts_engine=result.tts_engine,
        audio_wav_base64=audio_b64,
        tts_error=result.tts_error.message if result.tts_error else None,
    )


def _save_upload(upload: UploadFile, settings: Settings) -> Path:
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise _fail("audio", "Unsupported audio format.", 415)
    dest = settings.tmp_dir / f"upload-{uuid.uuid4().hex}{suffix}"  # server-chosen name, never the client's
    size = 0
    try:
        with open(dest, "wb") as fh:
            while chunk := upload.file.read(1024 * 1024):
                size += len(chunk)
                if size > settings.max_audio_bytes:
                    raise _fail("audio", "The audio file is too large.", 413)
                fh.write(chunk)
    except BaseException:
        dest.unlink(missing_ok=True)
        raise
    return dest


def create_app(pipeline: Optional[VoicePipeline] = None) -> FastAPI:
    if pipeline is None:
        pipeline = build_pipeline(Settings.from_env(dotenv_path=".env"))
    settings = pipeline.settings
    app = FastAPI(title="Voice Assistant API", version="0.2.0")

    @app.get("/health")
    def health():
        return {"status": "ok", "stt": pipeline.stt.name, "llm": pipeline.llm.name, "tts": pipeline.tts.name}

    @app.post("/v1/turn", response_model=TurnResponse)
    def turn(req: TurnRequest):
        """Text in -> reply (+ spoken audio). input_mode='typed' means no speech recognition was used."""
        return _to_response(pipeline, pipeline.respond(req.text, req.input_mode))

    @app.post("/v1/stt", response_model=TranscriptOut)
    def stt(file: UploadFile = File(...)):
        """Audio in -> transcript only, so the client can show/edit it before calling /v1/turn."""
        path = _save_upload(file, settings)
        try:
            t = pipeline.transcribe(path)
        except VoiceAssistantError as exc:
            raise _fail(exc.stage, exc.user_message) from None
        finally:
            path.unlink(missing_ok=True)
        return TranscriptOut(text=t.text, confidence=t.confidence, low_confidence=t.low_confidence, provider=t.provider)

    @app.post("/v1/turn/audio", response_model=TurnResponse)
    def turn_audio(file: UploadFile = File(...)):
        """Audio in -> STT -> LLM -> TTS in one call."""
        path = _save_upload(file, settings)
        try:
            result = pipeline.run_audio(path)
        finally:
            path.unlink(missing_ok=True)
        return _to_response(pipeline, result)

    return app
