"""Turn-based voice pipeline: audio -> validate -> STT -> LLM -> TTS.

Failure policy:
  * Fatal problems (bad input, STT failure, LLM failure) set `result.error`; there is no reply.
  * A TTS failure is NOT fatal: `result.reply_text` is kept and `result.tts_error` is set.
No exception from a provider escapes; users only ever see `user_message` strings.
"""

from __future__ import annotations

import logging
import os
import uuid
from pathlib import Path
from .dental.report_intent import parse_report_request
from .dental.service import (
    get_latest_report,
    AmbiguousPatientError,
    PatientNotFoundError,
)
from .audio import concat_wavs, validate_audio_file
from .config import Settings
from .errors import STTError, VoiceAssistantError
from .models import StageError, Transcript, TurnResult
from .providers.base import LLMProvider, STTProvider, TTSProvider
from .response import chunk_text
from .speech_cleaner import clean_text_for_speech

log = logging.getLogger(__name__)
MAX_HISTORY_TURNS = 10


class VoicePipeline:
    def __init__(self, stt: STTProvider, llm: LLMProvider, tts: TTSProvider, settings: Settings):
        self.stt, self.llm, self.tts, self.settings = stt, llm, tts, settings
        settings.tmp_dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(settings.tmp_dir, 0o700)  # no-op on Windows; per-user temp dir there
        except OSError:
            pass

    # -- speech input ---------------------------------------------------
    def transcribe(self, audio_path: str | Path) -> Transcript:
        """Validate and transcribe audio. Raises VoiceAssistantError (with a safe user_message)."""
        s = self.settings
        path = validate_audio_file(audio_path, max_bytes=s.max_audio_bytes, max_seconds=s.max_audio_seconds)
        try:
            transcript = self.stt.transcribe(path, s.language)
        except VoiceAssistantError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.exception("Unexpected STT failure")
            raise STTError(
                f"unexpected STT failure: {type(exc).__name__}", user_message="Speech recognition failed unexpectedly."
            ) from exc
        if not transcript.text.strip():
            raise STTError(
                "no speech detected",
                user_message="No speech was detected. Please try again, or use typed input.",
            )
        return transcript

    # -- text -> reply -> speech ---------------------------------------
    def respond(
        self,
        text: str,
        input_mode: str = "typed",
        transcript: Transcript | None = None,
        history: list[dict[str, str]] | None = None,
    ) -> TurnResult:
        """`history` = earlier user/assistant turns (oldest first) so follow-up questions keep their context."""
        result = TurnResult(input_mode=input_mode, transcript=transcript)
        cleaned = (text or "").strip()
        if not cleaned:
            result.error = StageError("input", "Nothing to send: the message is empty.")
            return result
        if len(cleaned) > self.settings.max_input_chars:
            result.error = StageError(
                "input", f"The message is too long (limit {self.settings.max_input_chars} characters)."
            )
            return result
        result.user_text = cleaned

        # Handle dental report requests directly through the dental service.
        report_request = parse_report_request(cleaned)

        if report_request is not None:
            if report_request.get("needs_patient") == "true":
                result.reply_text = (
                    "Which patient do you mean? Please provide the patient's "
                    "full name or patient ID."
                )
                self._speak(result)
                return result

            try:
                data = get_latest_report(
                    name=report_request.get("name", ""),
                    patient_id=report_request.get("patient_id"),
                    date_of_birth=report_request.get("date_of_birth"),
                    report_type=report_request.get("report_type"),
                )
            except AmbiguousPatientError:
                result.reply_text = (
                    "I found multiple matching patients. Please provide "
                    "the patient's ID or date of birth so I can identify "
                    "the correct record."
                )
                self._speak(result)
                return result
            except PatientNotFoundError:
                result.reply_text = (
                    "I couldn't find a matching patient or report. "
                    "Please check the patient details and report type."
                )
                self._speak(result)
                return result
            except Exception:
                log.exception("Dental report retrieval failed")
                result.reply_text = (
                    "I couldn't retrieve the dental report right now."
                )
                self._speak(result)
                return result

            report = data["report"]
            findings = report.get("findings", [])
            findings_text = "; ".join(str(item) for item in findings)
            report_type = report.get("type", "Dental report")

            result.reply_text = (
                f"Latest {report_type} for {data['patient_name']}. "
                f"Patient ID: {data['patient_id']}. "
                f"Report date: {report.get('date', 'Unknown')}. "
                f"Findings: {findings_text or 'No findings recorded'}. "
                f"Impression: {report.get('impression', 'Not recorded')}. "
                "This is synthetic demonstration data. "
                "Clinician review is required."
            )
            self._speak(result)
            return result


        messages = [{"role": "system", "content": self.settings.system_prompt}]
        for turn in (history or [])[-MAX_HISTORY_TURNS:]:
            role, content = turn.get("role"), (turn.get("content") or "").strip()
            if role in ("user", "assistant") and content:
                messages.append({"role": role, "content": content[: self.settings.max_input_chars]})
        messages.append({"role": "user", "content": cleaned})
        try:
            reply = self.llm.complete(messages)
        except VoiceAssistantError as exc:
            log.warning("LLM failed: %s", exc)
            result.error = StageError(exc.stage, exc.user_message)
            return result
        except Exception as exc:  # noqa: BLE001
            log.exception("Unexpected LLM failure")
            result.error = StageError("llm", "The language model failed unexpectedly.")
            return result

        reply = (reply or "").strip()
        if not reply:
            result.error = StageError("llm", "The language model returned an empty response.")
            return result
        result.reply_text = reply
        self._speak(result)
        return result

    def speak_text(self, text: str, input_mode: str = "typed") -> TurnResult:
        """Synthesize `text` only (no LLM). TTS failure is non-fatal: see `result.tts_error`."""
        result = TurnResult(input_mode=input_mode, user_text="", reply_text=text)
        self._speak(result)
        return result

    # -- convenience entry points ----------------------------------------
    def run_text(self, text: str) -> TurnResult:
        """Typed input. Speech recognition is NOT used; result.input_mode == 'typed'."""
        return self.respond(text, "typed")

    def run_audio(self, audio_path: str | Path) -> TurnResult:
        """Audio file -> STT -> LLM -> TTS in one call (no transcript review step)."""
        try:
            transcript = self.transcribe(audio_path)
        except VoiceAssistantError as exc:
            return TurnResult(input_mode="speech", error=StageError(exc.stage, exc.user_message))
        return self.respond(transcript.text, "speech", transcript)

    def cleanup(self, result: TurnResult) -> None:
        """Delete the generated audio file once it is no longer needed."""
        if result.audio_path:
            Path(result.audio_path).unlink(missing_ok=True)
            result.audio_path = None

    # -- internals --------------------------------------------------------
    def _speak(self, result: TurnResult) -> None:
        speech_text = clean_text_for_speech(result.reply_text)
        chunks = chunk_text(speech_text, self.settings.tts_max_chars)
        if not chunks:
            return
        tmp = self.settings.tmp_dir
        final = tmp / f"reply-{uuid.uuid4().hex}.wav"
        parts: list[Path] = []
        try:
            if len(chunks) == 1:
                self.tts.synthesize(chunks[0], final, self.settings.language)
            else:
                for chunk in chunks:
                    part = tmp / f"chunk-{uuid.uuid4().hex}.wav"
                    parts.append(part)
                    self.tts.synthesize(chunk, part, self.settings.language)
                concat_wavs(parts, final)
        except VoiceAssistantError as exc:
            log.warning("TTS failed: %s", exc)
            final.unlink(missing_ok=True)
            result.tts_error = StageError("tts", exc.user_message)
            return
        except Exception:  # noqa: BLE001
            log.exception("Unexpected TTS failure")
            final.unlink(missing_ok=True)
            result.tts_error = StageError("tts", "Speech synthesis failed unexpectedly.")
            return
        finally:
            for part in parts:
                part.unlink(missing_ok=True)
        result.audio_path = final
        result.tts_engine = getattr(self.tts, "last_used", None) or self.tts.name
