"""Audio file validation and WAV helpers (standard library only)."""

from __future__ import annotations

import sys
import wave
from array import array
from pathlib import Path
from typing import Iterable

from .errors import AudioValidationError, TTSError

ALLOWED_EXTENSIONS = {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".webm"}


def _sniff(header: bytes) -> str | None:
    """Guess the container from magic bytes (do not trust the file extension)."""
    if header[:4] == b"RIFF" and header[8:12] == b"WAVE":
        return ".wav"
    if header[:4] == b"fLaC":
        return ".flac"
    if header[:4] == b"OggS":
        return ".ogg"
    if header[:3] == b"ID3" or (len(header) >= 2 and header[0] == 0xFF and (header[1] & 0xE0) == 0xE0):
        return ".mp3"
    if header[4:8] == b"ftyp":
        return ".m4a"
    if header[:4] == b"\x1a\x45\xdf\xa3":
        return ".webm"
    return None


def validate_audio_file(
    path: str | Path,
    *,
    max_bytes: int,
    max_seconds: float,
    min_seconds: float = 0.1,
    silence_peak: int = 200,
) -> Path:
    """Validate an audio file before it is sent to STT. Returns the resolved path.

    Checks: exists, allowed extension, non-empty, size limit, magic bytes match the
    extension. For WAV files also: readable, duration limits, and (16-bit PCM only)
    not silent. Non-WAV formats are not decoded here; the STT engine is the judge.
    """
    try:
        p = Path(path).resolve(strict=True)
    except (OSError, RuntimeError):
        raise AudioValidationError("audio file not found", user_message="Audio file not found.") from None
    if not p.is_file():
        raise AudioValidationError("not a file", user_message="Audio path is not a file.")

    ext = p.suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise AudioValidationError(
            f"unsupported extension {ext!r}",
            user_message=f"Unsupported audio format. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}.",
        )

    size = p.stat().st_size
    if size == 0:
        raise AudioValidationError("empty file", user_message="The audio file is empty.")
    if size > max_bytes:
        raise AudioValidationError(
            f"file too large: {size} > {max_bytes}",
            user_message=f"The audio file is too large (limit {max_bytes // 1_000_000} MB).",
        )

    with p.open("rb") as fh:
        header = fh.read(16)
    sniffed = _sniff(header)
    if sniffed != ext:
        raise AudioValidationError(
            f"content looks like {sniffed!r} but extension is {ext!r}",
            user_message="The file content does not match its audio format, or it is not valid audio.",
        )

    if ext == ".wav":
        _validate_wav(p, max_seconds=max_seconds, min_seconds=min_seconds, silence_peak=silence_peak)
    return p


def _validate_wav(p: Path, *, max_seconds: float, min_seconds: float, silence_peak: int) -> None:
    try:
        with wave.open(str(p), "rb") as w:
            frames, rate, width = w.getnframes(), w.getframerate(), w.getsampwidth()
            if rate <= 0:
                raise AudioValidationError("bad sample rate", user_message="The WAV file is invalid.")
            duration = frames / rate
            if duration > max_seconds:
                raise AudioValidationError(
                    f"too long: {duration:.1f}s",
                    user_message=f"The recording is too long (limit {max_seconds:g} seconds).",
                )
            if duration < min_seconds:
                raise AudioValidationError(
                    f"too short: {duration:.2f}s", user_message="The recording is too short. Please try again."
                )
            raw = w.readframes(frames) if width == 2 else b""
    except (wave.Error, EOFError):
        raise AudioValidationError(
            "unreadable WAV", user_message="The WAV file could not be read. It may be corrupted."
        ) from None

    if width == 2:
        samples = array("h")
        samples.frombytes(raw[: len(raw) // 2 * 2])
        if sys.byteorder == "big":
            samples.byteswap()
        peak = max((abs(s) for s in samples), default=0)
        if peak < silence_peak:
            raise AudioValidationError(
                f"silent audio (peak {peak})",
                user_message="The recording is silent or too quiet. Check your microphone and try again.",
            )


def wav_duration(path: str | Path) -> float:
    with wave.open(str(path), "rb") as w:
        return w.getnframes() / float(w.getframerate())


def wav_bytes_duration(data: bytes | None) -> float:
    """Calculate duration in seconds of WAV audio bytes in memory."""
    if not data or len(data) < 44:
        return 0.0
    try:
        import io
        with wave.open(io.BytesIO(data), "rb") as w:
            rate = w.getframerate()
            return w.getnframes() / float(rate) if rate > 0 else 0.0
    except Exception:
        return max(0.5, (len(data) - 44) / 32000.0) if len(data) > 44 else 0.0


def concat_wavs(paths: Iterable[Path], out_path: Path) -> None:
    """Join WAV files with identical format into one (used for chunked TTS)."""
    paths = list(paths)
    if not paths:
        raise TTSError("no audio chunks to join", user_message="Speech synthesis produced no audio.")
    params = None
    try:
        with wave.open(str(out_path), "wb") as out:
            for p in paths:
                with wave.open(str(p), "rb") as w:
                    current = (w.getnchannels(), w.getsampwidth(), w.getframerate())
                    if params is None:
                        params = current
                        out.setnchannels(current[0])
                        out.setsampwidth(current[1])
                        out.setframerate(current[2])
                    elif current != params:
                        raise TTSError(
                            "WAV chunks have different formats",
                            user_message="Speech synthesis produced inconsistent audio.",
                        )
                    out.writeframes(w.readframes(w.getnframes()))
    except (wave.Error, EOFError):
        raise TTSError("could not join WAV chunks", user_message="Speech synthesis produced invalid audio.") from None
