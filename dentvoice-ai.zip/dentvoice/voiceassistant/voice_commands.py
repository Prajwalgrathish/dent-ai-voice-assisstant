"""Small, deterministic voice-workflow helpers shared by the frontend and the tests.

* greeting_for_hour()   - the greeting for the doctor's LOCAL hour (never a hard-coded single greeting).
* is_listen_command()   - "Listen to me" / "Start listening" / "Listen" (+ polite wrappers) as a whole utterance.

Nothing here talks to a model or a browser, so it is fully unit-testable.
"""

from __future__ import annotations

import re

MORNING_START, AFTERNOON_START, EVENING_START, NIGHT_START = 5, 12, 17, 21


def day_part(hour: int) -> str:
    """morning 05-11, afternoon 12-16, evening 17-20, night 21-04."""
    h = int(hour) % 24
    if MORNING_START <= h < AFTERNOON_START:
        return "morning"
    if AFTERNOON_START <= h < EVENING_START:
        return "afternoon"
    if EVENING_START <= h < NIGHT_START:
        return "evening"
    return "night"


_GREETINGS = {
    "morning": "Good morning, Doctor. Welcome to DentVoice AI. How can I help you?",
    "afternoon": "Good afternoon, Doctor. How can I help you?",
    "evening": "Good evening, Doctor. How can I help you?",
    "night": "Hello, Doctor. How can I help you tonight?",
}


def greeting_for_hour(hour: int) -> str:
    return _GREETINGS[day_part(hour)]


# Whole-utterance match only: "listen to the patient history" or "I will listen to me later" must not match.
_LISTEN = re.compile(
    r"""^\s*
    (?:(?:hey|ok(?:ay)?|hi)[\s,]+)?
    (?:(?:dent\s?voice(?:\s+ai)?)[\s,]+)?
    (?:please[\s,]+)?
    (?:
        listen(?:\s+to\s+me)?
      | start\s+listening
      | resume\s+listening
      | begin\s+listening
      | keep\s+listening
      | wake\s+up
    )
    (?:[\s,]+(?:please|now|doctor|dentvoice(?:\s+ai)?))*
    [\s.!?]*$""",
    re.IGNORECASE | re.VERBOSE,
)


def is_listen_command(text: str | None) -> bool:
    """True only when the WHOLE utterance is a request to (re)start listening."""
    return bool(text and _LISTEN.match(text))
