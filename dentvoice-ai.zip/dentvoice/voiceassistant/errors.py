"""Exception types.

Every error carries a `user_message` that is safe to show to the user (no stack
traces, no keys, no file-system details). The regular `str(error)` is for logs.
"""

from __future__ import annotations


class VoiceAssistantError(Exception):
    stage = "app"

    def __init__(self, message: str, *, user_message: str | None = None):
        super().__init__(message)
        self.user_message = user_message or message


class ConfigError(VoiceAssistantError):
    stage = "config"


class InputError(VoiceAssistantError):
    stage = "input"


class AudioValidationError(VoiceAssistantError):
    stage = "audio"


class STTError(VoiceAssistantError):
    stage = "stt"


class LLMError(VoiceAssistantError):
    stage = "llm"
    retryable = False


class LLMTimeoutError(LLMError):
    retryable = True


class LLMRateLimitError(LLMError):
    retryable = True

    def __init__(self, message: str, *, user_message: str | None = None, retry_after: float | None = None):
        super().__init__(message, user_message=user_message)
        self.retry_after = retry_after


class LLMServerError(LLMError):
    retryable = True


class LLMConnectionError(LLMError):
    """Cannot reach the server at all (not retried: usually 'Ollama is not running')."""


class LLMResponseError(LLMError):
    """Server answered, but the body was empty or malformed (not retried)."""


class TTSError(VoiceAssistantError):
    stage = "tts"
