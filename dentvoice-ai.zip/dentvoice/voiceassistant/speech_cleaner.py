"""Utility to clean and normalize text for speech synthesis (TTS).

Removes emojis, emoji descriptions, Markdown formatting, HTML tags, and UI artifacts
while preserving the natural clinical meaning of the assistant's response.
"""

from __future__ import annotations

import re

# Comprehensive Unicode pattern matching symbols, emoticons, pictographs, flags, etc.
_EMOJI_PATTERN = re.compile(
    r"["
    r"\U00010000-\U0010ffff"  # All supplementary planes (SMP including all modern emojis)
    r"\u2600-\u27bf"          # Misc symbols & Dingbats (e.g. ⚡, ⚪, ⏱, ✉)
    r"\u2300-\u23ff"          # Misc technical (e.g. ⏸, ⏹, ⏱, ⌛)
    r"\u2b50\u2b55"          # Star, heavy circle
    r"\ufe00-\ufe0f"          # Variation selectors (e.g. \ufe0f)
    r"\u200d"                 # Zero-width joiner (ZWJ)
    r"\u2060-\u206f"          # Word joiners / format chars
    r"]+",
    flags=re.UNICODE,
)

# Textual emoji shortcodes, e.g. :wave:, :smile:, :doctor:
_EMOJI_SHORTCODE_PATTERN = re.compile(r":[a-z0-9_+-]+:", flags=re.IGNORECASE)

# Markdown link: [Anchor text](url) -> Anchor text
_MD_LINK_PATTERN = re.compile(r"\[([^\]]+)\]\([^)]+\)")

# Markdown image: ![alt](url) -> ""
_MD_IMAGE_PATTERN = re.compile(r"!\[[^\]]*\]\([^)]+\)")

# HTML tags: <...> -> ""
_HTML_TAG_PATTERN = re.compile(r"<[^>]+>")

# Code blocks: ```...``` -> ""
_CODE_BLOCK_PATTERN = re.compile(r"```[\s\S]*?```")

# Inline code: `code` -> code
_INLINE_CODE_PATTERN = re.compile(r"`([^`]+)`")

# Markdown line prefixes: headers, blockquotes, list markers
_MD_LINE_PREFIX_PATTERN = re.compile(r"(?m)^[\s]*(?:#{1,6}\s+|>\s*|[-*+•]\s+|\d+\.\s+)")

# Bold / italic / strikethrough: **text**, *text*, __text__, _text_, ~~text~~
_MD_STYLE_PATTERN = re.compile(r"(\*\*|__|\*|_|~~)(.*?)\1")


def clean_text_for_speech(text: str) -> str:
    """Prepare text for TTS by stripping non-spoken visual artifacts.

    - Removes emojis and shortcodes so engines do not pronounce 'waving hand'.
    - Strips Markdown formatting (bold, italic, headers, bullet points).
    - Unwraps markdown links to their readable text.
    - Cleans up trailing punctuation and double spaces.
    """
    if not text:
        return ""

    s = text

    # 1. Code blocks and inline code
    s = _CODE_BLOCK_PATTERN.sub(" ", s)
    s = _INLINE_CODE_PATTERN.sub(r"\1", s)

    # 2. Markdown images and links
    s = _MD_IMAGE_PATTERN.sub(" ", s)
    s = _MD_LINK_PATTERN.sub(r"\1", s)

    # 3. HTML tags
    s = _HTML_TAG_PATTERN.sub(" ", s)

    # 4. Markdown headers and list markers
    s = _MD_LINE_PREFIX_PATTERN.sub("", s)

    # 5. Bold, italic, and strikethrough styling
    for _ in range(3):
        s = _MD_STYLE_PATTERN.sub(r"\2", s)

    # 6. Emojis and shortcodes
    s = _EMOJI_PATTERN.sub(" ", s)
    s = _EMOJI_SHORTCODE_PATTERN.sub(" ", s)

    # 7. Normalize punctuation for speech cadence
    # e.g., "Doctor! How can I help" -> "Doctor. How can I help"
    s = re.sub(r"\bDoctor!\s+([A-Z])", r"Doctor. \1", s)

    # Remove duplicate punctuation like "!." or "?. " -> single punctuation
    s = re.sub(r"([!?,.])\s*([!?,.])+", r"\1", s)

    # Fix space before punctuation: "Doctor ." -> "Doctor."
    s = re.sub(r"\s+([,.:;?!])", r"\1", s)

    # Collapse whitespace into single spaces and trim
    s = re.sub(r"\s+", " ", s).strip()

    return s
