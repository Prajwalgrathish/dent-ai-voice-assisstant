"""
Deterministic patient resolution.

The LLM (or your intent code) may EXTRACT a name / ID string from the request.
THIS module alone decides which record opens. Nothing here guesses a patient:
only an exact patient ID or an exact, unique full-name match returns "matched".
Everything else asks the user.

Input records are plain mappings with at least "patient_id" and "name"
(optional "date_of_birth"). Adapt your own patient rows with a one-line mapping.
"""
from __future__ import annotations

import difflib
import re
import unicodedata
from dataclasses import dataclass
from typing import Mapping, Optional, Sequence

# ───────────── spoken patient-ID normalisation ─────────────
_WORD_DIGITS = {"zero": "0", "oh": "0", "o": "0", "one": "1", "two": "2", "three": "3", "four": "4",
                "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9"}
_MULT = {"double": 2, "triple": 3}
_TOK = r"zero|oh|one|two|three|four|five|six|seven|eight|nine|double|triple|o|\d"
_ID_RE = re.compile(rf"\bP(?![A-Za-z])[\s\-_.]*((?:(?:{_TOK})(?![A-Za-z])[\s\-_.,]*)+)", re.I)


def _digits(span: str) -> str:
    out, mult = [], 1
    for t in re.findall(_TOK, span, re.I):
        t = t.lower()
        if t in _MULT:
            mult = _MULT[t]
            continue
        out.append(_WORD_DIGITS.get(t, t) * mult)
        mult = 1
    return "".join(out)


def extract_patient_id(text: Optional[str]) -> Optional[str]:
    """'P001', 'P-001', 'P 001', 'p 0 0 1', 'P zero zero one', 'p oh oh one', 'P double zero one' -> 'P001'.
    Returns None when there is no ID, fewer than 3 digits, or two DIFFERENT IDs (ambiguous)."""
    if not text:
        return None
    ids = set()
    for m in _ID_RE.finditer(text):
        d = _digits(m.group(1))
        if len(d) >= 3:
            ids.add("P" + d)
    return ids.pop() if len(ids) == 1 else None


# ───────────── name helpers ─────────────
_FILLER = {"dr", "doctor", "mr", "mrs", "ms", "miss", "patient", "named", "called", "for", "of", "the"}


def _norm(s: Optional[str]) -> str:
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    s = re.sub(r"['’]s\b", "", s)
    s = re.sub(r"[^a-z\s]", " ", s)
    return " ".join(t for t in s.split() if t not in _FILLER)


def _ratio(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, a, b).ratio()


@dataclass(frozen=True)
class Resolution:
    status: str                      # matched | ambiguous | needs_confirmation | not_found | needs_repeat | no_query
    patient: Optional[Mapping] = None
    candidates: tuple = ()
    message: str = ""                # safe to show / speak
    reason: str = ""                 # diagnostic: exact_id | exact_name | subset | fuzzy | ...
    query: str = ""                  # what we were asked to resolve (no extra patient data)


def _label(p: Mapping) -> str:
    dob = p.get("date_of_birth")
    return f"{p.get('name', '?')} ({p.get('patient_id', '?')}" + (f", born {dob})" if dob else ")")


def _options(cands: Sequence[Mapping]) -> str:
    return "; ".join(f"{i}. {_label(p)}" for i, p in enumerate(cands, 1))


def _sorted(c):
    return tuple(sorted(c, key=lambda p: str(p.get("patient_id", ""))))


def resolve(patients: Sequence[Mapping], *, name: Optional[str] = None, patient_id: Optional[str] = None,
            stt_confidence: Optional[float] = None, min_confidence: float = 0.55,
            fuzzy_threshold: float = 0.88, allow_unique_partial: bool = False) -> Resolution:
    """stt_confidence=None means typed input (no STT uncertainty). Use the real STT score only if
    your provider supplies one; never invent it."""
    q = (name or patient_id or "").strip()
    if stt_confidence is not None and stt_confidence < min_confidence:
        return Resolution("needs_repeat", query=q, reason="low_stt_confidence",
                          message="I'm not confident I heard that correctly. Could you repeat it, or spell the name or patient ID?")

    pid = None
    if patient_id:
        pid = extract_patient_id(patient_id)
        if pid is None:
            return Resolution("needs_repeat", query=q, reason="unreadable_id",
                              message="I couldn't read that patient ID. Please repeat it, for example P001.")
    elif name:
        pid = extract_patient_id(name)

    name_wo_id = _ID_RE.sub(" ", name or "")
    n = _norm(name_wo_id)

    if pid:
        hits = [p for p in patients if str(p.get("patient_id", "")).upper() == pid]
        if not hits:
            return Resolution("not_found", query=q, reason="id_not_found",
                              message=f"I couldn't find patient ID {pid}. Would you like to try another name or patient ID?")
        if len(hits) > 1:
            return Resolution("ambiguous", candidates=_sorted(hits), query=q, reason="duplicate_id",
                              message=f"More than one record has ID {pid}; please check the data.")
        p = hits[0]
        if n:  # a name was also given: it must agree with the ID
            pn = _norm(p.get("name"))
            if not (n == pn or set(n.split()) <= set(pn.split()) or _ratio(n, pn) >= fuzzy_threshold):
                return Resolution("needs_confirmation", candidates=(p,), query=q, reason="id_name_mismatch",
                                  message=f"{pid} belongs to {p.get('name')}, which doesn't match the name you gave. Which patient do you mean?")
        return Resolution("matched", patient=p, query=q, reason="exact_id")

    if not n:
        return Resolution("no_query", query=q, message="Which patient do you mean? Please give a name or patient ID.")

    toks = n.split()
    recs = [(p, _norm(p.get("name"))) for p in patients]

    exact = [p for p, pn in recs if pn == n]
    if len(exact) == 1:
        return Resolution("matched", patient=exact[0], query=q, reason="exact_name")
    if len(exact) > 1:
        return Resolution("ambiguous", candidates=_sorted(exact), query=q, reason="duplicate_exact_name",
                          message=f"I found {len(exact)} patients named {name.strip()}: {_options(_sorted(exact))}. Which one do you mean? You can say the patient ID or 'the first'.")

    if len(toks) >= 2:
        sub = [p for p, pn in recs if set(toks) <= set(pn.split())]
    else:
        sub = [p for p, pn in recs if toks[0] in pn.split()]
    if len(sub) > 1:
        return Resolution("ambiguous", candidates=_sorted(sub), query=q, reason="partial_name_multiple",
                          message=f"Several patients match '{name.strip()}': {_options(_sorted(sub))}. Which one do you mean?")
    if len(sub) == 1:
        if allow_unique_partial and len(toks) == 1:
            return Resolution("matched", patient=sub[0], query=q, reason="unique_partial")
        return Resolution("needs_confirmation", candidates=tuple(sub), query=q, reason="partial_name_unique",
                          message=f"Do you mean {_label(sub[0])}? Please confirm, or give the patient ID.")

    scored = []
    for p, pn in recs:
        s = _ratio(n, pn)
        if len(toks) == 1:
            s = max([s] + [_ratio(toks[0], t) for t in pn.split()])
        if s >= fuzzy_threshold:
            scored.append((s, p))
    if scored:
        scored.sort(key=lambda x: -x[0])
        c = tuple(p for _, p in scored)
        return Resolution("needs_confirmation", candidates=c, query=q, reason="fuzzy_name",
                          message=f"I'm not sure I heard the name correctly. Did you mean {_options(c)}? Please confirm or give the patient ID.")

    return Resolution("not_found", query=q, reason="name_not_found",
                      message=f"I couldn't find a patient named {name.strip()}. Would you like to try another name or patient ID?")


# ───────────── answering a "which one?" question ─────────────
_ORD = {"first": 0, "1st": 0, "second": 1, "2nd": 1, "third": 2, "3rd": 2, "fourth": 3, "4th": 3, "fifth": 4, "5th": 4}


def select_from_candidates(text: str, candidates: Sequence[Mapping], *, stt_confidence: Optional[float] = None,
                           min_confidence: float = 0.55) -> Resolution:
    """`candidates` MUST be the same ordered list that was shown/spoken to the user (keep it in session state)."""
    cands = tuple(candidates)
    opts = _options(cands)
    again = lambda why: Resolution("needs_repeat", candidates=cands, reason=why, query=text or "",
                                   message=f"Sorry, I couldn't tell which one you meant. The options are: {opts}. Please say the patient ID or 'the first'.")
    if stt_confidence is not None and stt_confidence < min_confidence:
        return again("low_stt_confidence")
    pid = extract_patient_id(text)
    if pid:
        hit = [p for p in cands if str(p.get("patient_id", "")).upper() == pid]
        return Resolution("matched", patient=hit[0], candidates=cands, reason="exact_id", query=text) if len(hit) == 1 else again("id_not_in_options")
    m = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", text or "")
    if m:
        hit = [p for p in cands if p.get("date_of_birth") == m.group(1)]
        return Resolution("matched", patient=hit[0], candidates=cands, reason="dob", query=text) if len(hit) == 1 else again("dob_not_unique")
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    for w in (words if len(words) <= 6 else []):  # an ordinal inside a long sentence ("...third molar...") is not a choice
        if w in _ORD:
            i = _ORD[w]
            return Resolution("matched", patient=cands[i], candidates=cands, reason="ordinal", query=text) if i < len(cands) else again("ordinal_out_of_range")
    n = _norm(text)
    hit = [p for p in cands if n and _norm(p.get("name")) == n]
    if len(hit) == 1:
        return Resolution("matched", patient=hit[0], candidates=cands, reason="exact_name", query=text)
    return again("no_selector")
