"""Command-line front end.

  python -m voiceassistant.cli --text "What is machine learning?"      # typed input (no STT)
  python -m voiceassistant.cli --audio-file question.wav               # STT -> LLM -> TTS
  python -m voiceassistant.cli --record 5                              # microphone (needs: pip install sounddevice)
  python -m voiceassistant.cli                                         # interactive typed loop
"""

from __future__ import annotations

import argparse
import logging
import shutil
import subprocess
import sys
import uuid
import wave
from pathlib import Path

from .audio import wav_duration
from .config import Settings
from .errors import AudioValidationError, VoiceAssistantError
from .factory import build_pipeline
from .models import TurnResult

RECORD_RATE = 16000


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="voiceassistant.cli", description="Voice assistant (English, turn-based).")
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--text", help="typed input (speech recognition is NOT used)")
    mode.add_argument("--audio-file", help="path to a recorded audio file (.wav recommended)")
    mode.add_argument("--record", type=float, metavar="SECONDS", help="record from the microphone (needs sounddevice)")
    p.add_argument("--no-play", action="store_true", help="do not play the spoken reply")
    p.add_argument("--no-confirm", action="store_true", help="do not pause to review/correct the transcript")
    p.add_argument("--save-audio", metavar="OUT.wav", help="keep a copy of the spoken reply")
    p.add_argument("-v", "--verbose", action="store_true", help="show log messages")
    return p


def play_wav(path: Path) -> tuple[bool, str]:
    """Play a WAV file. Windows uses the standard-library winsound; others try common players."""
    if sys.platform == "win32":
        try:
            import winsound

            winsound.PlaySound(str(path), winsound.SND_FILENAME)
            return True, "played with winsound"
        except Exception as exc:  # noqa: BLE001
            return False, f"playback failed ({type(exc).__name__})"
    for player in ("afplay", "paplay", "aplay"):
        exe = shutil.which(player)
        if exe:
            try:
                subprocess.run([exe, str(path)], check=True, timeout=300)
                return True, f"played with {player}"
            except (OSError, subprocess.SubprocessError):
                return False, f"playback with {player} failed"
    return False, "no audio player found"


def record_wav(seconds: float, out_path: Path) -> None:
    try:
        import sounddevice as sd
    except ImportError:
        raise AudioValidationError(
            "sounddevice missing",
            user_message="Microphone recording needs the sounddevice package: pip install sounddevice",
        ) from None
    try:
        data = sd.rec(int(seconds * RECORD_RATE), samplerate=RECORD_RATE, channels=1, dtype="int16")
        sd.wait()
    except Exception as exc:  # noqa: BLE001
        raise AudioValidationError(
            f"recording failed: {type(exc).__name__}",
            user_message="Could not record from the microphone. Check that one is connected and allowed.",
        ) from None
    with wave.open(str(out_path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RECORD_RATE)
        w.writeframes(data.tobytes())


def _show_result(pipeline, result: TurnResult, args) -> int:
    if result.input_mode == "typed":
        print("[typed input - speech recognition not used]")
    if result.error:
        print(f"[{result.error.stage} error] {result.error.message}")
        return 1
    print(f"You: {result.user_text}")
    print(f"Assistant: {result.reply_text}")
    if result.audio_path:
        try:
            print(f"(spoken reply: {result.tts_engine}, {wav_duration(result.audio_path):.1f}s)")
            if args.save_audio:
                shutil.copyfile(result.audio_path, args.save_audio)
                print(f"(saved to {args.save_audio})")
            if not args.no_play:
                ok, info = play_wav(result.audio_path)
                print(f"(playback: {info})" if ok else f"(playback not available: {info}; the text answer is above)")
        finally:
            pipeline.cleanup(result)
    elif result.tts_error:
        print(f"(speech unavailable: {result.tts_error.message})")
    return 0


def _handle_audio(pipeline, audio_path: Path, args, input_fn) -> int:
    try:
        transcript = pipeline.transcribe(audio_path)
    except VoiceAssistantError as exc:
        print(f"[{exc.stage} error] {exc.user_message}")
        return 1
    conf = f", confidence ~{transcript.confidence:.2f}" if transcript.confidence is not None else ""
    print(f"Transcript (speech recognition{conf}): {transcript.text}")
    
    if transcript.low_confidence:
        print("  Warning: recognition confidence is low. Please check names and numbers carefully.")

    text = transcript.text
    if not args.no_confirm:
        corrected = input_fn(
            "Press Enter to accept, or type the FULL corrected sentence: "
        ).strip()
        if corrected:
            text = corrected
            print(f"Corrected transcript: {text}")

    return _show_result(pipeline, pipeline.respond(text, "speech", transcript), args)


def main(argv=None, environ=None, input_fn=input) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO if args.verbose else logging.ERROR, format="%(levelname)s %(name)s: %(message)s")
    try:
        settings = Settings.from_env(environ, dotenv_path=None if environ is not None else ".env")
        pipeline = build_pipeline(settings)
    except VoiceAssistantError as exc:
        print(f"Configuration error: {exc.user_message}", file=sys.stderr)
        return 2

    if args.text is not None:
        return _show_result(pipeline, pipeline.run_text(args.text), args)

    if args.audio_file:
        return _handle_audio(pipeline, Path(args.audio_file), args, input_fn)

    if args.record is not None:
        if args.record <= 0 or args.record > settings.max_audio_seconds:
            print(f"--record must be between 0 and {settings.max_audio_seconds:g} seconds.", file=sys.stderr)
            return 2
        rec = settings.tmp_dir / f"rec-{uuid.uuid4().hex}.wav"
        try:
            print(f"Recording {args.record:g}s... speak now.")
            record_wav(args.record, rec)
            return _handle_audio(pipeline, rec, args, input_fn)
        except VoiceAssistantError as exc:
            print(f"[{exc.stage} error] {exc.user_message}")
            return 1
        finally:
            rec.unlink(missing_ok=True)  # do not keep recordings

    print("Typed interactive mode (speech recognition not used). Empty line or 'quit' to exit.")
    while True:
        try:
            line = input_fn("You> ").strip()
        except EOFError:
            break
        if not line or line.lower() in {"quit", "exit"}:
            break
        _show_result(pipeline, pipeline.run_text(line), args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
