"""Build providers and the pipeline from Settings. Swapping a provider = changing config here only."""

from __future__ import annotations

from .config import Settings
from .errors import ConfigError
from .pipeline import VoicePipeline
from .providers.base import FallbackTTS, LLMProvider, STTProvider, TTSProvider


def build_stt(s: Settings) -> STTProvider:
    if s.stt_provider == "fake":
        from .providers.fake import FakeSTT

        return FakeSTT()
    if s.stt_provider == "faster_whisper":
        from .providers.stt_faster_whisper import FasterWhisperSTT

        return FasterWhisperSTT(s.stt_model, s.stt_device, s.stt_compute_type, s.stt_min_confidence)
    raise ConfigError(f"Unknown STT provider {s.stt_provider!r}")


def build_llm(s: Settings) -> LLMProvider:
    if s.llm_provider == "fake":
        from .providers.fake import FakeLLM

        return FakeLLM()
    if s.llm_provider == "openai_compat":
        from .providers.llm_openai_compat import OpenAICompatLLM

        return OpenAICompatLLM(
            base_url=s.llm_base_url,
            model=s.llm_model,
            api_key=s.llm_api_key,
            timeout_s=s.llm_timeout_s,
            max_retries=s.llm_max_retries,
            temperature=s.llm_temperature,
            max_tokens=s.llm_max_tokens,
        )
    raise ConfigError(f"Unknown LLM provider {s.llm_provider!r}")


def _build_one_tts(name: str, s: Settings) -> TTSProvider:
    if name == "fake":
        from .providers.fake import FakeTTS

        return FakeTTS()
    if name == "piper":
        from .providers.tts_piper import PiperTTS

        return PiperTTS(s.piper_model_path, s.piper_length_scale)
    if name == "pyttsx3":
        from .providers.tts_pyttsx3 import Pyttsx3TTS

        return Pyttsx3TTS(s.tts_rate_wpm)
    raise ConfigError(f"Unknown TTS provider {name!r}")


def build_tts(s: Settings) -> TTSProvider:
    providers = [_build_one_tts(name, s) for name in s.tts_providers]
    return providers[0] if len(providers) == 1 else FallbackTTS(providers)


def build_pipeline(s: Settings) -> VoicePipeline:
    return VoicePipeline(build_stt(s), build_llm(s), build_tts(s), s)
