# DentVoice AI: architecture (one page)

One Streamlit app with four sidebar sections talks to one FastAPI backend. Speech, language model and speech synthesis
are swappable providers behind small interfaces (`voiceassistant/providers/`).

```
 Browser (Streamlit, frontend/)                       FastAPI backend (voiceassistant/api.py)
 ┌──────────────────────────────┐   HTTP/JSON   ┌──────────────────────────────────────────────────────┐
 │ 1 AI Assistant               │──────────────▶│ /v1/turn  /v1/stt  /v1/tts  (clinician, optional key)│
 │ 2 Patient Reports            │──────────────▶│ /v1/dental/*  /v1/clinical/dictation                 │
 │ 3 Clinical Dictation         │──────────────▶│                                                      │
 │ 4 Patient Voice Assistant    │──bearer token▶│ /v1/patient/session | reports | chat   (patient)     │
 └──────────────────────────────┘               └───────────────┬──────────────────────────────────────┘
        mic (dentvoice_mic / st.audio_input)                    │
        audio playback                          STT ◀─ faster-whisper │ LLM ◀─ Ollama / any OpenAI-compatible │ TTS ◀─ Piper / pyttsx3
```

## Patient Voice Assistant flow (the part with the safety rules)

```
 voice ──▶ /v1/stt ──▶ text ─┐
 typed ──────────────────────┴▶ POST /v1/patient/chat  (bearer token ⇒ patient; nothing else can name a patient)
      1. validate input (type, length)                                   patient/assistant.py
      2. SAFETY POLICY (deterministic regex; the LLM is never asked)      patient/policy.py
            other patient · urgent symptoms · diagnosis · treatment · prognosis  ⇒ refuse, restate own report only
      3. INTERPRET  rules first; LLM only if rules cannot tell            patient/interpreter.py
            ⇒ proposal {intent, report_ref, term, simplify}   (untrusted)
      4. VALIDATE the proposal against THIS patient's data                 patient/policy.py
            unknown intent → unknown · foreign report id → dropped · extra fields (e.g. patient_id) → ignored
      5. TOOLS (deterministic, bound to the session's patient)             patient/tools.py
            list_my_reports · get_my_report · define_dental_term   (no tool accepts a patient selector)
      6. COMPOSE   "From your report: …" = verbatim stored text (code)   +   "In general: …" = glossary or LLM
      7. GUARDRAILS on any LLM text → on failure discard it, use the glossary answer    patient/guardrails.py
      8. answer + evidence (report id, type, date, quotes) + grounding + timings  ⇒  optional TTS (/v1/patient/chat speak=true)
```

**LLM interpretation vs business rules.** The model only (a) proposes how to read a question and (b) phrases *general*
background that code already chose. Authorization, patient resolution, report retrieval, refusals and the choice of
what counts as "documented" are plain functions with unit tests. A model that is manipulated into proposing another
patient's report ID or a `patient_id` has that dropped by `validate_interpretation` and by the tools (tested in
`AuthorizationTests.test_llm_cannot_widen_access_by_proposing_foreign_ids`).

**Tool calling.** `patient/tools.py` exposes the three tools with OpenAI-style function schemas (`TOOL_SCHEMAS`, no patient
parameter) and a `dispatch(name, arguments)` that rejects unknown tools and unexpected arguments. The default flow
uses a *structured-intent + deterministic dispatch* design (works with any model, including ones with no native tool
calling); `dispatch` is the integration point if you switch to native function calling.

**Follow-ups.** Each session keeps a bounded `ConversationContext` (active report, last request, last 8 turns) on the
server, scoped to that token. "Explain this in simple English", "tell me more" and "what does this finding mean?" reuse
the previous topic and report without asking again; sessions never share context.

**Clinical dictation → draft report.** Transcript (typed, uploaded audio, or live speech via STT) → `/v1/clinical/dictation`
(`api._build_clinical_draft`, `dictation.build_draft`): original transcript preserved verbatim, only dictated site/finding
extracted, uncertainty labelled, `requires_clinician_review: true`. Available both in *Clinical Dictation* and inline in
*AI Assistant* (same endpoint; the draft can be handed to the full review/sign-off flow).

**Mock data.** `voiceassistant/dental/patients.json`: 6 synthetic patients, two named *Priya Sharma* (P001, P002) and a
*Priya Naik* (P006), two reports each.
