# Production considerations: privacy, authorization, latency, cost

Everything here is a demonstration build on **synthetic data**. This note says what is implemented, what is measured,
what is only an estimate, and what a real deployment would still need.

## Privacy
- **Data minimisation.** Patient endpoints return only whitelisted report fields (`id, type, date, findings, impression`).
  The LLM prompt contains the signed-in patient's own report text and a few glossary lines, never other patients' data and
  never contact details.
- **Logs.** The patient flow logs only a short hash of the session (`sid=ab12cd34`), intent, grounding, timings and refusal
  category. It does not log questions, answers, names, IDs or tokens. Error responses are generic and never echo input.
- **Where text goes.** With the default local Ollama LLM, conversation text stays on the machine. With a hosted
  `LLM_BASE_URL` the patient's question and the report text for that turn are sent to that provider: use a provider with
  a suitable data-processing agreement and, for real patients, do not use a consumer endpoint. Audio stays local (faster-whisper, Piper).
- **AI Assistant.** Only general-chat turns are sent back to the LLM as history; retrieved reports, dictation drafts and PDFs are not.
- **Retention.** Sessions live in memory only and expire (15 min idle / 30 min total, configurable). Nothing patient-specific is written to disk.

## Authorization
- Patient ID is the **only** credential, as the assignment specifies. **This is not adequate for real patients**: IDs are
  guessable and not secret. A real service needs identity verification (for example a one-time code to the registered phone
  or e-mail, or an identity-provider login with MFA), audit logging and consent handling.
- Mitigations in the demo: opaque random bearer tokens (256-bit), expiry, generic "not found" errors, failed-login rate
  limiting (default 10 per 5 min per client address), request models that reject unknown fields, report IDs resolved only inside
  the caller's own record (a foreign report returns the same 404 as a missing one).
- **Isolation tests**: `tests/test_patient_voice_assistant.py::AuthorizationTests` (missing/forged/expired token, foreign report ID,
  smuggled `patient_id`, "show me P002's report", prompt-injected interpretation, cross-session context).
- **Clinician endpoints** (`/v1/turn`, `/v1/dental/*`, `/v1/clinical/dictation`) are open in the demo, as before. Set
  `DENTVOICE_CLINICIAN_API_KEY` to require an `X-Clinician-Key` header; the Streamlit frontend sends it from the same environment variable.
  Without it, anyone who can reach the API can look patients up by name through those endpoints, so do not expose an unkeyed
  backend beyond localhost. `/v1/stt` and `/v1/tts` carry no patient data and are unauthenticated: add auth/rate limits before exposing them.
- The patient section and the clinician sections live in one Streamlit app. A patient-facing kiosk should be a separate deployment of
  the patient section only.

## Safety of answers
`policy.py` refuses diagnosis, treatment/medication, prognosis/severity, urgent symptoms (escalation message) and other-patient
requests **before any model runs**. LLM text must pass `guardrails.py` (no assertions of diagnosis, no advice, no reassurance,
no invented dates/tooth numbers/conditions, no other patients, not claiming to quote the report) or it is replaced by the glossary
answer. The "From your report" text is always the stored text, never model output. These checks are heuristics: they lower risk, they do not
prove an answer is clinically correct. Clinician review remains required.

## Latency
**Measured here** (`python scripts/measure_patient_latency.py --runs 20`; sandbox CPU, fake providers, HTTP on localhost, 140 requests):
orchestration only (safety + interpret + tools + compose + guardrails) is **about 0.4 to 0.7 ms server-side, p50 2.6 ms / p95 4.4 ms
per HTTP request**. The refusal path calls no model. These numbers contain **no model time**.

**Not measured here (estimates, depend on your hardware):** faster-whisper `base.en` on a laptop CPU is typically around real time
for a 5 s question (about 1 to 4 s); a 3B local LLM on CPU produces roughly 5 to 20 tokens/s, so a 100-token explanation is about 5 to 20 s
(a hosted model is typically 1 to 4 s); Piper TTS usually runs faster than real time (about 0.3 to 1.5 s for one answer). Expect an
end-to-end spoken turn of roughly **3 to 30 s locally** versus **under 10 s** with a hosted LLM. Run the script with `--real` (and `--speak`)
on the target machine to replace these estimates with measurements. Levers: rules-first interpretation (no model call for common
questions), the deterministic glossary answer needs no model at all, `LLM_MAX_TOKENS`, a smaller/faster model, `PATIENT_USE_LLM=0`.

## Model and tool cost
- **Tools are free**: they are in-process functions over a local JSON file.
- **Local models** (default Ollama + faster-whisper + Piper): no per-request fee; cost is your hardware and power.
- **Hosted LLM** per patient question: an explanation turn sends about **1.5 KB of prompt (about 380 tokens, estimated as chars/4)** and
  is capped at `LLM_MAX_TOKENS` (default 300) output tokens; a term definition is smaller. A turn that the rules cannot interpret adds one
  interpretation call of about 280 tokens. Refusals, report listings and glossary definitions cost **zero** model tokens.
  Cost per turn = (input tokens × input price + output tokens × output price) for your chosen model; prices change, so check your provider.
- STT and TTS are local here; a hosted STT/TTS would add per-minute/per-character cost.

## Failure handling implemented
Empty/oversized/malformed questions (422), unknown/malformed IDs (404/422), too many attempts (429), missing/expired token (401), missing
report (generic 404), LLM outage or unusable output (falls back to the glossary answer; never an error to the patient), TTS failure (text answer
still returned with `tts_error`), STT failure/empty speech (clear message, typed fallback), unexpected exception (generic 500, logged without patient data).

## Known gaps for a real deployment
Real patient authentication; shared session store (Redis) for more than one process; per-end-user rate limiting behind a trusted proxy
(behind Streamlit every patient shares one client address); TLS; audit trail; clinician review workflow beyond the draft/sign-off UI; clinical
validation of the glossary and of the model prompts by dentists; richer report data (the synthetic findings are one-line placeholders).
