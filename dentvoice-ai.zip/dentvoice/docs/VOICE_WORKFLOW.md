# Hands-free voice workflow (AI Assistant)

## The one rule
**The UI only says what the browser reports.** "Speaking…" appears when the `<audio>` element fires `playing` and clears
on `ended` / `error` / `pause`. "Listening…" appears only after the microphone stream and audio graph are actually
running. Nothing is inferred from a reply having been generated, a WAV file existing, or a wall-clock estimate.

## Where the logic lives
| Concern | Owner | Why |
|---|---|---|
| Assistant audio playback, start/end/blocked/failed reporting | browser component `dentvoice_mic/frontend/index.html` | only the browser knows if sound really played |
| Microphone capture, speech detection, **idle timer** | same component | the timer must count real listening silence (chunks arriving while un-gated), not elapsed page time |
| Conversation, clarification, greeting text, TTS, session state | Streamlit (`frontend/sections/assistant.py`) | survives microphone restarts and reruns |
| Greeting wording, "Listen to me" matching | `voiceassistant/voice_commands.py` | pure functions, unit-tested |

The component sends its last 12 events with every update (`{"events": [...]}`); Streamlit de-duplicates by id, so two
events emitted before a rerun cannot overwrite each other. Events: `ready`, `resume` (capture truly running), `pause`,
`idle_timeout`, `needs_tap`, `utterance`, `error`, `playback` (`started|ended|failed|blocked`).

## The flow
1. **Open** → greeting for the browser's local time (browser UTC offset, so it needs no time-zone database): morning 05–11
   "Good morning, Doctor. Welcome to DentVoice AI. How can I help you?", afternoon 12–16, evening 17–20, night 21–04
   "Hello, Doctor. How can I help you tonight?". Created once per session (`greeted`), written text == spoken text.
2. The greeting audio is handed to the browser. If autoplay is blocked: `playback:blocked`, the text is still shown, a
   "Tap to hear the reply" button appears in the microphone panel and a player is under the message. Never "Speaking…".
3. When playback **ended** (or there was no audio) the component starts listening by itself **if the browser already has
   microphone permission**. First visit: one tap on the microphone (permission prompt); afterwards it is automatic.
4. **Idle timer**: starts when capture is running and the mic is not gated. It counts only silence. It resets when speech
   starts, is never applied mid-utterance, and is held at zero while the request is transcribed/answered and while any
   assistant audio plays (+250 ms echo guard). After 15 s (30 s while waiting for a clarification answer): capture stops,
   status "Stopped after 15 seconds of silence", the conversation and any pending question are kept.
5. **Utterance** → STT → deterministic rules/LLM → reply → audio to the browser → `playing` → `ended` → listening again
   (the mic never closed; it was only gated). Empty/very short audio is dropped, never submitted.
6. **Resume** after a stop: tap the microphone, press *Resume listening*, or type **"Listen to me"** / "Start listening" /
   "Listen". While the mic is already on, saying it just gets "I'm listening, Doctor." Pending clarification, active
   patient and chat are untouched; no greeting, no LLM call, no second capture session (`start()` is a no-op while
   requesting/active).

## Clarification
`pending_report_name/type/intent/candidates` live in Streamlit session state and are never cleared by microphone
events, timeouts or reruns (tests simulate pause/resume/idle/resume). Answers accepted: patient ID in any spoken form
("Patient ID is P 0 0 1"), "the first", date of birth, yes/no. Wrong or unknown IDs keep the question open. "Give her
reports" uses the already-identified patient; with nobody identified it asks, and the answer completes the request.

## Limitations (honest)
* **"Listen to me" cannot work while the microphone is fully off.** After the idle stop the browser holds no audio
  stream, so nothing can hear the phrase. The supported wake mechanisms are the microphone button, the Resume button,
  and typing the phrase. A always-on wake-word listener would need continuous capture (privacy, battery, a separate
  detector or the Chrome-only Web Speech API that streams audio to a vendor) and was deliberately not built.
* Browsers require a user gesture before they will let a page open the microphone/AudioContext. The first visit needs one
  tap; if a later automatic start is refused the component says so (`needs_tap`) instead of pretending to listen.
* Autoplay can be blocked per browser policy; recovery is explicit (button + player), not silent.
* Chrome allows autoplay once a page holds microphone permission, so in testing the *block* itself is reproduced by making
  `play()` reject with `NotAllowedError` (the exact exception Chrome throws); the recovery path is the real code.
* The Patient Voice Assistant uses `st.audio` (visible controls) for replies and its own recorder; it does not use the
  hands-free component.
* One component copy now exists at the project root (`dentvoice_mic/`). The earlier duplicate under
  `frontend/dentvoice_mic/` was identical and is what `streamlit run frontend\app.py` loaded, so editing the other copy had
  no effect; it was removed so they cannot drift again.
