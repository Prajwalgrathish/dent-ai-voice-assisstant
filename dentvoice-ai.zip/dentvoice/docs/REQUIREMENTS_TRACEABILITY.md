# Requirements traceability

Every row names the implementing code and the automated test(s) that exercise it.
"Unverified" marks anything that could only be checked with fakes, not real models/microphone.
Test files: `PVA` = tests/test_patient_voice_assistant.py, `FE` = tests/test_frontend_integration.py,
`AIF` = tests/test_ai_assistant_fixes.py.

## Assignment requirements

| Requirement | Implementation | Test evidence |
|---|---|---|
| A. Report retrieval from typed/spoken request, e.g. "Open Priya's latest OPG report" | `dental/report_intent.py`, `dental/service.py`, `patient_resolver.py` | PVA `AssignmentExampleRequestTests`, AIF `ReportRequestParsingTests`, existing `test_dental_service.py` |
| A. Ambiguous matches handled safely | `service.find_patient` returns candidates, never guesses; DOB+name only when unique | PVA `AmbiguousIdentityTests`, AIF `DobDisambiguationTests`, FE ordinal / ID / DOB resolution |
| A. Missing reports handled safely | service returns a "no report" result, not an error or a guess | PVA `test_thin_report_is_described_honestly`; existing dental service tests |
| B. Dictation -> editable JSON (findings, site, draft); no invented observations; uncertainty + clinician review | existing `dictation` module, reused inline in AI Assistant | existing `test_dictation.py`; AIF `ClinicalStatementDetectionTests`, edited-draft test; FE inline draft test |
| C. Follow-up without re-asking patient; evidence shown | server-side per-session context; `history` on `/v1/turn` | PVA `FollowUpContextTests`; AIF `ConversationMemoryTests` |
| Mock data: >=5 patients, 2 similar names, >=2 reports | `dental/patients.json` (6 synthetic patients, P001/P002 both Priya Sharma) | existing dental service tests |
| Tool calling / deterministic integration | `patient/tools.py` (`PatientTools.dispatch`, `TOOL_SCHEMAS`, no patient parameter) | PVA `test_tools_are_scoped_to_the_signed_in_patient`, `test_tool_schemas_expose_no_patient_selector` |
| LLM interpretation separate from business rules | `patient/interpreter.py` (rules first, LLM only if undecided) + `validate_interpretation`; `patient/policy.py` deterministic safety | PVA `test_llm_interpreter_is_used_only_when_rules_cannot_tell`, `test_validate_interpretation_drops_untrusted_fields`, `test_safety_policy_is_independent_of_any_llm` |
| Failure handling & input validation | request models with `extra="forbid"`, length limits, generic errors, LLM/TTS fallbacks, login rate limit | PVA `InvalidIdAndInputTests`, `FailureAndSpeechTests` |
| Privacy / authorization / latency / cost note | `docs/PRODUCTION_NOTES.md` | documentation; `scripts/measure_patient_latency.py` (orchestration only measured; model latency/cost are estimates) |
| >=3 tests: retrieval, ambiguity, unsupported claims | see classes below | PVA `CorrectRetrievalTests`, `AmbiguousIdentityTests`, `UnsupportedClinicalClaimTests` |
| README, env sample, limitations | `README.md`, `.env.example` | n/a |
| Demo sequence | `docs/DEMO.md`, `scripts/generate_demo_doc.py` | n/a |
| One-page architecture | `docs/ARCHITECTURE.md` | n/a |

## Four-section application

| Requirement | Implementation | Test evidence |
|---|---|---|
| Exactly four sidebar sections in order | `frontend/app.py` `PAGES` | FE `test_sidebar_has_exactly_the_four_main_sections_in_order`, `test_every_section_renders_without_error`; headless-browser check |
| Patient Reports / Clinical Dictation preserved | unchanged modules | existing suite (all still passing) |
| AI Assistant: bug fixes, dictation inline, follow-ups | `frontend/sections/assistant.py`, `pipeline.respond(history=)` | AIF all classes; FE navigation, dictation, selection tests |

## Patient Voice Assistant

| Requirement | Implementation | Test evidence |
|---|---|---|
| Patient-ID-only login, clear invalid-ID error, documented limitation | `/v1/patient/login`, `patient/sessions.py`; limitation in README + PRODUCTION_NOTES | PVA `InvalidIdAndInputTests`; FE invalid-ID and sign-in tests |
| Strict isolation incl. manipulated requests | patient taken only from bearer token; foreign report ID gives same 404 as missing; body cannot carry a patient ID | PVA `AuthorizationTests` (all) |
| Spoken + typed English Q&A, spoken answers | same chat endpoint, optional `speak`, TTS fallback to text | PVA `test_speak_true_returns_audio_and_timings`, `test_tts_failure_still_returns_the_written_answer`, `test_spoken_questions_use_the_same_endpoint` (fake providers) |
| Follow-ups keep patient/report | session context | PVA `FollowUpContextTests`; FE question test |
| Grounded; findings vs general info separated; no invented diagnoses | `patient/assistant.py`, `guardrails.py`, `glossary.py` | PVA `test_documented_and_general_information_are_labelled_separately`, `UnsupportedClinicalClaimTests` |

## Test totals (last run)

`python -m pytest -q`: **349 passed, 0 failed** (31 subtests passed, 2 deprecation warnings from dependencies).

## Not verified

Real faster-whisper STT, a real LLM (Ollama/OpenAI-compatible), real Piper/pyttsx3 audio, and live microphone
capture were not exercised (sandbox has no models/network for them). Tests use fake providers.
One existing test expectation (`test_clarification_and_mic_fixes.py`) was changed: it had enshrined a bug
(selecting a candidate re-sent masked contact details); it now expects the patient ID only.
`frontend.zip` was an older snapshot and was not used.
