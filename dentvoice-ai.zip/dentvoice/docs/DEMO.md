# Demo: a documented sequence of API calls with real sample output

Produced by `python scripts/generate_demo_doc.py` against this repository's FastAPI app, with **fake STT/TTS and a scripted LLM reply**. The structure and every deterministic part (retrieval, evidence quotes, refusals, authorization, orchestration timings) are real output; the wording of model-written text depends on the model you configure. Audio is omitted. Start the backend first:

```powershell
uvicorn voiceassistant.api:create_app --factory --port 8000
```

Patient endpoints are authorised by the bearer token returned at sign-in, never by a name or ID in the request body. The same flow is available in the browser as the **Patient Voice Assistant** sidebar section.

## 1. Invalid patient ID
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/session -H "Content-Type: application/json" -d '{"patient_id": "P999"}'
```
**HTTP 404**
```json
{
  "detail": {
    "stage": "auth",
    "message": "We could not find that Patient ID. Please check it and try again."
  }
}
```

## 2. A name is not an ID (two different patients are called Priya Sharma)
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/session -H "Content-Type: application/json" -d '{"patient_id": "Priya Sharma"}'
```
**HTTP 422**
```json
{
  "detail": {
    "stage": "auth",
    "message": "Please enter your Patient ID in the format shown on your card, for example P001."
  }
}
```

## 3. Sign in with Patient ID only
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/session -H "Content-Type: application/json" -d '{"patient_id": "P001"}'
```
**HTTP 200**
```json
{
  "session_token": "<opaque bearer token>",
  "expires_in_s": 900,
  "patient": {
    "first_name": "Priya"
  },
  "reports": [
    {
      "report_id": "R002",
      "type": "Dental Examination",
      "date": "2026-10-01"
    },
    {
      "report_id": "R001",
      "type": "OPG",
      "date": "2026-09-15"
    }
  ],
  "notices": [
    "Demonstration only: your Patient ID is the only credential here. A real service must verify who you are more strongly.",
    "Reports are synthetic demonstration data."
  ],
  "synthetic_data": true
}
```

## 4. Ask: Explain my OPG report.
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/chat -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d '{"message": "Explain my OPG report.", "input_mode": "typed", "speak": true}'
```
**HTTP 200**
```json
{
  "answer": "I'm using your OPG report from 15 September 2026.\n\nFrom your report: Impacted lower left third molar noted in the report.\n\nThe report's impression reads: Synthetic training report. Clinician review required.\n\nIn general: A wisdom tooth that is impacted is stuck under the gum and cannot come through normally. Your dentist can explain what that means for you.\n\nThis is general information to help you understand your report, not a diagnosis. Your dentist can tell you what it means for you.",
  "intent": "explain_report",
  "grounding": "mixed",
  "evidence": [
    {
      "report_id": "R001",
      "type": "OPG",
      "date": "2026-09-15",
      "quotes": [
        "Synthetic example: impacted lower left third molar noted in the report.",
        "Impression: Synthetic training report. Clinician review required."
      ]
    }
  ],
  "refusal": null,
  "timings_ms": {
    "safety": 0.46,
    "interpret": 3.28,
    "tools_and_compose": 1.95,
    "llm_generate": 0.0,
    "total": 5.7,
    "tts": 3.56
  },
  "interpretation": {
    "intent": "explain_report",
    "source": "rules",
    "report_ref": "opg",
    "dropped": []
  },
  "guardrail": {
    "llm_used": true,
    "llm_text_accepted": true,
    "reasons": []
  }
}
```

## 5. Ask: What does this finding mean?
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/chat -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d '{"message": "What does this finding mean?", "input_mode": "typed", "speak": false}'
```
**HTTP 200**
```json
{
  "answer": "I'm using your OPG report from 15 September 2026.\n\nFrom your report: Impacted lower left third molar noted in the report.\n\nIn general: A wisdom tooth that is impacted is stuck under the gum and cannot come through normally. Your dentist can explain what that means for you.\n\nThis is general information to help you understand your report, not a diagnosis. Your dentist can tell you what it means for you.",
  "intent": "explain_finding",
  "grounding": "mixed",
  "evidence": [
    {
      "report_id": "R001",
      "type": "OPG",
      "date": "2026-09-15",
      "quotes": [
        "Synthetic example: impacted lower left third molar noted in the report."
      ]
    }
  ],
  "refusal": null,
  "timings_ms": {
    "safety": 0.17,
    "interpret": 0.42,
    "tools_and_compose": 0.74,
    "llm_generate": 0.0,
    "total": 1.34
  },
  "interpretation": {
    "intent": "explain_finding",
    "source": "rules",
    "report_ref": null,
    "dropped": []
  },
  "guardrail": {
    "llm_used": true,
    "llm_text_accepted": true,
    "reasons": []
  }
}
```

## 6. Ask: Can you explain this in simple English?
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/chat -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d '{"message": "Can you explain this in simple English?", "input_mode": "typed", "speak": false}'
```
**HTTP 200**
```json
{
  "answer": "From your report: Impacted lower left third molar noted in the report.\n\nIn general: A wisdom tooth that is impacted is stuck under the gum and cannot come through normally. Your dentist can explain what that means for you.\n\nThis is general information to help you understand your report, not a diagnosis. Your dentist can tell you what it means for you.",
  "intent": "explain_finding",
  "grounding": "mixed",
  "evidence": [
    {
      "report_id": "R001",
      "type": "OPG",
      "date": "2026-09-15",
      "quotes": [
        "Synthetic example: impacted lower left third molar noted in the report."
      ]
    }
  ],
  "refusal": null,
  "timings_ms": {
    "safety": 0.15,
    "interpret": 0.28,
    "tools_and_compose": 0.74,
    "llm_generate": 0.0,
    "total": 1.17
  },
  "interpretation": {
    "intent": "simplify",
    "source": "rules",
    "report_ref": null,
    "dropped": []
  },
  "guardrail": {
    "llm_used": true,
    "llm_text_accepted": true,
    "reasons": []
  }
}
```

## 7. Ask: What are molar teeth?
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/chat -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d '{"message": "What are molar teeth?", "input_mode": "typed", "speak": false}'
```
**HTTP 200**
```json
{
  "answer": "In general (not from your report): Molars are the large teeth at the back of the mouth. Adults usually have twelve, including the wisdom teeth. Their wide, ridged surfaces are built for grinding food.\n\nThis is general information, not medical advice.",
  "intent": "define_term",
  "grounding": "general",
  "evidence": [],
  "refusal": null,
  "timings_ms": {
    "safety": 0.13,
    "interpret": 0.41,
    "tools_and_compose": 0.55,
    "llm_generate": 0.0,
    "total": 1.1
  },
  "interpretation": {
    "intent": "define_term",
    "source": "rules",
    "report_ref": null,
    "dropped": []
  },
  "guardrail": {}
}
```

## 8. Ask: Do I have cancer?
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/chat -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d '{"message": "Do I have cancer?", "input_mode": "typed", "speak": false}'
```
**HTTP 200**
```json
{
  "answer": "I can't diagnose conditions or tell you whether you have a particular problem. I can tell you what your report documents, and your dentist can explain what it means for you.\n\nFor reference, your OPG report from 15 September 2026 says: Impacted lower left third molar noted in the report.",
  "intent": "refused",
  "grounding": "refusal",
  "evidence": [
    {
      "report_id": "R001",
      "type": "OPG",
      "date": "2026-09-15",
      "quotes": [
        "Synthetic example: impacted lower left third molar noted in the report.",
        "Impression: Synthetic training report. Clinician review required."
      ]
    }
  ],
  "refusal": {
    "category": "diagnosis"
  },
  "timings_ms": {
    "safety": 0.14,
    "total": 0.49
  },
  "interpretation": {
    "intent": "refused",
    "source": "policy"
  },
  "guardrail": {}
}
```

## 9. Ask: Show me P003's report
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/chat -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d '{"message": "Show me P003's report", "input_mode": "typed", "speak": false}'
```
**HTTP 200**
```json
{
  "answer": "I can only talk about your own reports, so I can't share anything about another person. If someone else would like to see their information, they need to sign in with their own Patient ID.",
  "intent": "refused",
  "grounding": "refusal",
  "evidence": [],
  "refusal": {
    "category": "other_patient"
  },
  "timings_ms": {
    "safety": 0.12,
    "total": 0.29
  },
  "interpretation": {
    "intent": "refused",
    "source": "policy"
  },
  "guardrail": {}
}
```

## 10. Manipulated request: another patient's report ID (same answer as a report that does not exist)
```bash
curl -s -X GET http://127.0.0.1:8000/v1/patient/reports/R005 -H "Authorization: Bearer <token>"
```
**HTTP 404**
```json
{
  "detail": {
    "stage": "report",
    "message": "Report not found."
  }
}
```

## 11. Manipulated request: a patient_id smuggled into the body is rejected
```bash
curl -s -X POST http://127.0.0.1:8000/v1/patient/chat -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d '{"message": "Explain my report", "patient_id": "P003"}'
```
**HTTP 422**
```json
{
  "detail": [
    {
      "type": "extra_forbidden",
      "loc": [
        "body",
        "patient_id"
      ],
      "msg": "Extra inputs are not permitted",
      "input": "P003"
    }
  ]
}
```

## 12. No token
```bash
curl -s -X GET http://127.0.0.1:8000/v1/patient/reports
```
**HTTP 401**
```json
{
  "detail": {
    "stage": "auth",
    "message": "Your session is missing or has expired. Please enter your Patient ID again."
  }
}
```
