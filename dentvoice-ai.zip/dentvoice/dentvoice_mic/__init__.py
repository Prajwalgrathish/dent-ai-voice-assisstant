"""
dentvoice_mic - a small bidirectional Streamlit component.

Browser side (frontend/index.html): ONE getUserMedia stream feeds both the volume
visualiser and the recorder, detects the end of an utterance, and sends the
recorded 16 kHz mono WAV to Python as the component's return value.

Python side (this file): declares the component, validates what comes back and
hands you either an `Utterance` (real WAV bytes) or a `MicError`.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import streamlit.components.v1 as components

_component = components.declare_component(
    "dentvoice_mic", path=str(Path(__file__).parent / "frontend")
)


@dataclass(frozen=True)
class Utterance:
    id: str            # unique per utterance; use it to de-duplicate across reruns
    wav: bytes         # complete RIFF/WAV file, 16 kHz, mono, 16-bit PCM
    duration_s: float
    sample_rate: int


@dataclass(frozen=True)
class MicError:
    id: str
    code: str          # permission_denied | no_microphone | mic_busy | insecure_context
                       # | device_lost | audio_engine | mic_error | empty_audio
    message: str


@dataclass(frozen=True)
class MicAction:
    id: str
    action: str        # pause | resume | idle_timeout | needs_tap | ready
                       # resume       = capture is GENUINELY running now
                       # idle_timeout = the browser stopped capture after N seconds of real listening silence
    local_hour: Optional[int] = None   # only on "ready": the browser's local hour (0-23)


@dataclass(frozen=True)
class PlaybackEvent:
    """What the BROWSER really did with assistant audio (never inferred from a file's duration)."""
    id: str
    audio_id: str
    state: str         # started | ended | failed | blocked
    message: str = ""


Event = Union[Utterance, MicError, MicAction, PlaybackEvent]


def _parse(value) -> Optional[Event]:
    if not isinstance(value, dict):
        return None
    eid = str(value.get("id") or "")
    if not eid:
        return None
    kind = value.get("type")
    if kind == "action":
        hour = value.get("local_hour")
        return MicAction(eid, str(value.get("action", "")),
                         int(hour) if isinstance(hour, (int, float)) and 0 <= hour <= 23 else None)
    if kind == "playback":
        state = str(value.get("state", ""))
        if state not in ("started", "ended", "failed", "blocked"):
            return None
        return PlaybackEvent(eid, str(value.get("audio_id") or ""), state, str(value.get("message", "")))
    if kind == "error":
        return MicError(eid, str(value.get("code", "mic_error")), str(value.get("message", "")))
    if kind == "utterance":
        try:
            wav = base64.b64decode(value.get("wav_b64") or "", validate=True)
        except Exception:
            wav = b""
        # Never forward empty / malformed audio to the STT pipeline.
        if len(wav) <= 44 or wav[:4] != b"RIFF":
            return MicError(eid, "empty_audio", "The recording was empty and was discarded.")
        return Utterance(eid, wav, float(value.get("duration_s", 0.0)),
                         int(value.get("sample_rate", 16000)))
    return None


def _parse_all(value) -> list[Event]:
    """The component returns {"events": [...last few...]}; older builds returned one event dict."""
    if isinstance(value, dict) and isinstance(value.get("events"), list):
        out = []
        for raw in value["events"]:
            ev = _parse(raw)
            if ev is not None:
                out.append(ev)
        return out
    ev = _parse(value)
    return [ev] if ev is not None else []


def dentvoice_mic_events(
    *,
    key: str,
    assistant_state: str = "idle",   # "idle" | "processing" | "paused"  (what Python is doing right now)
    turn_id: Optional[str] = None,   # id of the Utterance that assistant_state refers to
    speaking_ms: int = 0,            # ignored (kept for compatibility): "speaking" now follows REAL playback events
    end_silence_ms: int = 900,       # silence that ends an utterance
    min_speech_ms: int = 200,        # shorter bursts are discarded as noise
    min_rms: float = 0.006,          # absolute speech-energy floor (responsive to clear speech)
    max_utterance_ms: int = 30_000,  # hard cap per utterance
    hold_timeout_ms: int = 120_000,  # safety watchdog: mic un-gates itself if Python never answers
    auto_start: bool = False,        # start listening by itself (only when the browser already has mic permission)
    paused: bool = False,            # explicitly pause microphone capture
    audio: Optional[dict] = None,    # {"id": str, "b64": base64 WAV}: assistant audio for the BROWSER to play
    done_ids: Optional[list] = None, # audio ids Python has already seen start/finish: never replayed
    idle_timeout_ms: int = 15_000,   # stop capture after this much silence while genuinely listening
    clarify: bool = False,           # assistant is waiting for a clarification answer
    clarify_timeout_ms: int = 30_000,
    resume_nonce: int = 0,           # bump to ask the browser to (re)start listening
    standby: bool = False,           # capture was stopped by the idle timeout: do not auto-start
) -> list[Event]:
    """Render the mic/player component. Returns the recent events (they PERSIST across reruns - always skip
    ids you have already processed)."""
    raw = _component(
        key=key,
        default=None,
        assistant_state=assistant_state,
        turn_id=turn_id,
        speaking_ms=int(speaking_ms or 0),
        end_silence_ms=end_silence_ms,
        min_speech_ms=min_speech_ms,
        min_rms=min_rms,
        max_utterance_ms=max_utterance_ms,
        hold_timeout_ms=hold_timeout_ms,
        auto_start=auto_start,
        paused=paused,
        audio=audio,
        done_ids=list(done_ids or [])[-50:],
        idle_timeout_ms=int(idle_timeout_ms),
        clarify=clarify,
        clarify_timeout_ms=int(clarify_timeout_ms),
        resume_nonce=int(resume_nonce),
        standby=standby,
    )
    return _parse_all(raw)


def dentvoice_mic(**kwargs) -> Optional[Event]:
    """Backward-compatible wrapper: the most recent event only."""
    events = dentvoice_mic_events(**kwargs)
    return events[-1] if events else None


__all__ = ["dentvoice_mic", "dentvoice_mic_events", "Utterance", "MicError", "MicAction", "PlaybackEvent", "Event"]
